# 贡献指南

感谢你对 StoryAtlas 的关注！

## 提 Issue

- 先搜索是否有重复 Issue
- 描述复现步骤与期望行为；关系分析类问题请附上能复现的人物与故事原文

## 提交 PR

1. Fork 仓库并创建特性分支
2. 保证本地通过全部检查：

   ```bash
   cd packages/storyatlas_core && dart analyze && dart test
   flutter analyze && flutter test
   ```

3. 修改关系分析行为时，请在 `packages/storyatlas_core/test/` 补充或更新测试
4. 提交信息使用简洁的动词开头描述（如 `feat: 支持节点拖拽`）

## 代码风格

- 遵循仓库根目录与核心包的 `analysis_options.yaml`（flutter_lints / lints）
- 核心引擎保持零运行时依赖；新分析能力优先放在 `packages/storyatlas_core`
- UI 改动尽量覆盖组件测试

## 开发约定

- 关系数据模型、分析与布局在核心包内，界面层不重写业务逻辑
- 自动分析结果是启发式的：优先改进「归属过滤」与「方向推断」等通用机制，而不是硬编码特例
- 提交前在 GitHub Actions 上确认 CI 通过
