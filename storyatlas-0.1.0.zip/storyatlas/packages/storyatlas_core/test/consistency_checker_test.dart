import 'package:storyatlas_core/storyatlas_core.dart';
import 'package:test/test.dart';

Character ch(String id, String name,
        {List<String> aliases = const [],
        List<String> traits = const [],
        int? birth,
        int? death,
        String description = ''}) =>
    Character(
      id: id,
      name: name,
      aliases: aliases,
      traits: traits,
      birthYear: birth,
      deathYear: death,
      description: description,
    );

Story st(String id, String title, String content,
        {int? year, List<String> characterIds = const []}) =>
    Story(
      id: id,
      title: title,
      content: content,
      time: year == null ? null : DateTime(year, 6, 1),
      characterIds: characterIds,
    );

List<StoryIssue> withCode(CheckReport r, String code) =>
    r.issues.where((i) => i.code == code).toList();

void main() {
  group('重名与重复', () {
    test('姓名与别名冲突报 error', () {
      final report = ConsistencyChecker.check(
        characters: [
          ch('a', '沈砚秋', aliases: ['砚秋']),
          ch('b', '砚秋'),
        ],
        stories: const [],
      );
      final issues = withCode(report, 'duplicate-name');
      expect(issues, isNotEmpty);
      expect(issues.first.severity, IssueSeverity.error);
      expect(issues.first.characterIds, containsAll(<String>['a', 'b']));
    });

    test('不重名时不报', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲'), ch('b', '乙')],
        stories: const [],
      );
      expect(withCode(report, 'duplicate-name'), isEmpty);
    });
  });

  group('时间线', () {
    test('出生年晚于死亡年报 error', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲', birth: 1990, death: 1980)],
        stories: const [],
      );
      expect(withCode(report, 'birth-after-death'), isNotEmpty);
    });

    test('情节早于人物出生时报 error', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲', birth: 1950)],
        stories: [st('s1', '早年', '甲还是个孩子。', year: 1940)],
      );
      final issues = withCode(report, 'story-before-birth');
      expect(issues, isNotEmpty);
      expect(issues.first.storyIds, ['s1']);
      expect(issues.first.characterIds, ['a']);
    });

    test('人物去世后仍出场报 error', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲', death: 1950)],
        stories: [st('s1', '多年后', '甲又回来了。', year: 1960)],
      );
      expect(withCode(report, 'appears-after-death'), isNotEmpty);
    });

    test('通过别名出场也能检出时间矛盾', () {
      final report = ConsistencyChecker.check(
        characters: [
          ch('a', '沈砚秋', aliases: ['砚秋'], death: 1950)
        ],
        stories: [st('s1', '多年后', '砚秋回来了。', year: 1960)],
      );
      expect(withCode(report, 'appears-after-death'), isNotEmpty);
    });

    test('勾选但未提名的关联也参与时间检查', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲', death: 1950)],
        stories: [
          st('s1', '无提名', '众人沉默不语。', year: 1960, characterIds: ['a']),
        ],
      );
      expect(withCode(report, 'appears-after-death'), isNotEmpty);
    });

    test('同年多篇情节提示补全日期', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲')],
        stories: [
          st('s1', '一', '甲出门了。', year: 1920),
          st('s2', '二', '甲又出门了。', year: 1920),
        ],
      );
      expect(withCode(report, 'same-year-stories'), isNotEmpty);
    });

    test('年份在合理范围内不误报', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲', birth: 1900, death: 1980)],
        stories: [st('s1', '中年', '甲正值壮年。', year: 1940)],
      );
      expect(withCode(report, 'story-before-birth'), isEmpty);
      expect(withCode(report, 'appears-after-death'), isEmpty);
    });
  });

  group('情节', () {
    test('缺时间提示', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲')],
        stories: [st('s1', '无时间', '甲出门了。')],
      );
      expect(withCode(report, 'story-no-time'), isNotEmpty);
    });

    test('正文过短提示', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲')],
        stories: [st('s1', '短', '甲走了。', year: 1920)],
      );
      expect(withCode(report, 'story-too-short'), isNotEmpty);
    });

    test('没有任何人物的情节报 warning', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲')],
        stories: [st('s1', '空场', '狂风卷过空无一人的长街，门窗吱呀作响。', year: 1920)],
      );
      expect(withCode(report, 'story-without-characters'), isNotEmpty);
    });

    test('勾选但正文未提及提示', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲'), ch('b', '乙')],
        stories: [
          st('s1', '只有甲', '甲在灯下写信，写了很多很多字，直到天亮才停笔。',
              year: 1920, characterIds: ['a', 'b']),
        ],
      );
      final issues = withCode(report, 'marked-but-not-mentioned');
      expect(issues, isNotEmpty);
      expect(issues.first.characterIds, ['b']);
    });
  });

  group('关系', () {
    test('关系指向不存在的人物', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲')],
        stories: const [],
        manual: [
          Relation(
            id: 'r1',
            fromId: 'a',
            toId: 'ghost',
            kind: RelationKind.friendship,
            source: RelationSource.manual,
            updatedAt: DateTime(2026),
          ),
        ],
      );
      expect(withCode(report, 'relation-dangling'), isNotEmpty);
    });

    test('师徒互指报 error', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲'), ch('b', '乙')],
        stories: const [],
        manual: [
          Relation(
            id: 'r1',
            fromId: 'a',
            toId: 'b',
            kind: RelationKind.masterApprentice,
            source: RelationSource.manual,
            updatedAt: DateTime(2026),
          ),
          Relation(
            id: 'r2',
            fromId: 'b',
            toId: 'a',
            kind: RelationKind.masterApprentice,
            source: RelationSource.manual,
            updatedAt: DateTime(2026),
          ),
        ],
      );
      expect(withCode(report, 'relation-mutual'), isNotEmpty);
    });

    test('孤儿人物提示', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲'), ch('b', '孤零零')],
        stories: [st('s1', '一篇', '甲独自走在夜路上，四周静得能听见自己的心跳。', year: 1920)],
      );
      final issues = withCode(report, 'orphan-character');
      expect(issues, isNotEmpty);
      expect(issues.first.characterIds, ['b']);
    });

    test('温和设定却频繁主动施暴报 warning', () {
      final report = ConsistencyChecker.check(
        characters: [
          ch('a', '甲', traits: ['温和']),
          ch('b', '乙'),
          ch('c', '丙'),
        ],
        stories: [
          st('s1', '冲突一', '甲杀了乙。', year: 1920),
          st('s2', '冲突二', '甲又打败了丙。', year: 1921),
        ],
      );
      final issues = withCode(report, 'trait-conflict');
      expect(issues, isNotEmpty);
      expect(issues.first.severity, IssueSeverity.warning);
      expect(issues.first.characterIds, ['a']);
    });

    test('性格标签自相矛盾报 warning', () {
      final report = ConsistencyChecker.check(
        characters: [
          ch('a', '甲', traits: ['温和', '暴躁'])
        ],
        stories: const [],
      );
      expect(withCode(report, 'trait-self-conflict'), isNotEmpty);
    });
  });

  group('报告汇总', () {
    test('按严重级别排序，且统计正确', () {
      final report = ConsistencyChecker.check(
        characters: [
          ch('a', '甲', birth: 1990, death: 1980),
          ch('b', '乙', description: '有设定'),
        ],
        stories: [st('s1', '无时间', '甲和乙在灯下对坐，谁都没有先开口说话。')],
      );
      expect(report.errorCount, greaterThan(0));
      expect(report.issues.first.severity, IssueSeverity.error);
      // 严重级别必须单调不增。
      for (var i = 1; i < report.issues.length; i++) {
        expect(report.issues[i - 1].severity.rank,
            greaterThanOrEqualTo(report.issues[i].severity.rank));
      }
    });

    test('空项目返回干净报告', () {
      final report = ConsistencyChecker.check(
        characters: const [],
        stories: const [],
      );
      expect(report.isEmpty, isTrue);
      expect(report.isClean, isTrue);
    });

    test('可按人物 / 情节 / 类别过滤', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲', birth: 1950)],
        stories: [st('s1', '早年', '甲还是个孩子。', year: 1940)],
      );
      expect(report.ofStory('s1'), isNotEmpty);
      expect(report.ofCharacter('a'), isNotEmpty);
      expect(report.ofCategory(IssueCategory.timeline), isNotEmpty);
      expect(report.ofCharacter('不存在'), isEmpty);
    });

    test('issue id 在同对象上稳定', () {
      final report = ConsistencyChecker.check(
        characters: [ch('a', '甲', birth: 1950)],
        stories: [st('s1', '早年', '甲还是个孩子。', year: 1940)],
      );
      final issue = withCode(report, 'story-before-birth').first;
      expect(issue.id, contains('story-before-birth'));
      expect(issue.id, contains('a'));
      expect(issue.id, contains('s1'));
    });
  });
}
