import 'package:storyatlas_core/storyatlas_core.dart';
import 'package:test/test.dart';

void main() {
  final cast = <Character>[
    Character(
        id: 'a', name: '沈砚秋', aliases: const ['砚秋'], traits: const ['沉稳']),
    Character(id: 'b', name: '顾清欢', traits: const ['果敢']),
  ];

  group('生成人物', () {
    test('解析标准 JSON 数组并补齐字段', () {
      const raw = '''
      [{"name":"苏婉娘","aliases":["婉娘"],"description":"绣娘",
        "traits":["隐忍","重情"],"appearance":"青衫","background":"绣坊长大",
        "goal":"护住家人","birthYear":1902,"deathYear":null}]
      ''';
      final chars = AiGenerator.parseCharacters(raw);
      expect(chars.length, 1);
      final c = chars.single;
      expect(c.name, '苏婉娘');
      expect(c.aliases, ['婉娘']);
      expect(c.traits, ['隐忍', '重情']);
      expect(c.goal, '护住家人');
      expect(c.birthYear, 1902);
      expect(c.deathYear, isNull);
      expect(c.id, isNotEmpty);
    });

    test('容忍 Markdown 代码块包裹', () {
      const raw = '```json\n[{"name":"甲"}]\n```';
      expect(AiGenerator.parseCharacters(raw).single.name, '甲');
    });

    test('跳过没有名字的条目', () {
      const raw = '[{"name":""},{"description":"无名"},{"name":"乙"}]';
      final chars = AiGenerator.parseCharacters(raw);
      expect(chars.length, 1);
      expect(chars.single.name, '乙');
    });

    test('非法输入返回空列表', () {
      expect(AiGenerator.parseCharacters('抱歉，我无法生成。'), isEmpty);
      expect(AiGenerator.parseCharacters('{"name":"甲"}'), isEmpty);
    });

    test('colorSeed 让配色错开', () {
      final chars = AiGenerator.parseCharacters(
        '[{"name":"甲"},{"name":"乙"},{"name":"丙"}]',
        colorSeed: 8,
      );
      expect(chars.map((c) => c.colorIndex).toList(), [8, 9, 0]);
    });

    test('提示词包含数量、题材与已有人物', () {
      final msgs = AiGenerator.buildCharacterMessages(
        existing: cast,
        premise: '民国小镇',
        requirements: '要一个反派',
        count: 2,
        yearHint: 1924,
      );
      expect(msgs.length, 2);
      expect(msgs.first['content'], contains('JSON'));
      expect(msgs.last['content'], contains('民国小镇'));
      expect(msgs.last['content'], contains('要一个反派'));
      expect(msgs.last['content'], contains('沈砚秋'));
      expect(msgs.last['content'], contains('1924'));
    });

    test('generateCharacters 调用注入的 chat 并返回人物', () async {
      final chars = await AiGenerator.generateCharacters(
        chat: (messages) async => '[{"name":"丙","traits":["狡黠"]}]',
        existing: cast,
        count: 1,
      );
      expect(chars.single.name, '丙');
      expect(chars.single.traits, ['狡黠']);
    });
  });

  group('生成情节', () {
    test('解析 JSON 对象并识别出场人物', () {
      const raw = '{"title":"雨夜","content":"沈砚秋与顾清欢在雨里对望。",'
          '"location":"长街","tags":["转折"]}';
      final story = AiGenerator.parseStory(raw, cast: cast);
      expect(story, isNotNull);
      expect(story!.title, '雨夜');
      expect(story.location, '长街');
      expect(story.tags, ['转折']);
      expect(story.characterIds, containsAll(<String>['a', 'b']));
    });

    test('优先使用 AI 返回的人物名映射 ID', () {
      const raw = '{"title":"x","content":"两人对坐。",'
          '"characterIds":["顾清欢"]}';
      final story = AiGenerator.parseStory(raw, cast: cast);
      expect(story!.characterIds, ['b']);
    });

    test('丢弃不存在的人物名', () {
      const raw = '{"title":"x","content":"两人对坐。",'
          '"characterIds":["查无此人","沈砚秋"]}';
      final story = AiGenerator.parseStory(raw, cast: cast);
      expect(story!.characterIds, ['a']);
    });

    test('正文为空返回 null', () {
      expect(AiGenerator.parseStory('{"title":"x","content":""}', cast: cast),
          isNull);
      expect(AiGenerator.parseStory('没有 JSON', cast: cast), isNull);
    });

    test('带入指定时间', () {
      final story = AiGenerator.parseStory(
        '{"title":"x","content":"沈砚秋来了。"}',
        cast: cast,
        time: DateTime(1927, 3, 1),
      );
      expect(story!.time, DateTime(1927, 3, 1));
    });

    test('提示词带上出场人物与已有情节', () {
      final msgs = AiGenerator.buildStoryMessages(
        cast: cast,
        existingStories: [
          Story(id: 's1', title: '旧篇', content: '从前有座山。'),
        ],
        requirements: '留下悬念',
        year: 1925,
      );
      expect(msgs.last['content'], contains('沈砚秋'));
      expect(msgs.last['content'], contains('旧篇'));
      expect(msgs.last['content'], contains('留下悬念'));
      expect(msgs.last['content'], contains('1925'));
    });
  });

  group('润色', () {
    test('剥离代码块包裹', () {
      expect(AiGenerator.parsePolished('```\n润色后的正文。\n```'), '润色后的正文。');
      expect(AiGenerator.parsePolished('直接就是正文。'), '直接就是正文。');
      expect(AiGenerator.parsePolished('```text\n正文\n```'), '正文');
    });

    test('polish 返回处理后的正文', () async {
      final out = await AiGenerator.polish(
        chat: (messages) async => '```\n更好的文字。\n```',
        content: '原来的文字。',
        cast: cast,
      );
      expect(out, '更好的文字。');
    });

    test('润色提示词包含正文与人物', () {
      final msgs = AiGenerator.buildPolishMessages(
        content: '原文',
        cast: cast,
        requirements: '更口语化',
      );
      expect(msgs.first['content'], contains('润色'));
      expect(msgs.last['content'], contains('原文'));
      expect(msgs.last['content'], contains('沈砚秋'));
      expect(msgs.last['content'], contains('更口语化'));
    });
  });
}
