import 'dart:math';

import 'package:storyatlas_core/storyatlas_core.dart';
import 'package:test/test.dart';

void main() {
  group('MindmapLayout', () {
    test('根节点位于原点，子节点分布在同一圆环上', () {
      final pos = MindmapLayout.compute(
        rootId: 'root',
        edges: const [
          MindmapEdge(parentId: 'root', childId: 'a', weight: 1),
          MindmapEdge(parentId: 'root', childId: 'b', weight: 2),
          MindmapEdge(parentId: 'root', childId: 'c', weight: 0.5),
        ],
        levelGap: 260,
      );
      expect(pos['root']!.x, closeTo(0, 1e-9));
      expect(pos['root']!.y, closeTo(0, 1e-9));
      for (final id in ['a', 'b', 'c']) {
        final r = _len(pos[id]!);
        expect(r, closeTo(260, 1e-6));
      }
    });

    test('权重高的子节点扇区更宽（与后邻夹角更大）', () {
      final pos = MindmapLayout.compute(
        rootId: 'root',
        edges: const [
          MindmapEdge(parentId: 'root', childId: 'heavy', weight: 10),
          MindmapEdge(parentId: 'root', childId: 'mid', weight: 1),
          MindmapEdge(parentId: 'root', childId: 'light', weight: 1),
        ],
      );
      // 顺时针顺序：heavy → mid → light（权重降序）。
      double angle(String id) => atan2(pos[id]!.y, pos[id]!.x);
      final gapHeavyMid = (angle('mid') - angle('heavy')) % (2 * pi);
      final gapMidLight = (angle('light') - angle('mid')) % (2 * pi);
      expect(gapHeavyMid, greaterThan(gapMidLight));
    });

    test('第二层节点距根更远且坐标有限', () {
      final pos = MindmapLayout.compute(
        rootId: 'root',
        edges: const [
          MindmapEdge(parentId: 'root', childId: 'a', weight: 2),
          MindmapEdge(parentId: 'a', childId: 'a1', weight: 1),
          MindmapEdge(parentId: 'a', childId: 'a2', weight: 1),
          MindmapEdge(parentId: 'root', childId: 'b', weight: 1),
          MindmapEdge(parentId: 'b', childId: 'b1', weight: 1),
        ],
        levelGap: 260,
      );
      expect(_len(pos['a']!), closeTo(260, 1e-6));
      expect(_len(pos['b']!), closeTo(260, 1e-6));
      expect(_len(pos['a1']!), closeTo(520, 1e-6));
      expect(_len(pos['b1']!), closeTo(520, 1e-6));
      for (final p in pos.values) {
        expect(p.x.isFinite && p.y.isFinite, isTrue);
      }
    });

    test('孤立节点返回自身于原点', () {
      final pos = MindmapLayout.compute(rootId: 'solo', edges: const []);
      expect(pos['solo']!.x, closeTo(0, 1e-9));
      expect(pos['solo']!.y, closeTo(0, 1e-9));
    });
  });
}

double _len(Point<double> p) => sqrt(p.x * p.x + p.y * p.y);
