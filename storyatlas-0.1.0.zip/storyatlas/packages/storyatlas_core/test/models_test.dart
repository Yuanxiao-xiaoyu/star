import 'dart:convert';

import 'package:storyatlas_core/storyatlas_core.dart';
import 'package:test/test.dart';

void main() {
  group('模型', () {
    test('Character JSON 往返一致', () {
      final c = Character(
        id: 'c1',
        name: '沈砚秋',
        aliases: const ['砚秋', '沈先生'],
        description: '青年记者',
        traits: const ['沉稳', '护短'],
        appearance: '青衫长身',
        background: '药庐学徒出身',
        goal: '查明旧案',
        birthYear: 1901,
        deathYear: 1980,
        colorIndex: 3,
        createdAt: DateTime.utc(2026, 1, 1),
      );
      final restored = Character.fromJson(
          jsonDecode(jsonEncode(c.toJson())) as Map<String, dynamic>);
      expect(restored.id, c.id);
      expect(restored.name, c.name);
      expect(restored.aliases, c.aliases);
      expect(restored.colorIndex, 3);
      expect(restored.searchNames, ['沈砚秋', '砚秋', '沈先生']);
      expect(restored.traits, ['沉稳', '护短']);
      expect(restored.appearance, '青衫长身');
      expect(restored.background, '药庐学徒出身');
      expect(restored.goal, '查明旧案');
      expect(restored.birthYear, 1901);
      expect(restored.deathYear, 1980);
    });

    test('旧版 JSON 缺少新字段时使用默认值', () {
      final restored = Character.fromJson(<String, dynamic>{
        'id': 'old',
        'name': '旧人物',
      });
      expect(restored.traits, isEmpty);
      expect(restored.appearance, '');
      expect(restored.birthYear, isNull);
    });

    test('copyWith 可以清除生卒年', () {
      final c = Character(id: 'c', name: '甲', birthYear: 1900, deathYear: 1950);
      final cleared = c.copyWith(clearBirthYear: true, clearDeathYear: true);
      expect(cleared.birthYear, isNull);
      expect(cleared.deathYear, isNull);
      expect(c.birthYear, 1900, reason: '原对象不应被修改');
    });

    test('Story 保留地点并参与 JSON 往返', () {
      final s = Story(
        id: 's1',
        title: '雨夜',
        content: '两人对望。',
        location: '长街',
        characterIds: const ['a', 'b'],
        tags: const ['转折'],
      );
      final restored = Story.fromJson(
          jsonDecode(jsonEncode(s.toJson())) as Map<String, dynamic>);
      expect(restored.location, '长街');
      expect(restored.characterIds, ['a', 'b']);
      expect(restored.tags, ['转折']);
    });

    test('Story 的 time 允许为空（未注明时间）', () {
      final s = Story(id: 's1', title: '无时间篇', content: '正文', time: null);
      expect(s.time, isNull);
      final json = s.toJson();
      expect(json['time'], isNull);
      final restored = Story.fromJson(json as Map<String, dynamic>);
      expect(restored.time, isNull);
    });

    test('Relation 方向性与箭头', () {
      final love = Relation(
        id: 'r1',
        fromId: 'a',
        toId: 'b',
        kind: RelationKind.love,
        source: RelationSource.auto,
        updatedAt: _epoch,
      );
      expect(love.kind.isDirected, isFalse);
      expect(love.arrow, '—');
      final enemy = Relation(
        id: 'r2',
        fromId: 'a',
        toId: 'b',
        kind: RelationKind.enemy,
        source: RelationSource.auto,
        updatedAt: _epoch,
      );
      expect(enemy.kind.isDirected, isTrue);
      expect(enemy.arrow, '→');
      // 无向配对键与顺序无关。
      expect(
        love.unorderedPairKey,
        Relation(
          id: 'x',
          fromId: 'b',
          toId: 'a',
          kind: RelationKind.love,
          source: RelationSource.auto,
          updatedAt: _epoch,
        ).unorderedPairKey,
      );
    });

    test('ProjectData 整体 JSON 往返', () {
      final data = ProjectData(
        characters: [
          Character(id: 'a', name: '甲'),
          Character(id: 'b', name: '乙', aliases: const ['阿乙']),
        ],
        stories: [
          Story(
            id: 's1',
            title: '相遇',
            time: DateTime.utc(1924, 3),
            content: '甲在药庐遇见了乙。',
            characterIds: const ['a', 'b'],
          ),
        ],
        relations: [
          Relation(
            id: 'r1',
            fromId: 'a',
            toId: 'b',
            kind: RelationKind.friendship,
            weight: 70,
            source: RelationSource.manual,
            note: '同窗',
            updatedAt: DateTime.utc(2026),
          ),
        ],
        ignoredPairs: const ['a\u0000b'],
      );
      final restored = ProjectData.fromJsonString(jsonEncode(data.toJson()));
      expect(restored.characters.length, 2);
      expect(restored.stories.single.characterIds, ['a', 'b']);
      expect(restored.relations.single.kind, RelationKind.friendship);
      expect(restored.ignoredPairs, ['a\u0000b']);
      expect(restored.aiSettings.useAi, isFalse);
    });

    test('非法 JSON 抛出 FormatException', () {
      expect(() => ProjectData.fromJsonString('不是 JSON'),
          throwsA(isA<FormatException>()));
    });
  });
}

final DateTime _epoch = DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
