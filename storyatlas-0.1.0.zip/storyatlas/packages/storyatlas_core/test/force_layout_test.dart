import 'dart:math';

import 'package:storyatlas_core/storyatlas_core.dart';
import 'package:test/test.dart';

void main() {
  group('ForceLayout', () {
    test('空边集返回空结果', () {
      const layout = ForceLayout();
      expect(layout.run(edges: const []), isEmpty);
    });

    test('单节点置于画布中心', () {
      const layout = ForceLayout(width: 800, height: 600);
      final pos = layout.run(edges: const [
        ForceEdge(a: 'only', b: 'only'),
      ]);
      // 单节点特殊处理。
      expect(pos['only'], isNotNull);
    });

    test('同一种子结果确定可复现', () {
      const edges = [
        ForceEdge(a: 'a', b: 'b', weight: 0.8),
        ForceEdge(a: 'b', b: 'c', weight: 0.4),
        ForceEdge(a: 'a', b: 'c', weight: 0.2),
      ];
      final p1 = const ForceLayout().run(edges: edges);
      final p2 = const ForceLayout().run(edges: edges);
      for (final id in ['a', 'b', 'c']) {
        expect(p1[id]!.x, p2[id]!.x);
        expect(p1[id]!.y, p2[id]!.y);
      }
    });

    test('全部位置有限且在画布范围内', () {
      const layout = ForceLayout(width: 1000, height: 720);
      final edges = <ForceEdge>[
        for (var i = 1; i < 8; i++)
          ForceEdge(a: 'n0', b: 'n$i', weight: i / 10),
        ForceEdge(a: 'n1', b: 'n2'),
        ForceEdge(a: 'n3', b: 'n4'),
      ];
      final pos = layout.run(edges: edges);
      expect(pos.length, 8);
      for (final p in pos.values) {
        expect(p.x.isFinite && p.y.isFinite, isTrue);
        expect(p.x, inInclusiveRange(0, layout.width));
        expect(p.y, inInclusiveRange(0, layout.height));
      }
    });

    test('相连节点比不相连节点靠得更近', () {
      const edges = [
        ForceEdge(a: 'a', b: 'b', weight: 1),
        ForceEdge(a: 'c', b: 'd', weight: 1),
      ];
      final pos = const ForceLayout().run(edges: edges);
      final ab = _dist(pos['a']!, pos['b']!);
      final ac = _dist(pos['a']!, pos['c']!);
      final ad = _dist(pos['a']!, pos['d']!);
      expect(ab, lessThan(ac));
      expect(ab, lessThan(ad));
    });

    test('高权重边比低权重边更近', () {
      const edges = [
        ForceEdge(a: 'hub', b: 'close', weight: 1),
        ForceEdge(a: 'hub', b: 'far', weight: 0.05),
      ];
      final pos = const ForceLayout().run(edges: edges);
      expect(
        _dist(pos['hub']!, pos['close']!),
        lessThan(_dist(pos['hub']!, pos['far']!)),
      );
    });

    test('pinned 节点保持近中心', () {
      const edges = [
        ForceEdge(a: 'p', b: 'a', weight: 1),
        ForceEdge(a: 'p', b: 'b', weight: 1),
        ForceEdge(a: 'p', b: 'c', weight: 1),
      ];
      const layout = ForceLayout(width: 1000, height: 720);
      final pos = layout.run(edges: edges, pinned: {'p'});
      final p = pos['p']!;
      // 归一化会整体平移，但 pinned 节点应离中心最近。
      final center = Point<double>(layout.width / 2, layout.height / 2);
      final pd = _dist(p, center);
      for (final id in ['a', 'b', 'c']) {
        expect(_dist(pos[id]!, center), greaterThan(pd));
      }
    });
  });
}

double _dist(Point<double> a, Point<double> b) {
  final dx = a.x - b.x;
  final dy = a.y - b.y;
  return sqrt(dx * dx + dy * dy);
}
