import 'package:storyatlas_core/storyatlas_core.dart';
import 'package:test/test.dart';

void main() {
  final characters = <Character>[
    Character(id: 'a', name: '沈砚秋'),
    Character(id: 'b', name: '顾清欢'),
  ];
  final stories = <Story>[
    Story(id: 's1', title: '灯会', content: '沈砚秋向顾清欢表白。'),
  ];

  group('buildMessages', () {
    test('包含系统提示、人物、故事与已有关联', () {
      final msgs = AiAnalyzer.buildMessages(
        characters: characters,
        stories: stories,
        known: [
          Relation(
            id: 'r1',
            fromId: 'a',
            toId: 'b',
            kind: RelationKind.friendship,
            source: RelationSource.manual,
            updatedAt: _epoch,
          ),
        ],
      );
      expect(msgs.length, 2);
      expect(msgs.first['role'], 'system');
      expect(msgs.first['content'], contains('JSON'));
      expect(msgs.last['content'], contains('沈砚秋'));
      expect(msgs.last['content'], contains('friendship'));
    });

    test('超长故事被截断', () {
      final long = Story(
        id: 's2',
        title: '长文',
        content: '字' * (AiAnalyzer.storyContentLimit + 500),
      );
      final msgs =
          AiAnalyzer.buildMessages(characters: characters, stories: [long]);
      expect(msgs.last['content']!.length,
          lessThan(AiAnalyzer.storyContentLimit + 200));
    });
  });

  group('parseResponse', () {
    test('解析标准 JSON 数组', () {
      const raw = '''
        [{"from":"a","to":"b","type":"love","weight":88,"reason":"灯会上表白"},
         {"from":"a","to":"b","type":"enemy","weight":10,"reason":"曾有过节"}]
      ''';
      final rels = AiAnalyzer.parseResponse(raw, now: _epoch);
      expect(rels.length, 2);
      expect(rels.first.kind, RelationKind.love);
      expect(rels.first.weight, 88);
      expect(rels.first.fromId, 'a');
      expect(rels.first.source, RelationSource.ai);
    });

    test('容忍 Markdown 代码块包裹', () {
      const raw = '''
      好的，分析结果如下：
      ```json
      [{"from":"a","to":"b","type":"master_apprentice","weight":70,"reason":"师从"}]
      ```
      以上。
      ''';
      final rels = AiAnalyzer.parseResponse(raw, now: _epoch);
      expect(rels.single.kind, RelationKind.masterApprentice);
    });

    test('支持中文类型标签与连字符写法', () {
      const raw =
          '[{"from":"a","to":"b","type":"师徒","weight":60,"reason":"拜师"}]';
      final rels = AiAnalyzer.parseResponse(raw, now: _epoch);
      expect(rels.single.kind, RelationKind.masterApprentice);
      const raw2 =
          '[{"from":"a","to":"b","type":"master-apprentice","weight":60,"reason":"拜师"}]';
      expect(AiAnalyzer.parseResponse(raw2, now: _epoch).single.kind,
          RelationKind.masterApprentice);
    });

    test('非法输入返回空列表而不抛异常', () {
      expect(AiAnalyzer.parseResponse('抱歉，我无法完成这个分析。', now: _epoch), isEmpty);
      expect(AiAnalyzer.parseResponse('{"a":1}', now: _epoch), isEmpty);
      expect(AiAnalyzer.parseResponse('[{"foo":"bar"}]', now: _epoch), isEmpty);
    });

    test('过滤缺失字段与自环', () {
      const raw = '''
        [{"from":"a","to":"b","type":"alliance","weight":50,"reason":"结盟"},
         {"from":"a","to":"a","type":"love","weight":90,"reason":"自恋"},
         {"from":"x","type":"love","weight":90,"reason":"缺 to"}]
      ''';
      final rels = AiAnalyzer.parseResponse(raw, now: _epoch);
      expect(rels.length, 1);
      expect(rels.single.kind, RelationKind.alliance);
    });

    test('analyze 组装消息并调用注入的 chat 函数', () async {
      final calls = <List<Map<String, String>>>[];
      final rels = await AiAnalyzer.analyze(
        chat: (messages) async {
          calls.add(messages);
          return '[{"from":"a","to":"b","type":"love","weight":90,"reason":"表白"}]';
        },
        characters: characters,
        stories: stories,
      );
      expect(calls.length, 1);
      expect(rels.single.kind, RelationKind.love);
    });
  });
}

final DateTime _epoch = DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
