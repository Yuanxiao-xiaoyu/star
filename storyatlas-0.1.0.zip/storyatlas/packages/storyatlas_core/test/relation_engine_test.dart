import 'package:storyatlas_core/storyatlas_core.dart';
import 'package:test/test.dart';

final DateTime _now = DateTime.utc(2026, 5, 1);

final Character _a = Character(id: 'a', name: '沈砚秋', aliases: const ['砚秋']);
final Character _b = Character(id: 'b', name: '赵铁山', aliases: const ['铁山']);
final Character _c = Character(id: 'c', name: '顾清欢');
final Character _d = Character(id: 'd', name: '刘捕头');

Story story(String id, String title, String content,
        {List<String> characterIds = const [], DateTime? time}) =>
    Story(
      id: id,
      title: title,
      content: content,
      characterIds: characterIds,
      time: time,
    );

void main() {
  group('提及识别 findMentions', () {
    test('识别正式名与别名，忽略大小写', () {
      final ms = RelationEngine.findMentions(
        '沈砚秋走在街上。砚秋回头看了一眼。Tom saw TOM.',
        [_a, Character(id: 't', name: 'Tom')],
      );
      expect(ms.where((m) => m.characterId == 'a').length, 2);
      expect(ms.where((m) => m.characterId == 't').length, 2);
    });

    test('同一人物重叠提及只保留最长者', () {
      // 「沈砚秋」与别名「砚秋」重叠时只算一次。
      final ms = RelationEngine.findMentions('沈砚秋转身离去', [_a]);
      expect(ms.length, 1);
      expect(ms.single.end - ms.single.start, 3);
    });
  });

  group('关联分析', () {
    test('同篇共现产生弱关联（其他），权重不低于阈值', () {
      final result = RelationEngine.analyze(
        characters: [_a, _b],
        stories: [
          story('s1', '码头', '沈砚秋在码头遇见了赵铁山。'),
        ],
        now: _now,
      );
      final rel = result.between('a', 'b');
      expect(rel, isNotNull);
      expect(rel!.kind, RelationKind.other);
      expect(
          rel.weight, greaterThanOrEqualTo(RelationEngine.minRelationWeight));
      expect(rel.source, RelationSource.auto);
    });

    test('不同故事中的人物不产生关联', () {
      final result = RelationEngine.analyze(
        characters: [_a, _b],
        stories: [
          story('s1', '一', '沈砚秋独自研读医书。'),
          story('s2', '二', '赵铁山独自押镖上路。'),
        ],
        now: _now,
      );
      expect(result.between('a', 'b'), isNull);
    });

    test('近距离共现权重大于远距离共现', () {
      final near = '沈砚秋与赵铁山并肩而行，一路谈笑。';
      final filler = List<String>.filled(60, '无关内容。').join();
      final far = '沈砚秋独自研读医书，$filler远处，赵铁山押镖上路。';
      final r1 = RelationEngine.analyze(
        characters: [_a, _b],
        stories: [story('s1', '近', near)],
        now: _now,
      ).between('a', 'b')!;
      final r2 = RelationEngine.analyze(
        characters: [_a, _b],
        stories: [story('s2', '远', far)],
        now: _now,
      ).between('a', 'b')!;
      expect(r1.weight, greaterThan(r2.weight));
    });

    test('关键词「杀」判定敌对，方向为 先提及 → 后提及', () {
      final result = RelationEngine.analyze(
        characters: [_a, _b],
        stories: [
          story('s3', '复仇', '沈砚秋发誓，当年赵铁山杀害了自己的父亲，此仇必报。'),
        ],
        now: _now,
      );
      final rel = result.between('a', 'b');
      expect(rel, isNotNull);
      expect(rel!.kind, RelationKind.enemy);
      expect(rel.fromId, 'a');
      expect(rel.toId, 'b');
    });

    test('关键词「师父」判定师徒，方向为师父 → 徒弟', () {
      final result = RelationEngine.analyze(
        characters: [_a, _b],
        stories: [
          story('s4', '拜师', '沈砚秋跪倒在地，拜赵铁山为师。'),
        ],
        now: _now,
      );
      final rel = result.between('a', 'b');
      expect(rel, isNotNull);
      expect(rel!.kind, RelationKind.masterApprentice);
      // 此处「拜赵铁山为师」：赵铁山为师父，沈砚秋为徒弟。
      expect(rel.fromId, 'b');
      expect(rel.toId, 'a');
    });

    test('「嫁」判定爱情且为无向关系', () {
      final result = RelationEngine.analyze(
        characters: [_a, _c],
        stories: [
          story('s5', '成亲', '上元灯会，沈砚秋终于把顾清欢娶进了门。'),
        ],
        now: _now,
      );
      final rel = result.between('a', 'c');
      expect(rel, isNotNull);
      expect(rel!.kind, RelationKind.love);
    });

    test('作者勾选的人物即使未在正文提名也计入共现', () {
      final result = RelationEngine.analyze(
        characters: [_a, _d],
        stories: [
          story('s6', '查案', '码头出了命案，众人议论纷纷。', characterIds: ['a', 'd']),
        ],
        now: _now,
      );
      expect(result.between('a', 'd'), isNotNull);
    });

    test('同一人物多次共现于多篇故事，权重更高', () {
      final single = RelationEngine.analyze(
        characters: [_a, _b],
        stories: [story('s1', '一', '沈砚秋在码头遇见了赵铁山。')],
        now: _now,
      ).between('a', 'b')!;
      final multi = RelationEngine.analyze(
        characters: [_a, _b],
        stories: [
          story('s1', '一', '沈砚秋在码头遇见了赵铁山。'),
          story('s2', '二', '沈砚秋与赵铁山再次对峙。'),
          story('s3', '三', '沈砚秋最终击败了赵铁山。'),
        ],
        now: _now,
      ).between('a', 'b')!;
      expect(multi.weight, greaterThan(single.weight));
      // 多篇出现「击败」等词，类型应为敌对。
      expect(multi.kind, RelationKind.enemy);
    });

    test('手动关系覆盖自动关系', () {
      final manual = Relation(
        id: 'm1',
        fromId: 'a',
        toId: 'b',
        kind: RelationKind.friendship,
        weight: 90,
        source: RelationSource.manual,
        note: '其实是挚友',
        updatedAt: _now,
      );
      final result = RelationEngine.analyze(
        characters: [_a, _b],
        stories: [story('s1', '对决', '沈砚秋在雨夜决斗中击败了赵铁山。')],
        manual: [manual],
        now: _now,
      );
      final rel = result.between('a', 'b');
      expect(rel, isNotNull);
      expect(rel!.source, RelationSource.manual);
      expect(rel.kind, RelationKind.friendship);
      expect(rel.weight, 90);
    });

    test('AI 关系覆盖自动但不覆盖手动', () {
      final aiRel = Relation(
        id: 'ai1',
        fromId: 'a',
        toId: 'b',
        kind: RelationKind.alliance,
        weight: 80,
        source: RelationSource.ai,
        note: '并肩作战',
        updatedAt: _now,
      );
      final manual = Relation(
        id: 'm1',
        fromId: 'a',
        toId: 'b',
        kind: RelationKind.enemy,
        weight: 70,
        source: RelationSource.manual,
        updatedAt: _now,
      );
      final withAi = RelationEngine.analyze(
        characters: [_a, _b],
        stories: [story('s1', '联手', '沈砚秋与赵铁山联手对敌。')],
        ai: [aiRel],
        now: _now,
      ).between('a', 'b')!;
      expect(withAi.source, RelationSource.ai);
      expect(withAi.kind, RelationKind.alliance);
      final withManual = RelationEngine.analyze(
        characters: [_a, _b],
        stories: [story('s1', '联手', '沈砚秋与赵铁山联手对敌。')],
        ai: [aiRel],
        manual: [manual],
        now: _now,
      ).between('a', 'b')!;
      expect(withManual.source, RelationSource.manual);
      expect(withManual.kind, RelationKind.enemy);
    });

    test('忽略列表屏蔽指定人对', () {
      final result = RelationEngine.analyze(
        characters: [_a, _b, _c],
        stories: [
          story('s1', '一', '沈砚秋遇见了赵铁山和顾清欢。'),
        ],
        ignoredPairs: {'a\u0000b'},
        now: _now,
      );
      expect(result.between('a', 'b'), isNull);
      expect(result.between('a', 'c'), isNotNull);
    });

    test('关键词归属过滤：干扰词离第三人更近时不计入', () {
      final result = RelationEngine.analyze(
        characters: [_a, _b, _c],
        stories: [
          story('s8', '威胁', '赵铁山派人威胁沈砚秋。顾清欢在远处看见了这一切。'),
        ],
        now: _now,
      );
      final rel = result.between('a', 'b')!;
      expect(rel.kind, RelationKind.enemy);
      expect(rel.fromId, 'b');
      expect(rel.toId, 'a');
      // 顾与二人仅共现，不因「威胁」产生误关联。
      expect(result.between('a', 'c')!.kind, RelationKind.other);
      expect(result.between('b', 'c')!.kind, RelationKind.other);
    });

    test('证据记录上下文片段与类型', () {
      final result = RelationEngine.analyze(
        characters: [_a, _b],
        stories: [
          story('s1', '复仇', '沈砚秋发誓，当年赵铁山杀害了自己的父亲。'),
        ],
        now: _now,
      );
      final ev = result.evidence.single;
      expect(ev.storyId, 's1');
      expect(ev.kind, RelationKind.enemy);
      expect(ev.snippet, contains('杀害'));
    });
  });
}
