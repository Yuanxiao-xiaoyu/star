/// 体检问题的严重级别。
enum IssueSeverity { info, warning, error }

extension IssueSeverityX on IssueSeverity {
  String get label => switch (this) {
        IssueSeverity.info => '提示',
        IssueSeverity.warning => '建议',
        IssueSeverity.error => '问题',
      };

  int get rank => switch (this) {
        IssueSeverity.info => 0,
        IssueSeverity.warning => 1,
        IssueSeverity.error => 2,
      };
}

/// 体检问题的类别。
enum IssueCategory { timeline, relation, character, story, duplicate }

extension IssueCategoryX on IssueCategory {
  String get label => switch (this) {
        IssueCategory.timeline => '时间线',
        IssueCategory.relation => '人物关系',
        IssueCategory.character => '人物设定',
        IssueCategory.story => '情节',
        IssueCategory.duplicate => '重复冲突',
      };
}

/// 一条体检结果：指出哪里可能不妥，并给出修改建议。
class StoryIssue {
  const StoryIssue({
    required this.code,
    required this.severity,
    required this.category,
    required this.title,
    required this.message,
    this.suggestion = '',
    this.characterIds = const <String>[],
    this.storyIds = const <String>[],
  });

  /// 规则代码，如 `appears-after-death`。
  final String code;

  final IssueSeverity severity;
  final IssueCategory category;

  /// 简短标题。
  final String title;

  /// 具体说明。
  final String message;

  /// 修改建议。
  final String suggestion;

  /// 涉及的人物。
  final List<String> characterIds;

  /// 涉及的故事。
  final List<String> storyIds;

  /// 稳定 ID（同类同对象只出现一次）。
  String get id => '$code|${characterIds.join(',')}|${storyIds.join(',')}';

  bool involvesCharacter(String id) => characterIds.contains(id);

  bool involvesStory(String id) => storyIds.contains(id);

  Map<String, Object?> toJson() => <String, Object?>{
        'code': code,
        'severity': severity.name,
        'category': category.name,
        'title': title,
        'message': message,
        'suggestion': suggestion,
        'characterIds': characterIds,
        'storyIds': storyIds,
      };

  @override
  String toString() => 'StoryIssue($code, ${severity.name}, $title)';
}

/// 一次完整体检的结果。
class CheckReport {
  const CheckReport(this.issues);

  final List<StoryIssue> issues;

  int get errorCount =>
      issues.where((i) => i.severity == IssueSeverity.error).length;

  int get warningCount =>
      issues.where((i) => i.severity == IssueSeverity.warning).length;

  int get infoCount =>
      issues.where((i) => i.severity == IssueSeverity.info).length;

  bool get isEmpty => issues.isEmpty;

  /// 是否一切正常（没有 error / warning）。
  bool get isClean => errorCount == 0 && warningCount == 0;

  List<StoryIssue> ofCharacter(String id) => <StoryIssue>[
        for (final i in issues)
          if (i.involvesCharacter(id)) i,
      ];

  List<StoryIssue> ofStory(String id) => <StoryIssue>[
        for (final i in issues)
          if (i.involvesStory(id)) i,
      ];

  List<StoryIssue> ofCategory(IssueCategory category) => <StoryIssue>[
        for (final i in issues)
          if (i.category == category) i,
      ];
}
