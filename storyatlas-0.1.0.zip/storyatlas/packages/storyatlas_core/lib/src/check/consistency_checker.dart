import '../analysis/relation_engine.dart';
import '../models/character.dart';
import '../models/relation.dart';
import '../models/story.dart';
import 'issue.dart';

/// 调性词表：用于「人物性格与行为不符」的检查。
///
/// 如果人物被设定为温和类性格，却在剧情中反复主动施暴，提示复核。
const List<String> gentleTraits = <String>[
  '温和',
  '温柔',
  '善良',
  '仁慈',
  '和善',
  '友善',
  '宽厚',
  '懦弱',
  '胆小',
  '心软',
  '慈悲',
  '文弱',
  '腼腆',
  '老实',
];

const List<String> harshTraits = <String>[
  '暴躁',
  '凶狠',
  '冷酷',
  '残暴',
  '狠辣',
  '好斗',
  '易怒',
  '暴虐',
  '嗜杀',
];

/// 互斥的关系类型：同一对人物出现两类证据时提示复核。
const List<List<RelationKind>> conflictingKinds = <List<RelationKind>>[
  <RelationKind>[RelationKind.love, RelationKind.enemy],
  <RelationKind>[RelationKind.friendship, RelationKind.enemy],
  <RelationKind>[RelationKind.family, RelationKind.enemy],
  <RelationKind>[RelationKind.alliance, RelationKind.enemy],
];

/// 剧情体检引擎：纯本地规则，确定性、可测试。
///
/// 它不会替你改写，只指出「哪里可能不合适」，并给出可执行的修改建议。
class ConsistencyChecker {
  const ConsistencyChecker._();

  /// 正文过短的阈值（字符数）。
  static const int shortContentThreshold = 20;

  static CheckReport check({
    required List<Character> characters,
    required List<Story> stories,
    List<Relation> manual = const <Relation>[],
    List<Relation> ai = const <Relation>[],
  }) {
    final issues = <StoryIssue>[];
    final charById = <String, Character>{for (final c in characters) c.id: c};

    _checkDuplicates(characters, issues);
    _checkCharacterYears(characters, issues);
    _checkPlacement(characters, stories, issues);
    _checkStories(stories, characters, charById, issues);
    _checkRelations(characters, stories, manual, ai, charById, issues);
    _checkTraits(characters, stories, charById, issues);

    issues.sort((a, b) {
      final bySeverity = b.severity.rank.compareTo(a.severity.rank);
      if (bySeverity != 0) return bySeverity;
      return a.category.index.compareTo(b.category.index);
    });
    return CheckReport(issues);
  }

  // ---- 重名与重复 ----

  static void _checkDuplicates(
      List<Character> characters, List<StoryIssue> issues) {
    final seen = <String, List<Character>>{};
    for (final c in characters) {
      for (final name in c.searchNames) {
        final key = name.trim();
        if (key.isEmpty) continue;
        seen.putIfAbsent(key, () => <Character>[]).add(c);
      }
    }
    for (final entry in seen.entries) {
      final owners = entry.value.map((c) => c.id).toSet().toList()..sort();
      if (owners.length < 2) continue;
      final names = owners
          .map((id) => characters.firstWhere((c) => c.id == id).name)
          .join('、');
      issues.add(StoryIssue(
        code: 'duplicate-name',
        severity: IssueSeverity.error,
        category: IssueCategory.duplicate,
        title: '「${entry.key}」被多个人物共用',
        message: '「${entry.key}」同时是 $names 的姓名或别名，'
            '正文里出现这个词时无法判断指的是谁。',
        suggestion: '给其中一个人物换一个别名，或在正文中改用更具区分度的称呼。',
        characterIds: owners,
      ));
    }
  }

  static void _checkCharacterYears(
      List<Character> characters, List<StoryIssue> issues) {
    for (final c in characters) {
      final birth = c.birthYear;
      final death = c.deathYear;
      if (birth != null && death != null && birth > death) {
        issues.add(StoryIssue(
          code: 'birth-after-death',
          severity: IssueSeverity.error,
          category: IssueCategory.timeline,
          title: '${c.name}的出生年晚于死亡年',
          message: '出生年 $birth 晚于死亡年 $death。',
          suggestion: '检查并修正这两个年份。',
          characterIds: <String>[c.id],
        ));
      }
      if (c.traits.isEmpty &&
          c.description.isEmpty &&
          c.background.isEmpty &&
          c.goal.isEmpty) {
        issues.add(StoryIssue(
          code: 'character-blank',
          severity: IssueSeverity.info,
          category: IssueCategory.character,
          title: '${c.name}还没有任何设定',
          message: '这个人物只有名字，没有性格、简介、背景或目标，'
              '后续体检与 AI 创作能参考的信息很少。',
          suggestion: '补充性格标签、目标或一段背景，让角色更立体。',
          characterIds: <String>[c.id],
        ));
      }
    }
  }

  // ---- 时间线 ----

  static void _checkPlacement(
    List<Character> characters,
    List<Story> stories,
    List<StoryIssue> issues,
  ) {
    final charById = <String, Character>{for (final c in characters) c.id: c};
    for (final s in stories) {
      final year = s.time?.year;
      if (year == null) continue;
      final ids = RelationEngine.findMentions(s.content, characters)
          .map((m) => m.characterId)
          .toSet()
        ..addAll(s.characterIds);
      for (final id in ids) {
        final c = charById[id];
        if (c == null) continue;
        final birth = c.birthYear;
        if (birth != null && year < birth) {
          issues.add(StoryIssue(
            code: 'story-before-birth',
            severity: IssueSeverity.error,
            category: IssueCategory.timeline,
            title: '${c.name}在出生前就出场了',
            message: '《${s.title}》发生在 $year 年，'
                '但${c.name}的出生年是 $birth 年。',
            suggestion: '调整故事时间，或修正${c.name}的出生年。',
            characterIds: <String>[id],
            storyIds: <String>[s.id],
          ));
        }
        final death = c.deathYear;
        if (death != null && year > death) {
          issues.add(StoryIssue(
            code: 'appears-after-death',
            severity: IssueSeverity.error,
            category: IssueCategory.timeline,
            title: '${c.name}去世后仍然出场',
            message: '《${s.title}》发生在 $year 年，'
                '但${c.name}已在 $death 年去世。',
            suggestion: '确认这是回忆 / 追述，还是故事时间写错了；'
                '如果是回忆，建议在正文里点明。',
            characterIds: <String>[id],
            storyIds: <String>[s.id],
          ));
        }
      }
    }

    // 同一时间点的多篇故事。
    final byYear = <int, List<Story>>{};
    for (final s in stories) {
      final y = s.time?.year;
      if (y == null) continue;
      byYear.putIfAbsent(y, () => <Story>[]).add(s);
    }
    for (final entry in byYear.entries) {
      if (entry.value.length < 2) continue;
      issues.add(StoryIssue(
        code: 'same-year-stories',
        severity: IssueSeverity.info,
        category: IssueCategory.timeline,
        title: '${entry.key} 年有 ${entry.value.length} 篇情节',
        message: '${entry.value.map((s) => '《${s.title}》').join('、')}'
            '都在 ${entry.key} 年，若发生在不同时间，建议补全月日。',
        suggestion: '为同一年的情节设置更精确的日期，时间线会更清晰。',
        storyIds: entry.value.map((s) => s.id).toList(growable: false),
      ));
    }
  }

  // ---- 情节本身 ----

  static void _checkStories(
    List<Story> stories,
    List<Character> characters,
    Map<String, Character> charById,
    List<StoryIssue> issues,
  ) {
    for (final s in stories) {
      if (s.time == null) {
        issues.add(StoryIssue(
          code: 'story-no-time',
          severity: IssueSeverity.info,
          category: IssueCategory.timeline,
          title: '《${s.title}》没有时间',
          message: '没设置发生时间的情节会排在时间线末尾，'
              '也无法参与时间矛盾检查。',
          suggestion: '为它选择一个发生时间。',
          storyIds: <String>[s.id],
        ));
      }
      if (s.content.trim().length < shortContentThreshold) {
        issues.add(StoryIssue(
          code: 'story-too-short',
          severity: IssueSeverity.warning,
          category: IssueCategory.story,
          title: '《${s.title}》内容过短',
          message: '正文少于 $shortContentThreshold 字，'
              '关系分析很难从中读到有效上下文。',
          suggestion: '补充情节细节，或把它并进相邻的一篇。',
          storyIds: <String>[s.id],
        ));
      }

      final mentioned = RelationEngine.findMentions(s.content, characters)
          .map((m) => m.characterId)
          .toSet();
      if (mentioned.isEmpty && s.characterIds.isEmpty) {
        issues.add(StoryIssue(
          code: 'story-without-characters',
          severity: IssueSeverity.warning,
          category: IssueCategory.story,
          title: '《${s.title}》里没有识别到人物',
          message: '正文没有出现任何已有人物的姓名或别名，也没有勾选关联人物。',
          suggestion: '在正文里写清出场人物，或勾选这篇涉及的关联人物。',
          storyIds: <String>[s.id],
        ));
      }

      // 勾选了但正文没提到。
      for (final id in s.characterIds) {
        final c = charById[id];
        if (c == null) continue;
        if (!mentioned.contains(id)) {
          issues.add(StoryIssue(
            code: 'marked-but-not-mentioned',
            severity: IssueSeverity.info,
            category: IssueCategory.story,
            title: '${c.name}被勾选，但正文没提到',
            message: '《${s.title}》勾选了${c.name}，'
                '但正文里找不到这个名字或别名。',
            suggestion: '在正文中写到他，或取消勾选以免影响关系分析。',
            characterIds: <String>[id],
            storyIds: <String>[s.id],
          ));
        }
      }
    }
  }

  // ---- 关系 ----

  static void _checkRelations(
    List<Character> characters,
    List<Story> stories,
    List<Relation> manual,
    List<Relation> ai,
    Map<String, Character> charById,
    List<StoryIssue> issues,
  ) {
    // 自动 / AI 分析结果，用于对比。
    final analysis = RelationEngine.analyze(
      characters: characters,
      stories: stories,
      manual: manual,
      ai: ai,
    );

    for (final r in <Relation>[...manual, ...ai]) {
      if (r.fromId == r.toId) {
        issues.add(StoryIssue(
          code: 'relation-self-loop',
          severity: IssueSeverity.error,
          category: IssueCategory.relation,
          title: '关系指向了自己',
          message: '${charById[r.fromId]?.name ?? r.fromId} 被设置成和自己的关系。',
          suggestion: '删除这条关系。',
          characterIds: <String>[r.fromId],
        ));
      }
      final from = charById[r.fromId];
      final to = charById[r.toId];
      if (from == null || to == null) {
        issues.add(StoryIssue(
          code: 'relation-dangling',
          severity: IssueSeverity.warning,
          category: IssueCategory.relation,
          title: '关系指向了不存在的人物',
          message: '有一条${r.kind.label}关系的人物已被删除。',
          suggestion: '删除这条关系。',
        ));
      }
    }

    // 师徒 / 上下级 互指（双向同一有向类型）。
    final all = <Relation>[...manual, ...ai];
    final directedKeys = <String>{
      for (final r in all)
        if (r.kind.isDirected) '${r.fromId}\u0000${r.toId}\u0000${r.kind.name}',
    };
    for (final r in all) {
      if (!r.kind.isDirected) continue;
      // 只从字典序较小的一方检查一次，避免重复上报。
      if (r.fromId.compareTo(r.toId) >= 0) continue;
      final reverse = '${r.toId}\u0000${r.fromId}\u0000${r.kind.name}';
      if (!directedKeys.contains(reverse)) continue;
      issues.add(StoryIssue(
        code: 'relation-mutual',
        severity: IssueSeverity.error,
        category: IssueCategory.relation,
        title: '两条关系互相指向',
        message: '${charById[r.fromId]?.name} 与 ${charById[r.toId]?.name} '
            '被同时设成彼此的${r.kind.label}。',
        suggestion: '有向关系通常只有一方是上位 / 主动方，删除其中一条。',
        characterIds: <String>[r.fromId, r.toId],
      ));
    }

    // 性格与行为：温和设定却频繁主动施暴。
    final enemyAsActor = <String, int>{};
    for (final r in analysis.relations) {
      if (r.kind == RelationKind.enemy && r.source != RelationSource.manual) {
        enemyAsActor[r.fromId] = (enemyAsActor[r.fromId] ?? 0) + 1;
      }
    }
    for (final entry in enemyAsActor.entries) {
      if (entry.value < 2) continue;
      final c = charById[entry.key];
      if (c == null) continue;
      final gentle = c.traits.where(gentleTraits.contains).toList();
      if (gentle.isEmpty) continue;
      issues.add(StoryIssue(
        code: 'trait-conflict',
        severity: IssueSeverity.warning,
        category: IssueCategory.character,
        title: '${c.name}的性格与行为不太一致',
        message: '${c.name}被设定为「${gentle.join('、')}」，'
            '但在 ${entry.value} 条敌对关系中是主动方。',
        suggestion: '要么补充转变的动机（如被逼到绝境），要么调整性格设定。',
        characterIds: <String>[c.id],
      ));
    }

    // 手动覆盖自动结果时提示。
    for (final r in manual) {
      final auto = analysis.evidence
          .where((e) =>
              (e.fromId == r.fromId && e.toId == r.toId) ||
              (e.fromId == r.toId && e.toId == r.fromId))
          .toList();
      if (auto.isEmpty) continue;
      final autoKinds = auto
          .map((e) => e.kind)
          .whereType<RelationKind>()
          .where((k) => k != RelationKind.other)
          .toSet();
      if (autoKinds.isEmpty) continue;
      if (autoKinds.contains(r.kind)) continue;
      issues.add(StoryIssue(
        code: 'manual-overrides-context',
        severity: IssueSeverity.info,
        category: IssueCategory.relation,
        title: '手动关系与正文不一致',
        message: '你把${charById[r.fromId]?.name}与'
            '${charById[r.toId]?.name}设为${r.kind.label}，'
            '但正文里更接近${autoKinds.map((k) => k.label).join('、')}。',
        suggestion: '如果这是刻意的反转（如反目成仇），可以在备注里写清来龙去脉。',
        characterIds: <String>[r.fromId, r.toId],
      ));
    }

    // 孤岛人物。
    for (final c in characters) {
      final inStory = stories.any((s) =>
          s.characterIds.contains(c.id) ||
          RelationEngine.findMentions(s.content, <Character>[c]).isNotEmpty);
      final inRelation = analysis.relations.any((r) => r.involves(c.id));
      if (!inStory && !inRelation) {
        issues.add(StoryIssue(
          code: 'orphan-character',
          severity: IssueSeverity.info,
          category: IssueCategory.character,
          title: '${c.name}还没有进入故事',
          message: '这个人物目前没有出现在任何情节里，也没有任何关系。',
          suggestion: '写一篇有他出场的情节，或把它关联到已有人物。',
          characterIds: <String>[c.id],
        ));
      }
    }
  }

  // ---- 性格一致性 ----

  static void _checkTraits(
    List<Character> characters,
    List<Story> stories,
    Map<String, Character> charById,
    List<StoryIssue> issues,
  ) {
    final analysis = RelationEngine.analyze(
      characters: characters,
      stories: stories,
    );
    // 同一对人物在不同篇章里出现互斥的类型。
    final kindsByPair = <String, Set<RelationKind>>{};
    for (final e in analysis.evidence) {
      final kind = e.kind;
      if (kind == null || kind == RelationKind.other) continue;
      final key = e.fromId.compareTo(e.toId) <= 0
          ? '${e.fromId}\u0000${e.toId}'
          : '${e.toId}\u0000${e.fromId}';
      kindsByPair.putIfAbsent(key, () => <RelationKind>{}).add(kind);
    }
    for (final entry in kindsByPair.entries) {
      final kinds = entry.value;
      for (final pair in conflictingKinds) {
        if (!kinds.contains(pair[0]) || !kinds.contains(pair[1])) continue;
        final parts = entry.key.split('\u0000');
        final n1 = charById[parts[0]]?.name ?? '?';
        final n2 = charById[parts[1]]?.name ?? '?';
        issues.add(StoryIssue(
          code: 'relation-kinds-conflict',
          severity: IssueSeverity.warning,
          category: IssueCategory.relation,
          title: '$n1 与 $n2 的关系前后矛盾',
          message: '正文里既有「${pair[0].label}」的证据，'
              '也有「${pair[1].label}」的证据。',
          suggestion: '如果这是剧情反转（如挚友反目），建议在转折处写清原因；'
              '否则可能是用词前后不一致。',
          characterIds: <String>[parts[0], parts[1]],
        ));
        break;
      }
    }

    // 性格标签自相矛盾。
    for (final c in characters) {
      final gentle = c.traits.where(gentleTraits.contains).toList();
      final harsh = c.traits.where(harshTraits.contains).toList();
      if (gentle.isEmpty || harsh.isEmpty) continue;
      issues.add(StoryIssue(
        code: 'trait-self-conflict',
        severity: IssueSeverity.warning,
        category: IssueCategory.character,
        title: '${c.name}的性格标签互相冲突',
        message: '同时标注了「${gentle.join('、')}」与「${harsh.join('、')}」。',
        suggestion: '如果这是多面性，建议改成更具体的描述，'
            '如「外表温和，对内人极为护短」。',
        characterIds: <String>[c.id],
      ));
    }
  }
}
