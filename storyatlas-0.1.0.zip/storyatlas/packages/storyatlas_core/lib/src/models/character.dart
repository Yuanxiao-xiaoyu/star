/// 一个虚构世界中的「人物」。
class Character {
  Character({
    required this.id,
    required this.name,
    List<String>? aliases,
    this.description = '',
    List<String>? traits,
    this.appearance = '',
    this.background = '',
    this.goal = '',
    this.birthYear,
    this.deathYear,
    this.colorIndex = 0,
    DateTime? createdAt,
  })  : aliases = aliases ?? const <String>[],
        traits = traits ?? const <String>[],
        createdAt = createdAt ?? DateTime.now();

  /// 唯一 ID。
  final String id;

  /// 正式名称。
  final String name;

  /// 别名 / 称呼（用于在故事正文中识别这个人物）。
  final List<String> aliases;

  /// 一句话简介。
  final String description;

  /// 性格 / 特点标签，如「沉稳」「多疑」「护短」。
  final List<String> traits;

  /// 外貌描写。
  final String appearance;

  /// 背景故事 / 出身经历。
  final String background;

  /// 目标 / 动机。
  final String goal;

  /// 出生年份（用于时间线体检，可为空）。
  final int? birthYear;

  /// 死亡年份（用于「死后出场」体检，可为空）。
  final int? deathYear;

  /// 界面配色索引（由 UI 层映射到颜色盘）。
  final int colorIndex;

  final DateTime createdAt;

  /// 参与识别匹配的全部名字（正式名 + 别名）。
  List<String> get searchNames => <String>[name, ...aliases];

  Character copyWith({
    String? name,
    List<String>? aliases,
    String? description,
    List<String>? traits,
    String? appearance,
    String? background,
    String? goal,
    int? birthYear,
    bool clearBirthYear = false,
    int? deathYear,
    bool clearDeathYear = false,
    int? colorIndex,
  }) {
    return Character(
      id: id,
      name: name ?? this.name,
      aliases: aliases ?? this.aliases,
      description: description ?? this.description,
      traits: traits ?? this.traits,
      appearance: appearance ?? this.appearance,
      background: background ?? this.background,
      goal: goal ?? this.goal,
      birthYear: clearBirthYear ? null : (birthYear ?? this.birthYear),
      deathYear: clearDeathYear ? null : (deathYear ?? this.deathYear),
      colorIndex: colorIndex ?? this.colorIndex,
      createdAt: createdAt,
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'name': name,
        'aliases': aliases,
        'description': description,
        'traits': traits,
        'appearance': appearance,
        'background': background,
        'goal': goal,
        'birthYear': birthYear,
        'deathYear': deathYear,
        'colorIndex': colorIndex,
        'createdAt': createdAt.toIso8601String(),
      };

  factory Character.fromJson(Map<String, dynamic> json) {
    return Character(
      id: json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      aliases: (json['aliases'] as List<dynamic>?)?.cast<String>(),
      description: json['description'] as String? ?? '',
      traits: (json['traits'] as List<dynamic>?)?.cast<String>(),
      appearance: json['appearance'] as String? ?? '',
      background: json['background'] as String? ?? '',
      goal: json['goal'] as String? ?? '',
      birthYear: (json['birthYear'] as num?)?.toInt(),
      deathYear: (json['deathYear'] as num?)?.toInt(),
      colorIndex: (json['colorIndex'] as num?)?.toInt() ?? 0,
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? ''),
    );
  }

  @override
  String toString() => 'Character($id, $name)';
}
