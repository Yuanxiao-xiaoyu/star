/// 一段情节 / 一个篇章。时间交际线以它为单位组织。
class Story {
  Story({
    required this.id,
    required this.title,
    this.time,
    required this.content,
    this.location = '',
    List<String>? characterIds,
    List<String>? tags,
    DateTime? createdAt,
  })  : characterIds = characterIds ?? const <String>[],
        tags = tags ?? const <String>[],
        createdAt = createdAt ?? DateTime.now();

  /// 唯一 ID。
  final String id;

  final String title;

  /// 情节发生时间（可选，为空则排在时间线末尾的「未注明时间」区）。
  final DateTime? time;

  /// 正文。人物关联与体检分析都基于它进行。
  final String content;

  /// 发生地点。
  final String location;

  /// 作者手动勾选的相关人物 ID（即使正文没提到名字也计入共现）。
  final List<String> characterIds;

  final List<String> tags;

  final DateTime createdAt;

  Story copyWith({
    String? title,
    DateTime? time,
    bool clearTime = false,
    String? content,
    String? location,
    List<String>? characterIds,
    List<String>? tags,
  }) {
    return Story(
      id: id,
      title: title ?? this.title,
      time: clearTime ? null : (time ?? this.time),
      content: content ?? this.content,
      location: location ?? this.location,
      characterIds: characterIds ?? this.characterIds,
      tags: tags ?? this.tags,
      createdAt: createdAt,
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'title': title,
        'time': time?.toIso8601String(),
        'content': content,
        'location': location,
        'characterIds': characterIds,
        'tags': tags,
        'createdAt': createdAt.toIso8601String(),
      };

  factory Story.fromJson(Map<String, dynamic> json) {
    return Story(
      id: json['id'] as String? ?? '',
      title: json['title'] as String? ?? '',
      time: DateTime.tryParse(json['time'] as String? ?? ''),
      content: json['content'] as String? ?? '',
      location: json['location'] as String? ?? '',
      characterIds: (json['characterIds'] as List<dynamic>?)?.cast<String>(),
      tags: (json['tags'] as List<dynamic>?)?.cast<String>(),
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? ''),
    );
  }

  @override
  String toString() => 'Story($id, $title)';
}
