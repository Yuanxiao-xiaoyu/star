import 'dart:math';

final Random _idRng = Random();

/// 生成唯一 ID，例如 `char-m2k3x9-8f3a2c`。
String newId([String prefix = 'id']) {
  final now = DateTime.now().microsecondsSinceEpoch.toRadixString(36);
  final rand = _idRng.nextInt(0xffffff).toRadixString(36);
  return '$prefix-$now-$rand';
}
