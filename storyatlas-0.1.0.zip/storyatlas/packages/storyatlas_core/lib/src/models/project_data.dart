import 'dart:convert';

import 'ai_settings.dart';
import 'character.dart';
import 'relation.dart';
import 'story.dart';

/// 整个图谱项目的数据容器，可整体序列化为 JSON。
class ProjectData {
  ProjectData({
    List<Character>? characters,
    List<Story>? stories,
    List<Relation>? relations,
    List<Relation>? aiRelations,
    AiSettings? aiSettings,
    List<String>? ignoredPairs,
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : characters = characters ?? <Character>[],
        stories = stories ?? <Story>[],
        relations = relations ?? <Relation>[],
        aiRelations = aiRelations ?? <Relation>[],
        aiSettings = aiSettings ?? const AiSettings(),
        ignoredPairs = ignoredPairs ?? <String>[],
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  static const int schemaVersion = 2;

  /// 全部人物。
  List<Character> characters;

  /// 全部故事（篇章）。
  List<Story> stories;

  /// 手动设定的人际关系（优先级最高）。
  List<Relation> relations;

  /// 最近一次 AI 分析产出的关系（优先级居中）。
  List<Relation> aiRelations;

  /// 用户屏蔽的自动关系（无向配对键列表）。
  List<String> ignoredPairs;

  AiSettings aiSettings;

  final DateTime createdAt;

  DateTime updatedAt;

  Character? characterById(String id) {
    for (final c in characters) {
      if (c.id == id) return c;
    }
    return null;
  }

  Story? storyById(String id) {
    for (final s in stories) {
      if (s.id == id) return s;
    }
    return null;
  }

  Map<String, Object?> toJson() => <String, Object?>{
        'schemaVersion': schemaVersion,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'aiSettings': aiSettings.toJson(),
        'characters': <Object?>[
          for (final c in characters) c.toJson(),
        ],
        'stories': <Object?>[
          for (final s in stories) s.toJson(),
        ],
        'relations': <Object?>[
          for (final r in relations) r.toJson(),
        ],
        'aiRelations': <Object?>[
          for (final r in aiRelations) r.toJson(),
        ],
        'ignoredPairs': ignoredPairs,
      };

  factory ProjectData.fromJson(Map<String, dynamic> json) {
    Map<String, dynamic> objOf(Object? v) =>
        v is Map<String, dynamic> ? v : const <String, dynamic>{};
    return ProjectData(
      characters: <Character>[
        for (final item in json['characters'] as List<dynamic>? ?? const [])
          Character.fromJson(objOf(item)),
      ],
      stories: <Story>[
        for (final item in json['stories'] as List<dynamic>? ?? const [])
          Story.fromJson(objOf(item)),
      ],
      relations: <Relation>[
        for (final item in json['relations'] as List<dynamic>? ?? const [])
          Relation.fromJson(objOf(item)),
      ],
      aiRelations: <Relation>[
        for (final item in json['aiRelations'] as List<dynamic>? ?? const [])
          Relation.fromJson(objOf(item)),
      ],
      ignoredPairs: (json['ignoredPairs'] as List<dynamic>?)?.cast<String>() ??
          const <String>[],
      aiSettings: AiSettings.fromJson(objOf(json['aiSettings'] as Object?)),
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ??
          DateTime.now(),
      updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  /// 带缩进的 JSON 文本（导出 / 保存用）。
  String exportJson() => const JsonEncoder.withIndent('  ').convert(toJson());

  /// 从 JSON 文本解析（导入用），格式非法时抛出 [FormatException]。
  static ProjectData fromJsonString(String source) {
    final decoded = jsonDecode(source);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('JSON 根节点必须是对象');
    }
    return ProjectData.fromJson(decoded);
  }
}
