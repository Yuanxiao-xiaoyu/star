/// 关系来源：手动设定 > AI 分析 > 本地规则自动推断。
enum RelationSource { manual, ai, auto }

extension RelationSourceX on RelationSource {
  String get label => switch (this) {
        RelationSource.manual => '手动',
        RelationSource.ai => 'AI',
        RelationSource.auto => '自动',
      };

  /// 合并时的优先级：手动最高。
  int get priority => switch (this) {
        RelationSource.manual => 3,
        RelationSource.ai => 2,
        RelationSource.auto => 1,
      };
}

/// 关系类型。
enum RelationKind {
  love,
  family,
  friendship,
  masterApprentice,
  colleague,
  superior,
  enemy,
  alliance,
  other,
}

extension RelationKindX on RelationKind {
  String get label => switch (this) {
        RelationKind.love => '爱情',
        RelationKind.family => '亲情',
        RelationKind.friendship => '友情',
        RelationKind.masterApprentice => '师徒',
        RelationKind.colleague => '同事',
        RelationKind.superior => '上下级',
        RelationKind.enemy => '敌对',
        RelationKind.alliance => '同盟',
        RelationKind.other => '其他',
      };

  /// 是否有方向性。有向关系 from → to 有意义
  /// （如师徒：from 为师父；上下级：from 为上级；敌对：from 为主动方）。
  bool get isDirected => switch (this) {
        RelationKind.masterApprentice ||
        RelationKind.superior ||
        RelationKind.enemy ||
        RelationKind.other =>
          true,
        _ => false,
      };
}

/// 两个人物之间的一条关系（关系网中的一条边）。
class Relation {
  const Relation({
    required this.id,
    required this.fromId,
    required this.toId,
    required this.kind,
    this.weight = 50,
    required this.source,
    this.note = '',
    required this.updatedAt,
  });

  final String id;

  /// 起点人物 ID（有向类型下指主动 / 上位一方）。
  final String fromId;

  /// 终点人物 ID。
  final String toId;

  final RelationKind kind;

  /// 亲密度 / 强度，0–100。
  final double weight;

  final RelationSource source;

  /// 证据片段或人工备注。
  final String note;

  final DateTime updatedAt;

  bool involves(String characterId) =>
      fromId == characterId || toId == characterId;

  /// 返回这条关系中另一端的 ID。
  String otherOf(String characterId) => fromId == characterId ? toId : fromId;

  /// 无向配对键（合并与查找用，与方向无关）。
  String get unorderedPairKey =>
      fromId.compareTo(toId) <= 0 ? '$fromId\u0000$toId' : '$toId\u0000$fromId';

  /// 展示用方向符：有向 →，无向 —。
  String get arrow => kind.isDirected ? '→' : '—';

  Relation copyWith({
    String? fromId,
    String? toId,
    RelationKind? kind,
    double? weight,
    RelationSource? source,
    String? note,
    DateTime? updatedAt,
  }) {
    return Relation(
      id: id,
      fromId: fromId ?? this.fromId,
      toId: toId ?? this.toId,
      kind: kind ?? this.kind,
      weight: weight ?? this.weight,
      source: source ?? this.source,
      note: note ?? this.note,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'fromId': fromId,
        'toId': toId,
        'kind': kind.name,
        'weight': weight,
        'source': source.name,
        'note': note,
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory Relation.fromJson(Map<String, dynamic> json) {
    return Relation(
      id: json['id'] as String? ?? '',
      fromId: json['fromId'] as String? ?? '',
      toId: json['toId'] as String? ?? '',
      kind: RelationKind.values.asNameMap()[json['kind'] as String?] ??
          RelationKind.other,
      weight: ((json['weight'] as num?)?.toDouble() ?? 50).clamp(0.0, 100.0),
      source: RelationSource.values.asNameMap()[json['source'] as String?] ??
          RelationSource.auto,
      note: json['note'] as String? ?? '',
      updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ??
          DateTime.now(),
    );
  }

  @override
  String toString() => 'Relation($fromId $arrow $toId, ${kind.label}, $weight)';
}
