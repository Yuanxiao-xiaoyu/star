/// 可选 AI 分析的连接配置（OpenAI 兼容接口）。
class AiSettings {
  const AiSettings({
    this.useAi = false,
    this.baseUrl = 'https://api.deepseek.com/v1',
    this.apiKey = '',
    this.model = 'deepseek-chat',
  });

  /// 是否启用 AI 语义分析（关闭时仅使用本地规则）。
  final bool useAi;

  /// OpenAI 兼容接口地址，如 https://api.deepseek.com/v1
  final String baseUrl;

  final String apiKey;

  final String model;

  AiSettings copyWith({
    bool? useAi,
    String? baseUrl,
    String? apiKey,
    String? model,
  }) {
    return AiSettings(
      useAi: useAi ?? this.useAi,
      baseUrl: baseUrl ?? this.baseUrl,
      apiKey: apiKey ?? this.apiKey,
      model: model ?? this.model,
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
        'useAi': useAi,
        'baseUrl': baseUrl,
        'apiKey': apiKey,
        'model': model,
      };

  factory AiSettings.fromJson(Map<String, dynamic> json) {
    return AiSettings(
      useAi: json['useAi'] as bool? ?? false,
      baseUrl: json['baseUrl'] as String? ?? 'https://api.deepseek.com/v1',
      apiKey: json['apiKey'] as String? ?? '',
      model: json['model'] as String? ?? 'deepseek-chat',
    );
  }
}
