import 'dart:math';

/// 思维导图树中的一条父子连线。
class MindmapEdge {
  const MindmapEdge({
    required this.parentId,
    required this.childId,
    this.weight = 1,
  });

  final String parentId;
  final String childId;

  /// 分支权重，越大则占据的扇区越宽。
  final double weight;
}

/// 思维视图的径向树布局。
///
/// 根节点位于中心；每一层节点分布在以根为圆心的同心圆环上，
/// 扇区大小与关系权重成正比，权重高的分支排在前面（从正上方起顺时针）。
class MindmapLayout {
  const MindmapLayout._();

  static Map<String, Point<double>> compute({
    required String rootId,
    required List<MindmapEdge> edges,
    double levelGap = 260,
  }) {
    final children = <String, List<MindmapEdge>>{};
    for (final e in edges) {
      children.putIfAbsent(e.parentId, () => <MindmapEdge>[]).add(e);
    }
    final pos = <String, Point<double>>{};

    void place(String id, int depth, double a0, double a1) {
      final angle = (a0 + a1) / 2;
      pos[id] = Point<double>(
        depth * levelGap * cos(angle),
        depth * levelGap * sin(angle),
      );
      final kids = children[id] ?? const <MindmapEdge>[];
      if (kids.isEmpty) return;
      final sorted = <MindmapEdge>[...kids]
        ..sort((x, y) => y.weight.compareTo(x.weight));
      final total = sorted.fold<double>(0, (s, e) => s + max(e.weight, 0.05));
      var cur = a0;
      for (final kid in sorted) {
        final span = (a1 - a0) * (max(kid.weight, 0.05) / total);
        place(kid.childId, depth + 1, cur, min(cur + span, a1));
        cur += span;
      }
    }

    // 从正上方开始，逆时针绕行一周。
    place(rootId, 0, -pi / 2, 3 * pi / 2);
    return pos;
  }
}
