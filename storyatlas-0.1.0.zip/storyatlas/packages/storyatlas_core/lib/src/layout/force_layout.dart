import 'dart:math';

/// 关系网中的一条边。
class ForceEdge {
  const ForceEdge({
    required this.a,
    required this.b,
    this.weight = 0.5,
  });

  final String a;
  final String b;

  /// 边权重 0–1，越大则理想距离越近（关系越紧密）。
  final double weight;

  String get key => a.compareTo(b) <= 0 ? '$a\u0000$b' : '$b\u0000$a';

  bool involves(String id) => a == id || b == id;
}

/// 力导向布局（Fruchterman-Reingold 变体）。
///
/// 纯 Dart 实现，无第三方依赖；随机种子固定时结果确定，便于测试与复现。
class ForceLayout {
  const ForceLayout({
    this.width = 1000,
    this.height = 720,
    this.iterations = 300,
    this.seed = 42,
  });

  final double width;
  final double height;
  final int iterations;
  final int seed;

  /// 计算所有节点位置。
  ///
  /// [edges] 为关系网的全部边；[pinned] 中的节点保持初始位置（近中心）
  /// 不动，用于「聚焦某人物」的场景。
  Map<String, Point<double>> run({
    required List<ForceEdge> edges,
    Set<String> pinned = const <String>{},
  }) {
    final rng = Random(seed);
    final ids = <String>{
      for (final e in edges) ...[e.a, e.b]
    };
    final n = ids.length;
    if (n == 0) return const <String, Point<double>>{};
    if (n == 1) {
      return <String, Point<double>>{
        ids.first: Point<double>(width / 2, height / 2),
      };
    }

    final half = min(width, height) / 2;
    final pos = <String, Point<double>>{
      for (final id in ids)
        id: Point<double>(
          width / 2 + (rng.nextDouble() - 0.5) * half,
          height / 2 + (rng.nextDouble() - 0.5) * half,
        ),
    };
    if (pinned.isNotEmpty) {
      for (final id in pinned) {
        pos[id] = Point<double>(width / 2, height / 2);
      }
    }

    final area = width * height;
    final k = sqrt(area / max(n, 1));
    var temp = min(width, height) * 0.08;

    for (var iter = 0; iter < iterations; iter++) {
      final disp = <String, Point<double>>{
        for (final id in ids) id: const Point<double>(0, 0),
      };
      final list = ids.toList();

      // 斥力：任意两节点之间。
      for (var i = 0; i < list.length; i++) {
        for (var j = i + 1; j < list.length; j++) {
          final a = list[i];
          final b = list[j];
          var dx = pos[a]!.x - pos[b]!.x;
          var dy = pos[a]!.y - pos[b]!.y;
          var d = sqrt(dx * dx + dy * dy);
          if (d < 0.01) {
            dx = rng.nextDouble() - 0.5;
            dy = rng.nextDouble() - 0.5;
            d = 0.01;
          }
          final f = (k * k) / d;
          disp[a] = disp[a]! + Point<double>(dx / d * f, dy / d * f);
          disp[b] = disp[b]! - Point<double>(dx / d * f, dy / d * f);
        }
      }

      // 引力：沿边，权重越高理想距离越短。
      for (final e in edges) {
        final a = e.a;
        final b = e.b;
        final pa = pos[a];
        final pb = pos[b];
        if (pa == null || pb == null) continue;
        final dx = pa.x - pb.x;
        final dy = pa.y - pb.y;
        final d = max(sqrt(dx * dx + dy * dy), 0.01);
        final w = e.weight.clamp(0.0, 1.0);
        final ideal = k * (1.9 - 1.3 * w);
        final f = min((d * d) / ideal, 6 * k);
        disp[a] = disp[a]! - Point<double>(dx / d * f, dy / d * f);
        disp[b] = disp[b]! + Point<double>(dx / d * f, dy / d * f);
      }

      // 位移 + 微弱向心力，避免整体漂移。
      for (final id in ids) {
        if (pinned.contains(id)) continue;
        var d = disp[id]!;
        final len = sqrt(d.x * d.x + d.y * d.y);
        if (len > temp) {
          d = Point<double>(d.x / len * temp, d.y / len * temp);
        }
        final next = pos[id]! + d;
        pos[id] = Point<double>(
          next.x - (next.x - width / 2) * 0.02,
          next.y - (next.y - height / 2) * 0.02,
        );
      }
      temp *= 0.95;
    }

    return _normalize(pos);
  }

  Map<String, Point<double>> _normalize(Map<String, Point<double>> pos) {
    const margin = 70.0;
    var minX = double.infinity;
    var maxX = -double.infinity;
    var minY = double.infinity;
    var maxY = -double.infinity;
    for (final p in pos.values) {
      minX = min(minX, p.x);
      maxX = max(maxX, p.x);
      minY = min(minY, p.y);
      maxY = max(maxY, p.y);
    }
    final bw = max(maxX - minX, 1.0);
    final bh = max(maxY - minY, 1.0);
    final targetW = max(width - margin * 2, 10.0);
    final targetH = max(height - margin * 2, 10.0);
    final scale = min(targetW / bw, targetH / bh);
    final cx = (minX + maxX) / 2;
    final cy = (minY + maxY) / 2;
    return <String, Point<double>>{
      for (final e in pos.entries)
        e.key: Point<double>(
          (e.value.x - cx) * scale + width / 2,
          (e.value.y - cy) * scale + height / 2,
        ),
    };
  }
}
