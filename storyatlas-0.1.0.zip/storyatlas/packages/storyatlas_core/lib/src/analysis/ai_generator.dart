import 'dart:convert';

import '../models/character.dart';
import '../models/ids.dart';
import '../models/story.dart';
import 'ai_analyzer.dart' show ChatFn;

/// AI 创作：根据用户的设定与要求，自动生成人物、情节或润色文本。
///
/// 与 [AiAnalyzer] 一样只负责「构造提示词 + 容错解析」，
/// 真正的 HTTP 调用由宿主注入的 [ChatFn] 完成。
class AiGenerator {
  const AiGenerator._();

  // ---------------- 生成人物 ----------------

  static const String characterSystemPrompt = '你是一位资深的小说角色设计师。'
      '请根据用户给出的题材与要求设计人物。'
      '只输出一个 JSON 数组，不要输出解释文字或 Markdown 代码块。'
      '数组元素格式：'
      '{"name":"姓名","aliases":["别名"],"description":"一句话简介",'
      '"traits":["性格标签","性格标签"],"appearance":"外貌",'
      '"background":"背景经历","goal":"目标或动机",'
      '"birthYear":出生年份或null,"deathYear":去世年份或null}。'
      '人物之间要有区分度，避免雷同；信息缺失时留空字符串或 null，不要编造与用户设定冲突的内容。';

  static List<Map<String, String>> buildCharacterMessages({
    required List<Character> existing,
    String premise = '',
    String requirements = '',
    int count = 3,
    int? yearHint,
  }) {
    final payload = <String, Object?>{
      'count': count,
      'premise': premise,
      'requirements': requirements,
      if (yearHint != null) 'story_year_hint': yearHint,
      'existing_characters': <Object?>[
        for (final c in existing)
          <String, Object?>{
            'name': c.name,
            'traits': c.traits,
            'description': c.description,
            'goal': c.goal,
          },
      ],
    };
    return <Map<String, String>>[
      <String, String>{'role': 'system', 'content': characterSystemPrompt},
      <String, String>{'role': 'user', 'content': jsonEncode(payload)},
    ];
  }

  /// 解析人物数组；无法解析时返回空列表。
  static List<Character> parseCharacters(
    String raw, {
    int colorSeed = 0,
  }) {
    final arr = _extractArray(raw);
    if (arr == null) return const <Character>[];
    final out = <Character>[];
    for (final item in arr) {
      if (item is! Map<String, dynamic>) continue;
      final name = (item['name'] as String?)?.trim() ?? '';
      if (name.isEmpty) continue;
      out.add(Character(
        id: newId('char'),
        name: name,
        aliases: _stringList(item['aliases']),
        description: (item['description'] as String?)?.trim() ?? '',
        traits: _stringList(item['traits']),
        appearance: (item['appearance'] as String?)?.trim() ?? '',
        background: (item['background'] as String?)?.trim() ?? '',
        goal: (item['goal'] as String?)?.trim() ?? '',
        birthYear: _intOrNull(item['birthYear']),
        deathYear: _intOrNull(item['deathYear']),
        colorIndex: (colorSeed + out.length) % 10,
      ));
    }
    return out;
  }

  static Future<List<Character>> generateCharacters({
    required ChatFn chat,
    required List<Character> existing,
    String premise = '',
    String requirements = '',
    int count = 3,
    int? yearHint,
    int colorSeed = 0,
  }) async {
    final raw = await chat(buildCharacterMessages(
      existing: existing,
      premise: premise,
      requirements: requirements,
      count: count,
      yearHint: yearHint,
    ));
    return parseCharacters(raw, colorSeed: colorSeed);
  }

  // ---------------- 生成情节 ----------------

  static const String storySystemPrompt = '你是一位擅长情节铺陈的小说作者。'
      '请严格使用给定的出场人物（姓名原样出现），不要引入未列出的人物。'
      '只输出一个 JSON 对象，不要输出解释文字或 Markdown 代码块。'
      '格式：{"title":"标题","content":"正文，300到600字","location":"地点",'
      '"tags":["标签"]}。'
      '正文要自然地把人物写进冲突或关系中，便于读者理解。';

  static List<Map<String, String>> buildStoryMessages({
    required List<Character> cast,
    required List<Story> existingStories,
    String requirements = '',
    String premise = '',
    int? year,
    int? targetLength,
  }) {
    final payload = <String, Object?>{
      'cast': <Object?>[
        for (final c in cast)
          <String, Object?>{
            'name': c.name,
            'aliases': c.aliases,
            'traits': c.traits,
            'goal': c.goal,
            'background': c.background,
          },
      ],
      'requirements': requirements,
      'premise': premise,
      if (year != null) 'year': year,
      if (targetLength != null) 'target_length': targetLength,
      'previous_stories': <Object?>[
        for (final s in existingStories)
          <String, Object?>{
            'title': s.title,
            'year': s.time?.year,
            'summary': s.content.length <= 200
                ? s.content
                : '${s.content.substring(0, 200)}…',
          },
      ],
    };
    return <Map<String, String>>[
      <String, String>{'role': 'system', 'content': storySystemPrompt},
      <String, String>{'role': 'user', 'content': jsonEncode(payload)},
    ];
  }

  /// 解析单篇情节；失败返回 null。
  static Story? parseStory(
    String raw, {
    required List<Character> cast,
    DateTime? time,
  }) {
    final obj = _extractObject(raw);
    if (obj == null) return null;
    final content = (obj['content'] as String?)?.trim() ?? '';
    if (content.isEmpty) return null;
    final title = (obj['title'] as String?)?.trim();
    return Story(
      id: newId('story'),
      title: title == null || title.isEmpty ? '未命名情节' : title,
      content: content,
      time: time,
      location: (obj['location'] as String?)?.trim() ?? '',
      characterIds: _stringList(obj['characterIds']).isNotEmpty
          ? _matchIds(_stringList(obj['characterIds']), cast)
          : _matchIdsFromContent(content, cast),
      tags: _stringList(obj['tags']),
    );
  }

  static Future<Story?> generateStory({
    required ChatFn chat,
    required List<Character> cast,
    required List<Story> existingStories,
    String requirements = '',
    String premise = '',
    DateTime? time,
  }) async {
    final raw = await chat(buildStoryMessages(
      cast: cast,
      existingStories: existingStories,
      requirements: requirements,
      premise: premise,
      year: time?.year,
    ));
    return parseStory(raw, cast: cast, time: time);
  }

  // ---------------- 润色 ----------------

  static const String polishSystemPrompt = '你是一位文字编辑。'
      '请在保持原意与人物设定的前提下润色下面这段小说正文：'
      '修正语病、增强画面感、统一人称与语气。只输出润色后的正文本身，'
      '不要输出解释、标题或 Markdown 代码块。';

  static List<Map<String, String>> buildPolishMessages({
    required String content,
    required List<Character> cast,
    String requirements = '',
  }) {
    final payload = <String, Object?>{
      'content': content,
      'cast': <Object?>[
        for (final c in cast)
          <String, Object?>{'name': c.name, 'traits': c.traits},
      ],
      'requirements': requirements,
    };
    return <Map<String, String>>[
      <String, String>{'role': 'system', 'content': polishSystemPrompt},
      <String, String>{'role': 'user', 'content': jsonEncode(payload)},
    ];
  }

  /// 从回复中提取正文（去掉可能包裹的代码块）。
  static String parsePolished(String raw) {
    var text = raw.trim();
    final fence = RegExp(r'^```[a-zA-Z]*\s*');
    if (fence.hasMatch(text)) {
      text = text.replaceFirst(fence, '');
      final end = text.lastIndexOf('```');
      if (end >= 0) text = text.substring(0, end);
    }
    return text.trim();
  }

  static Future<String> polish({
    required ChatFn chat,
    required String content,
    required List<Character> cast,
    String requirements = '',
  }) async {
    final raw = await chat(buildPolishMessages(
      content: content,
      cast: cast,
      requirements: requirements,
    ));
    return parsePolished(raw);
  }

  // ---------------- 解析辅助 ----------------

  static List<dynamic>? _extractArray(String raw) {
    final text = _stripFence(raw);
    final start = text.indexOf('[');
    final end = text.lastIndexOf(']');
    if (start < 0 || end <= start) return null;
    try {
      final decoded = jsonDecode(text.substring(start, end + 1));
      return decoded is List<dynamic> ? decoded : null;
    } catch (_) {
      return null;
    }
  }

  static Map<String, dynamic>? _extractObject(String raw) {
    final text = _stripFence(raw);
    final start = text.indexOf('{');
    final end = text.lastIndexOf('}');
    if (start < 0 || end <= start) return null;
    try {
      final decoded = jsonDecode(text.substring(start, end + 1));
      return decoded is Map<String, dynamic> ? decoded : null;
    } catch (_) {
      return null;
    }
  }

  static String _stripFence(String raw) {
    var text = raw.trim();
    final fence = RegExp(r'^```[a-zA-Z]*\s*');
    if (fence.hasMatch(text)) text = text.replaceFirst(fence, '');
    if (text.endsWith('```')) {
      text = text.substring(0, text.length - 3);
    }
    return text.trim();
  }

  static List<String> _stringList(Object? value) {
    if (value is List<dynamic>) {
      return <String>[
        for (final v in value)
          if (v is String && v.trim().isNotEmpty) v.trim(),
      ];
    }
    if (value is String && value.trim().isNotEmpty) {
      return value
          .split(RegExp(r'[、,，\s]+'))
          .where((s) => s.trim().isNotEmpty)
          .map((s) => s.trim())
          .toList(growable: false);
    }
    return const <String>[];
  }

  static int? _intOrNull(Object? value) {
    if (value is num) return value.toInt();
    if (value is String) return int.tryParse(value.trim());
    return null;
  }

  /// 把名字映射回人物 ID（丢弃不存在的人）。
  static List<String> _matchIds(List<String> names, List<Character> cast) {
    final out = <String>[];
    for (final name in names) {
      for (final c in cast) {
        if (c.searchNames.contains(name) && !out.contains(c.id)) {
          out.add(c.id);
        }
      }
    }
    return out;
  }

  /// 从正文里识别出场人物。
  static List<String> _matchIdsFromContent(
      String content, List<Character> cast) {
    final out = <String>[];
    for (final c in cast) {
      if (c.searchNames.any(content.contains)) out.add(c.id);
    }
    return out;
  }
}
