import 'dart:convert';

import '../models/character.dart';
import '../models/ids.dart';
import '../models/relation.dart';
import '../models/story.dart';

/// 注入式对话函数：输入 messages（OpenAI 格式），返回模型回复文本。
/// 由宿主（Flutter 应用）提供 HTTP 实现，核心包保持零运行时依赖。
typedef ChatFn = Future<String> Function(List<Map<String, String>> messages);

/// 可选 AI 语义分析：把人物与故事交给大模型，从上下文判断人物关系。
class AiAnalyzer {
  const AiAnalyzer._();

  /// 单篇故事送入模型的最大字符数（避免超长上下文）。
  static const int storyContentLimit = 2000;

  static const String systemPrompt = '你是一位严谨的小说人物关系分析专家。'
      '我会给你人物列表和故事原文，请你结合上下文判断人物之间的真实关系。'
      '只输出一个 JSON 数组，不要输出任何解释文字或 Markdown 代码块。'
      '数组元素格式：'
      '{"from":"人物id","to":"人物id","type":"类型","weight":0到100的整数,'
      '"reason":"不超过40字的原文依据"}。'
      'type 只能取：love(爱情)、family(亲情)、friendship(友情)、'
      'master_apprentice(师徒，from为师父)、colleague(同事)、'
      'superior(上下级，from为上级)、enemy(敌对，from为主动方)、'
      'alliance(同盟)、other(其他)。'
      '只输出有明确原文依据的关系，没有把握的不要输出。';

  /// 构造发给模型的 messages。
  static List<Map<String, String>> buildMessages({
    required List<Character> characters,
    required List<Story> stories,
    List<Relation> known = const <Relation>[],
  }) {
    final payload = <String, Object?>{
      'characters': <Object?>[
        for (final c in characters)
          <String, Object?>{
            'id': c.id,
            'name': c.name,
            'aliases': c.aliases,
            'description': c.description,
          },
      ],
      'stories': <Object?>[
        for (final s in stories)
          <String, Object?>{
            'id': s.id,
            'title': s.title,
            'content': s.content.length <= storyContentLimit
                ? s.content
                : s.content.substring(0, storyContentLimit),
          },
      ],
      'known_relations': <Object?>[
        for (final r in known)
          <String, Object?>{
            'from': r.fromId,
            'to': r.toId,
            'type': r.kind.name
          },
      ],
    };
    return <Map<String, String>>[
      <String, String>{'role': 'system', 'content': systemPrompt},
      <String, String>{'role': 'user', 'content': jsonEncode(payload)},
    ];
  }

  /// 从容错解析模型回复中提取关系列表；失败返回空列表（不抛异常）。
  static List<Relation> parseResponse(
    String raw, {
    DateTime? now,
    String idPrefix = 'ai',
  }) {
    final stamp = now ?? DateTime.now();
    final text = raw.trim();
    final start = text.indexOf('[');
    final end = text.lastIndexOf(']');
    if (start < 0 || end <= start) return const <Relation>[];
    List<dynamic> arr;
    try {
      arr = jsonDecode(text.substring(start, end + 1)) as List<dynamic>;
    } catch (_) {
      return const <Relation>[];
    }
    final out = <Relation>[];
    for (final item in arr) {
      if (item is! Map<String, dynamic>) continue;
      final from = item['from'];
      final to = item['to'];
      if (from is! String || to is! String) continue;
      if (from.isEmpty || to.isEmpty || from == to) continue;
      final kind = _parseKind(item['type']);
      final weight =
          ((item['weight'] as num?)?.toDouble() ?? 60).clamp(0.0, 100.0);
      final reason =
          item['reason'] is String ? (item['reason'] as String).trim() : '';
      out.add(Relation(
        id: newId('$idPrefix-${out.length}'),
        fromId: from,
        toId: to,
        kind: kind,
        weight: weight,
        source: RelationSource.ai,
        note: reason.isEmpty ? 'AI 判定' : reason,
        updatedAt: stamp,
      ));
    }
    return out;
  }

  /// 调用对话函数完成一次分析；失败时抛出，由调用方兜底降级到本地规则。
  static Future<List<Relation>> analyze({
    required ChatFn chat,
    required List<Character> characters,
    required List<Story> stories,
    List<Relation> known = const <Relation>[],
  }) async {
    final messages =
        buildMessages(characters: characters, stories: stories, known: known);
    final raw = await chat(messages);
    return parseResponse(raw);
  }

  static RelationKind _parseKind(Object? value) {
    if (value is! String) return RelationKind.other;
    final v = value.trim().toLowerCase();
    final byName = RelationKind.values.asNameMap();
    if (byName.containsKey(v)) return byName[v]!;
    return switch (v) {
      'master-apprentice' ||
      'master_apprentice' =>
        RelationKind.masterApprentice,
      '爱情' || '愛' => RelationKind.love,
      '亲情' || '家人' => RelationKind.family,
      '友情' || '朋友' => RelationKind.friendship,
      '师徒' || '师傅' || '师父' => RelationKind.masterApprentice,
      '同事' || '同僚' => RelationKind.colleague,
      '上下级' || '上级' || '主仆' => RelationKind.superior,
      '敌对' || '敌人' || '仇恨' => RelationKind.enemy,
      '同盟' || '盟友' => RelationKind.alliance,
      '其他' || '其他关系' => RelationKind.other,
      _ => RelationKind.other,
    };
  }
}
