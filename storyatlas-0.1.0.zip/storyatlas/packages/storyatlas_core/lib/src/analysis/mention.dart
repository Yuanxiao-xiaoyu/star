/// 正文中某个人物的一次提及（名字或别名命中的位置区间）。
class Mention {
  const Mention({
    required this.characterId,
    required this.start,
    required this.end,
  });

  final String characterId;

  /// 起始下标（含）。
  final int start;

  /// 结束下标（不含）。
  final int end;

  /// 与另一处提及的字符距离（0 表示紧邻或重叠）。
  int distanceTo(Mention other) {
    if (end <= other.start) return other.start - end;
    if (other.end <= start) return start - other.end;
    return 0;
  }

  @override
  String toString() => 'Mention($characterId, $start..$end)';
}
