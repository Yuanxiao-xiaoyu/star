import 'dart:math' as math;

import '../models/character.dart';
import '../models/relation.dart';
import '../models/story.dart';
import 'keywords.dart';
import 'mention.dart';

/// 单篇故事中一对人物的「交际证据」，用于时间交际线展示。
class StoryEvidence {
  const StoryEvidence({
    required this.storyId,
    required this.fromId,
    required this.toId,
    this.kind,
    required this.snippet,
    required this.score,
  });

  final String storyId;

  /// 上下文中先出现的一方。
  final String fromId;

  /// 上下文中后出现的一方。
  final String toId;

  /// 命中的关系类型（无关键词命中时为 null，仅共现）。
  final RelationKind? kind;

  /// 上下文片段。
  final String snippet;

  /// 证据强度（0–100）。
  final double score;

  Map<String, Object?> toJson() => <String, Object?>{
        'storyId': storyId,
        'fromId': fromId,
        'toId': toId,
        'kind': kind?.name,
        'snippet': snippet,
        'score': score,
      };

  factory StoryEvidence.fromJson(Map<String, dynamic> json) {
    return StoryEvidence(
      storyId: json['storyId'] as String? ?? '',
      fromId: json['fromId'] as String? ?? '',
      toId: json['toId'] as String? ?? '',
      kind: RelationKind.values.asNameMap()[json['kind'] as String?],
      snippet: json['snippet'] as String? ?? '',
      score: ((json['score'] as num?)?.toDouble() ?? 0).clamp(0.0, 100.0),
    );
  }
}

/// 一次分析的完整结果。
class AnalysisResult {
  const AnalysisResult({
    required this.relations,
    this.evidence = const <StoryEvidence>[],
  });

  /// 合并后的人物关系（手动 > AI > 自动，同一对人物只保留一条）。
  final List<Relation> relations;

  /// 逐篇故事的人物交际证据。
  final List<StoryEvidence> evidence;

  /// 某个人物参与的所有关系。
  List<Relation> relationsOf(String characterId) => <Relation>[
        for (final r in relations)
          if (r.involves(characterId)) r,
      ];

  /// 某篇故事里的全部交际证据。
  List<StoryEvidence> evidenceOf(String storyId) => <StoryEvidence>[
        for (final e in evidence)
          if (e.storyId == storyId) e,
      ];

  /// 两个人之间当前生效的关系（无则为 null）。
  Relation? between(String aId, String bId) {
    for (final r in relations) {
      if (r.involves(aId) && r.involves(bId)) return r;
    }
    return null;
  }
}

/// 基于上下文的人物关联分析引擎（纯本地规则，确定性、可测试）。
///
/// 三个层次：
/// 1. 同篇章共现 —— 两人出现在同一故事里即产生关联，距离越近越强；
/// 2. 关键词规则 —— 两人提及的上下文窗口内命中关系关键词，判定关系类型；
/// 3. 方向推断 —— 有向关系中，根据提及先后与关键词位置推断 from → to。
class RelationEngine {
  const RelationEngine._();

  // ---- 可调参数 ----
  static const double baseCooccurScore = 10; // 每篇共现基础分
  static const double protagonistBonus = 5; // 与故事主角共现的加成
  static const int proximityWindow = 100; // 近距离共现窗口（字符数）
  static const double proximityScore = 2; // 每次近距离共现得分
  static const double proximityCapPerStory = 20; // 每篇每对的上限
  static const int keywordWindow = 200; // 关键词检索窗口（字符数）
  static const int keywordMargin = 12; // 窗口外扩边距
  static const int keywordAdjacency = 20; // 关键词与二人提及的最大距离
  static const double keywordHitScore = 3; // 每个关键词命中得分
  static const double keywordCapPerStory = 15; // 每篇每对关键词分上限
  static const double kindStoryScore = 15; // 每篇同类型判定 +15
  static const double minRelationWeight = 10; // 权重低于此值的关系忽略
  static const double maxWeight = 100;

  static const String _sep = '\u0000';

  /// 在正文中找出所有人物提及（名字 + 别名，长名优先，去重叠）。
  static List<Mention> findMentions(
    String text,
    Iterable<Character> characters,
  ) {
    final lower = text.toLowerCase();
    final mentions = <Mention>[];
    for (final c in characters) {
      final names = <String>[c.name, ...c.aliases]
        ..removeWhere((n) => n.trim().isEmpty)
        ..sort((a, b) => b.length.compareTo(a.length));
      for (final name in names) {
        final nl = name.toLowerCase();
        var from = 0;
        while (true) {
          final idx = lower.indexOf(nl, from);
          if (idx < 0) break;
          mentions.add(Mention(
            characterId: c.id,
            start: idx,
            end: idx + nl.length,
          ));
          from = idx + nl.length;
        }
      }
    }
    mentions.sort((a, b) => a.start.compareTo(b.start));
    // 同一人物相互重叠的提及只保留先出现的（更长的）一个。
    final kept = <Mention>[];
    for (final m in mentions) {
      final overlaps = kept.any((k) =>
          k.characterId == m.characterId && m.start < k.end && k.start < m.end);
      if (!overlaps) kept.add(m);
    }
    return kept;
  }

  /// 执行完整分析并合并手动 / AI / 自动关系。
  ///
  /// [ignoredPairs] 中的人对（无向配对键）会被完全忽略，
  /// 用于让用户屏蔽自动分析产生的噪声边。
  static AnalysisResult analyze({
    required List<Character> characters,
    required List<Story> stories,
    List<Relation> manual = const <Relation>[],
    List<Relation> ai = const <Relation>[],
    Set<String> ignoredPairs = const <String>{},
    DateTime? now,
  }) {
    final stamp = now ?? DateTime.now();
    final charById = <String, Character>{for (final c in characters) c.id: c};
    final accs = <String, _PairAcc>{};
    final evidence = <StoryEvidence>[];

    for (final story in stories) {
      final mentions = findMentions(story.content, characters);
      final counts = <String, int>{};
      for (final m in mentions) {
        counts[m.characterId] = (counts[m.characterId] ?? 0) + 1;
      }
      // 作者手动勾选的人物即使正文未提名也参与共现。
      for (final id in story.characterIds) {
        counts.putIfAbsent(id, () => 1);
      }
      final ids = <String>[
        for (final id in counts.keys)
          if (charById.containsKey(id)) id,
      ];

      // 主角判定：提及次数最多且不少于 2 次。
      String? protagonist;
      var bestCount = 0;
      for (final e in counts.entries) {
        if (e.value > bestCount) {
          bestCount = e.value;
          protagonist = e.key;
        }
      }
      if (bestCount < 2) protagonist = null;

      for (var i = 0; i < ids.length; i++) {
        for (var j = i + 1; j < ids.length; j++) {
          final a = ids[i];
          final b = ids[j];
          final acc = accs.putIfAbsent(_pairKey(a, b), _PairAcc.new);
          acc.cooccur += baseCooccurScore;
          if (protagonist == a || protagonist == b) {
            acc.cooccur += protagonistBonus;
          }

          final ms = <Mention>[
            for (final m in mentions)
              if (m.characterId == a || m.characterId == b) m,
          ];

          // 近距离共现。
          var proximity = 0.0;
          for (var x = 0;
              x < ms.length && proximity < proximityCapPerStory;
              x++) {
            for (var y = x + 1; y < ms.length; y++) {
              if (ms[x].characterId == ms[y].characterId) continue;
              if (ms[x].distanceTo(ms[y]) <= proximityWindow) {
                proximity += proximityScore;
              }
            }
          }
          acc.cooccur += math.min(proximity, proximityCapPerStory);

          // 关键词命中与方向投票（按窗口计票，避免跨窗口重复）。
          final hits = <RelationKind, int>{};
          String? bestSnippet;
          for (var x = 0; x < ms.length; x++) {
            for (var y = x + 1; y < ms.length; y++) {
              if (ms[x].characterId == ms[y].characterId) continue;
              final left = ms[x].start < ms[y].start ? ms[x] : ms[y];
              final right = ms[x].start < ms[y].start ? ms[y] : ms[x];
              if (right.start - left.end > keywordWindow) continue;
              final spanStart = math.max(0, left.end - keywordMargin);
              final spanEnd =
                  math.min(story.content.length, right.start + keywordMargin);
              final span = story.content.substring(spanStart, spanEnd);
              final windowHits = <RelationKind, int>{};
              for (final e in relationKeywords.entries) {
                for (final kw in e.value) {
                  var from = 0;
                  while (true) {
                    final idx = span.indexOf(kw, from);
                    if (idx < 0) break;
                    final absPos = spanStart + idx;
                    // 关键词落在某个人物名字内部时不算关系证据
                    //（如「苏婉娘」中的「娘」）。
                    if (_overlapsAnyMention(mentions, absPos, kw.length)) {
                      from = idx + kw.length;
                      continue;
                    }
                    // 归属过滤：关键词只归属于离它最近的人物提及，
                    // 且须落在两人的提及区间内（先提及者之后、
                    // 后提及者之后 12 字以内），减少跨对污染。
                    if (absPos < left.end) {
                      from = idx + kw.length;
                      continue;
                    }
                    if (absPos > right.start + keywordMargin) {
                      from = idx + kw.length;
                      continue;
                    }
                    final owner =
                        _nearestMentionId(mentions, absPos, kw.length);
                    if (owner != a && owner != b) {
                      from = idx + kw.length;
                      continue;
                    }
                    if (_minDistanceToPair(mentions, a, b, absPos, kw.length) >
                        keywordAdjacency) {
                      from = idx + kw.length;
                      continue;
                    }
                    windowHits[e.key] = (windowHits[e.key] ?? 0) + 1;
                    // 有向关系：按本次出现投票方向。反向句式
                    // （「拜…为师」「被…所害」「X 的下属 Y」）
                    // 通过定位标记词后的最近提及确定主动方。
                    if (e.key.isDirected) {
                      final fromIdx = math.max(0, absPos - 20);
                      final before = story.content.substring(fromIdx, absPos);
                      final resolved = _resolveDirection(
                        mentions: mentions,
                        a: a,
                        b: b,
                        kind: e.key,
                        before: before,
                        beforeStart: fromIdx,
                        kw: kw,
                        absPos: absPos,
                      );
                      final voteKey = resolved ??
                          '${left.characterId}$_sep${right.characterId}';
                      final votes = acc.dirVotes
                          .putIfAbsent(e.key, () => <String, int>{});
                      votes[voteKey] = (votes[voteKey] ?? 0) + 1;
                    }
                    from = idx + kw.length;
                  }
                }
              }
              for (final e in windowHits.entries) {
                hits[e.key] = (hits[e.key] ?? 0) + e.value;
              }
              if (windowHits.isNotEmpty && bestSnippet == null) {
                bestSnippet = _cleanSnippet(span);
              }
            }
          }

          RelationKind? bestKind;
          var bestHits = 0;
          for (final e in hits.entries) {
            if (e.value > bestHits) {
              bestHits = e.value;
              bestKind = e.key;
            }
          }
          final kindScore = bestKind == null
              ? 0.0
              : math.min(hits[bestKind]! * keywordHitScore, keywordCapPerStory);
          acc.cooccur += kindScore;
          if (bestKind != null) {
            acc.kindStories[bestKind] = (acc.kindStories[bestKind] ?? 0) + 1;
          }
          if (acc.snippet == null && bestSnippet != null) {
            acc.snippet = bestSnippet;
          }

          final evScore = math.min(
            maxWeight,
            baseCooccurScore +
                math.min(proximity, proximityCapPerStory) +
                kindScore,
          );
          evidence.add(StoryEvidence(
            storyId: story.id,
            fromId: a,
            toId: b,
            kind: bestKind,
            snippet: bestSnippet ?? '同篇共现',
            score: evScore,
          ));
        }
      }
    }

    // 聚合为自动关系。
    final auto = <Relation>[];
    for (final entry in accs.entries) {
      final acc = entry.value;
      final pair = entry.key.split(_sep);
      RelationKind? kind;
      var kindStories = 0;
      for (final e in acc.kindStories.entries) {
        if (e.value > kindStories) {
          kindStories = e.value;
          kind = e.key;
        }
      }
      final kindBonus =
          kind == null ? 0.0 : math.min(kindStoryScore * kindStories, 45.0);
      final weight = (math.min(acc.cooccur, 60.0) +
              kindBonus +
              (kind == null ? 0.0 : 10.0))
          .clamp(0.0, maxWeight);
      if (weight < minRelationWeight) continue;
      if (ignoredPairs.contains('${pair[0]}$_sep${pair[1]}') ||
          ignoredPairs.contains('${pair[1]}$_sep${pair[0]}')) {
        continue;
      }

      final effKind = kind ?? RelationKind.other;
      var fromId = pair[0];
      var toId = pair[1];
      if (effKind.isDirected) {
        // 依据该类型的方向投票决定 from → to。
        final votes = acc.dirVotes[effKind];
        var bestVote = 0;
        if (votes != null) {
          for (final dv in votes.entries) {
            final parts = dv.key.split(_sep);
            final matches = (parts[0] == pair[0] && parts[1] == pair[1]) ||
                (parts[0] == pair[1] && parts[1] == pair[0]);
            if (matches && dv.value > bestVote) {
              bestVote = dv.value;
              fromId = parts[0];
              toId = parts[1];
            }
          }
        }
      } else {
        final sorted = <String>[pair[0], pair[1]]..sort();
        fromId = sorted[0];
        toId = sorted[1];
      }

      auto.add(Relation(
        id: 'auto-${entry.key.replaceAll(_sep, '-')}',
        fromId: fromId,
        toId: toId,
        kind: effKind,
        weight: weight,
        source: RelationSource.auto,
        note: acc.snippet == null ? '同篇章共现' : '依据：${acc.snippet}',
        updatedAt: stamp,
      ));
    }

    // 合并：同一对人物保留优先级最高（手动 > AI > 自动）的一条。
    final byPair = <String, Relation>{};
    for (final r in <Relation>[...auto, ...ai, ...manual]) {
      final key = r.unorderedPairKey;
      if (ignoredPairs.contains(key)) continue;
      final existing = byPair[key];
      if (existing == null ||
          r.source.priority > existing.source.priority ||
          (r.source == existing.source &&
              r.updatedAt.isAfter(existing.updatedAt))) {
        byPair[key] = r;
      }
    }
    final merged = byPair.values.toList()
      ..sort((x, y) => y.weight.compareTo(x.weight));

    return AnalysisResult(relations: merged, evidence: evidence);
  }

  static String _pairKey(String a, String b) =>
      a.compareTo(b) <= 0 ? '$a$_sep$b' : '$b$_sep$a';

  /// 反向句式方向解析：返回 'from\u0000to'，无法判定时返回 null。
  ///
  /// - 师徒：标记（拜 / 拜师 / 师从…）之后最近的人物是师父；
  /// - 敌对：标记（被）之后最近的人物是主动方（「被赵铁山害死」）；
  /// - 上下级：标记（的下属…）之前是上级、之后是下属。
  static String? _resolveDirection({
    required List<Mention> mentions,
    required String a,
    required String b,
    required RelationKind kind,
    required String before,
    required int beforeStart,
    required String kw,
    required int absPos,
  }) {
    final markers = reverseDirectionKeywords[kind];
    if (markers == null) return null;
    var markerAbs = -1;
    for (final mk in markers) {
      final rel = before.lastIndexOf(mk);
      if (rel >= 0) {
        final abs = beforeStart + rel + mk.length;
        if (abs > markerAbs) markerAbs = abs;
      }
      if (kw.contains(mk)) {
        final abs = absPos + kw.length;
        if (abs > markerAbs) markerAbs = abs;
      }
    }
    if (markerAbs < 0) return null;
    String? after;
    for (final m in mentions) {
      if (m.start >= markerAbs) {
        after = m.characterId;
        break;
      }
    }
    String? beforeAgent;
    for (final m in mentions) {
      if (m.end <= markerAbs) beforeAgent = m.characterId;
    }
    if (kind == RelationKind.superior) {
      if (beforeAgent != null && after != null) {
        return '$beforeAgent\u0000$after';
      }
      return null;
    }
    if (after != null && (after == a || after == b)) {
      final other = after == a ? b : a;
      return '$after\u0000$other';
    }
    return null;
  }

  /// 关键词区间是否与任何人物提及重叠（即落在人名内部）。
  static bool _overlapsAnyMention(List<Mention> mentions, int pos, int len) {
    final kwEnd = pos + len;
    for (final m in mentions) {
      if (pos < m.end && kwEnd > m.start) return true;
    }
    return false;
  }

  /// 离关键词区间最近的人物提及（按到区间的距离，越近越优先）。
  static String? _nearestMentionId(List<Mention> mentions, int pos, int len) {
    String? best;
    var bestDist = 1 << 30;
    final kwEnd = pos + len;
    for (final m in mentions) {
      final d = kwEnd <= m.start
          ? m.start - kwEnd
          : pos >= m.end
              ? pos - m.end
              : 0;
      if (d < bestDist) {
        bestDist = d;
        best = m.characterId;
      }
    }
    return best;
  }

  /// 关键词区间到二人任一提及的最小距离。
  static int _minDistanceToPair(
      List<Mention> mentions, String a, String b, int pos, int len) {
    var best = 1 << 30;
    final kwEnd = pos + len;
    for (final m in mentions) {
      if (m.characterId != a && m.characterId != b) continue;
      final d = kwEnd <= m.start
          ? m.start - kwEnd
          : pos >= m.end
              ? pos - m.end
              : 0;
      if (d < best) best = d;
    }
    return best;
  }

  static String _cleanSnippet(String raw) {
    final collapsed = raw.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (collapsed.length <= 60) return collapsed;
    return '${collapsed.substring(0, 57)}…';
  }
}

class _PairAcc {
  double cooccur = 0;
  final Map<RelationKind, int> kindStories = <RelationKind, int>{};
  final Map<RelationKind, Map<String, int>> dirVotes =
      <RelationKind, Map<String, int>>{};
  String? snippet;
}
