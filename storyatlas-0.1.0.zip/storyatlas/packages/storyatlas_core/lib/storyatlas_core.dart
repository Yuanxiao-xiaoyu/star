/// StoryAtlas 核心引擎：数据模型、关联分析、剧情体检与图布局。
///
/// 纯 Dart 实现、零运行时依赖，可独立发布与测试；
/// 应用层（Flutter）只负责界面、存储与 HTTP 通信。
library storyatlas_core;

export 'src/analysis/ai_analyzer.dart';
export 'src/analysis/ai_generator.dart';
export 'src/analysis/keywords.dart';
export 'src/analysis/mention.dart';
export 'src/analysis/relation_engine.dart';
export 'src/check/consistency_checker.dart';
export 'src/check/issue.dart';
export 'src/layout/force_layout.dart';
export 'src/layout/mindmap_layout.dart';
export 'src/models/ai_settings.dart';
export 'src/models/character.dart';
export 'src/models/ids.dart';
export 'src/models/project_data.dart';
export 'src/models/relation.dart';
export 'src/models/story.dart';
