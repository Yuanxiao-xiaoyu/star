import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:storyatlas/src/app.dart';
import 'package:storyatlas/src/painters/graph_painter.dart';
import 'package:storyatlas/src/painters/mindmap_painter.dart';
import 'package:storyatlas/src/services/data_store.dart';
import 'package:storyatlas/src/state/app_state.dart';
import 'package:storyatlas/src/ui/check_page.dart';
import 'package:storyatlas/src/ui/welcome_view.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

/// 构造一份最小的用户数据（不使用任何内置剧情）。
AppState buildState() {
  final state = AppState(store: DataStore());
  state.data = ProjectData(
    characters: <Character>[
      Character(
        id: 'a',
        name: '甲',
        aliases: const ['阿甲'],
        traits: const ['沉稳'],
      ),
      Character(id: 'b', name: '乙', traits: const ['果敢']),
    ],
    stories: <Story>[
      Story(
        id: 's1',
        title: '初见',
        time: DateTime(1924, 3, 2),
        content: '甲在渡口遇见了乙，两人一见如故，聊了很久很久。',
        characterIds: const ['a', 'b'],
      ),
      Story(
        id: 's2',
        title: '分歧',
        time: DateTime(1925, 7, 9),
        content: '甲与乙因为一桩旧事起了争执，最后不欢而散。',
        characterIds: const ['a', 'b'],
      ),
    ],
  );
  state.refresh();
  return state;
}

void main() {
  testWidgets('空项目显示引导页而非预置内容', (tester) async {
    final state = AppState(store: DataStore());
    addTearDown(state.dispose);
    state.refresh();
    await tester.pumpWidget(StoryAtlasApp(state: state));
    await tester.pump();
    expect(find.byType(WelcomeView), findsWidgets);
    expect(find.text('从一个名字开始'), findsWidgets);
    // 不应出现任何预置剧情内容。
    expect(find.text('沈砚秋'), findsNothing);
  });

  testWidgets('五个标签页与三个视图正常渲染', (tester) async {
    final state = buildState();
    addTearDown(state.dispose);
    await tester.pumpWidget(StoryAtlasApp(state: state));
    await tester.pump();

    expect(find.text('故事图谱 · 人物'), findsOneWidget);
    expect(find.text('甲'), findsWidgets);

    await tester.tap(find.text('情节'));
    await tester.pump();
    expect(find.text('故事图谱 · 情节'), findsOneWidget);
    expect(find.text('初见'), findsWidgets);

    await tester.tap(find.text('时间线'));
    await tester.pump();
    expect(find.text('故事图谱 · 时间线'), findsOneWidget);
    expect(find.text('1924 年'), findsOneWidget);

    await tester.tap(find.text('思维图'));
    await tester.pump();
    expect(find.text('故事图谱 · 思维图'), findsOneWidget);
    expect(find.byType(MindmapPainter), findsOneWidget);

    await tester.tap(find.text('关系网'));
    await tester.pump();
    expect(find.text('故事图谱 · 关系网'), findsOneWidget);
    expect(find.byType(GraphPainter), findsOneWidget);
  });

  testWidgets('体检页能列出矛盾并统计数量', (tester) async {
    final state = AppState(store: DataStore());
    addTearDown(state.dispose);
    state.data = ProjectData(
      characters: <Character>[Character(id: 'a', name: '甲', birthYear: 1950)],
      stories: <Story>[
        Story(
          id: 's1',
          title: '早年',
          time: DateTime(1940, 1, 1),
          content: '甲还是个孩子，蹲在门口数着来往的车马。',
        ),
      ],
    );
    state.refresh();
    await tester.pumpWidget(
      AppScope(
        state: state,
        child: const MaterialApp(home: CheckPage()),
      ),
    );
    await tester.pump();
    expect(find.textContaining('剧情体检'), findsOneWidget);
    expect(find.textContaining('出生前'), findsOneWidget);
  });
}
