import 'dart:math';

import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../app.dart';
import '../painters/graph_painter.dart';
import 'character_detail_page.dart';
import 'palette.dart';
import 'widgets.dart';

/// 人物关系网：力导向布局，可缩放平移、点选人物、聚焦重排。
class GraphPage extends StatefulWidget {
  const GraphPage({super.key});

  @override
  State<GraphPage> createState() => _GraphPageState();
}

class _GraphPageState extends State<GraphPage> {
  static const double _canvasW = 1200;
  static const double _canvasH = 900;

  int _seed = 42;
  String? _selectedId;
  int _builtRevision = -1;
  Map<String, Point<double>> _positions = const <String, Point<double>>{};
  List<Relation> _relations = const <Relation>[];

  void _relayout(AppState state, {String? focus}) {
    _relations = state.analysis.relations;
    final edges = <ForceEdge>[
      for (final r in _relations)
        ForceEdge(a: r.fromId, b: r.toId, weight: r.weight / 100),
    ];
    _positions =
        ForceLayout(
          width: _canvasW,
          height: _canvasH,
          seed: _seed,
          iterations: edges.length > 30 ? 200 : 300,
        ).run(
          edges: edges,
          pinned: focus == null ? const <String>{} : <String>{focus},
        );
    _builtRevision = state.revision;
  }

  void _onTapUp(TapUpDetails details, AppState state) {
    String? hit;
    var best = 52.0;
    final tap = details.localPosition;
    for (final e in _positions.entries) {
      final meta = _nodeMeta(state, e.key);
      if (meta == null) continue;
      final d = (Offset(e.value.x, e.value.y) - tap).distance;
      if (d < best && d <= meta.radius + 10) {
        best = d;
        hit = e.key;
      }
    }
    setState(() => _selectedId = hit);
  }

  GraphNodeMeta? _nodeMeta(AppState state, String id) {
    final c = state.characterById(id);
    if (c == null) return null;
    final degree = _relations.where((r) => r.involves(id)).length;
    return GraphNodeMeta(
      name: c.name,
      color: charColor(c.colorIndex),
      radius: 15 + min(14.0, degree * 2.5),
      selected: id == _selectedId,
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    if (state.data.characters.isEmpty) {
      return EmptyHint(
        icon: Icons.share_outlined,
        title: '还没有关系网',
        subtitle: '创建人物并写下情节后，\n这里会生成力导向的人物关系网络。',
      );
    }
    if (_builtRevision != state.revision) {
      _relayout(state);
    }
    final nodes = <String, GraphNodeMeta>{
      for (final c in state.data.characters) c.id: _nodeMeta(state, c.id)!,
    };
    final selected = _selectedId == null
        ? null
        : state.characterById(_selectedId!);

    return Column(
      children: <Widget>[
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            children: <Widget>[
              for (final kind in RelationKind.values)
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: Row(
                    children: <Widget>[
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: kindColor(kind),
                        ),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        kind.label,
                        style: Theme.of(context).textTheme.labelSmall,
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            if (_selectedId != null)
              IconButton(
                tooltip: '以选中人物为中心重排',
                icon: const Icon(Icons.center_focus_strong),
                onPressed: () {
                  _seed++;
                  _relayout(state, focus: _selectedId);
                  setState(() {});
                },
              ),
            IconButton(
              tooltip: '重新布局',
              icon: const Icon(Icons.refresh),
              onPressed: () {
                _seed++;
                _relayout(state);
                setState(() {});
              },
            ),
          ],
        ),
        Expanded(
          child: Stack(
            children: <Widget>[
              Positioned.fill(
                child: InteractiveViewer(
                  constrained: false,
                  minScale: 0.2,
                  maxScale: 4,
                  boundaryMargin: const EdgeInsets.all(200),
                  child: GestureDetector(
                    onTapUp: (d) => _onTapUp(d, state),
                    child: CustomPaint(
                      size: const Size(_canvasW, _canvasH),
                      painter: GraphPainter(
                        positions: _positions,
                        relations: _relations,
                        nodes: nodes,
                      ),
                    ),
                  ),
                ),
              ),
              if (selected != null)
                Positioned(
                  left: 12,
                  right: 12,
                  bottom: 12,
                  child: _selectedCard(context, state, selected),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _selectedCard(BuildContext context, AppState state, Character c) {
    final rels = state.relationsOf(c.id);
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Row(
              children: <Widget>[
                CircleAvatar(
                  radius: 12,
                  backgroundColor: charColor(c.colorIndex),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    c.name,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                IconButton(
                  tooltip: '收起',
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.close, size: 18),
                  onPressed: () => setState(() => _selectedId = null),
                ),
              ],
            ),
            if (c.description.isNotEmpty)
              Text(c.description, maxLines: 2, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 6),
            Text(
              rels.isEmpty
                  ? '暂无关系'
                  : rels
                        .map((r) {
                          final other = state.characterById(r.otherOf(c.id));
                          return '${other?.name ?? '?'}·${r.kind.label}'
                              '（${r.weight.round()}）';
                        })
                        .join('　'),
              style: Theme.of(context).textTheme.bodySmall,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 8),
            Row(
              children: <Widget>[
                FilledButton.tonalIcon(
                  onPressed: () {
                    state.mindmapRootId = c.id;
                    state.switchTab(3);
                  },
                  icon: const Icon(Icons.hub_outlined, size: 18),
                  label: const Text('思维视图'),
                ),
                const SizedBox(width: 8),
                OutlinedButton.icon(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => CharacterDetailPage(characterId: c.id),
                      ),
                    );
                  },
                  icon: const Icon(Icons.person_outline, size: 18),
                  label: const Text('详情'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
