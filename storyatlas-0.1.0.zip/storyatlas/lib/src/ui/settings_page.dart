import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../app.dart';
import 'check_page.dart';

/// 设置：可选 AI 分析、数据导入导出、示例与清空、关于。
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool _busy = false;
  bool _obscure = true;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final ai = state.data.aiSettings;
    return Scaffold(
      appBar: AppBar(title: const Text('设置')),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: <Widget>[
          _card(
            title: 'AI 语义分析（可选）',
            subtitle:
                '本地规则始终生效；开启后可用大模型从上下文语义判断人物关系。'
                '兼容 OpenAI 格式接口（如 DeepSeek、通义千问等）。',
            children: <Widget>[
              SwitchListTile(
                title: const Text('启用 AI 分析'),
                subtitle: Text(ai.useAi ? '已开启' : '仅使用本地规则'),
                value: ai.useAi,
                onChanged: (v) => state.updateAiSettings(ai.copyWith(useAi: v)),
              ),
              _AiTextField(
                label: '接口地址',
                helper: '例如 https://api.deepseek.com/v1',
                value: ai.baseUrl,
                onChanged: (v) =>
                    state.updateAiSettings(ai.copyWith(baseUrl: v.trim())),
              ),
              _AiTextField(
                label: 'API 密钥',
                value: ai.apiKey,
                obscure: _obscure,
                suffix: IconButton(
                  icon: Icon(
                    _obscure ? Icons.visibility_off : Icons.visibility,
                  ),
                  onPressed: () => setState(() => _obscure = !_obscure),
                ),
                onChanged: (v) =>
                    state.updateAiSettings(ai.copyWith(apiKey: v.trim())),
              ),
              _AiTextField(
                label: '模型',
                helper: '例如 deepseek-chat',
                value: ai.model,
                onChanged: (v) =>
                    state.updateAiSettings(ai.copyWith(model: v.trim())),
              ),
              const SizedBox(height: 12),
              Row(
                children: <Widget>[
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _busy ? null : _testConnection,
                      icon: const Icon(Icons.wifi_tethering),
                      label: const Text('测试连接'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: _busy ? null : _runAi,
                      icon: const Icon(Icons.auto_awesome),
                      label: const Text('运行 AI 分析'),
                    ),
                  ),
                ],
              ),
              if (state.data.aiRelations.isNotEmpty)
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () {
                      state.clearAiRelations();
                      _snack('已清除 AI 分析结果');
                    },
                    child: Text('清除 AI 结果（${state.data.aiRelations.length} 条）'),
                  ),
                ),
            ],
          ),
          _card(
            title: '数据',
            subtitle: '数据保存在本机应用目录，自动保存。',
            children: <Widget>[
              ListTile(
                leading: const Icon(Icons.upload_outlined),
                title: const Text('导出 JSON'),
                subtitle: const Text('完整备份为 JSON 文本'),
                onTap: _export,
              ),
              ListTile(
                leading: const Icon(Icons.download_outlined),
                title: const Text('导入 JSON'),
                subtitle: const Text('粘贴 JSON 文本覆盖当前数据'),
                onTap: _import,
              ),
              ListTile(
                leading: const Icon(Icons.fact_check_outlined),
                title: const Text('剧情体检'),
                subtitle: const Text('检查时间线、人物设定与关系矛盾'),
                onTap: _openCheck,
              ),
              ListTile(
                leading: Icon(
                  Icons.delete_forever_outlined,
                  color: Theme.of(context).colorScheme.error,
                ),
                title: Text(
                  '清空全部数据',
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
                onTap: _clearAll,
              ),
            ],
          ),
          _card(
            title: '关于',
            children: <Widget>[
              const ListTile(
                leading: Icon(Icons.info_outline),
                title: Text('故事图谱 StoryAtlas'),
                subtitle: Text('v0.1.0 · MIT 开源协议'),
              ),
              ListTile(
                leading: const Icon(Icons.code),
                title: const Text('源代码'),
                subtitle: const Text('github.com/storyatlas-app/storyatlas'),
                onTap: () => _snack('在 GitHub 搜索 storyatlas 即可找到仓库'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _card({
    required String title,
    String? subtitle,
    required List<Widget> children,
  }) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: Text(
                title,
                style: theme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            if (subtitle != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Text(
                  subtitle,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.outline,
                  ),
                ),
              ),
            ...children,
          ],
        ),
      ),
    );
  }

  void _snack(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _testConnection() async {
    final state = AppScope.of(context);
    setState(() => _busy = true);
    final ok = await state.testAiConnection();
    if (!mounted) return;
    setState(() => _busy = false);
    _snack(ok ? '连接成功' : '连接失败，请检查地址、密钥与模型名');
  }

  Future<void> _runAi() async {
    final state = AppScope.of(context);
    setState(() => _busy = true);
    final error = await state.runAiAnalysis();
    if (!mounted) return;
    setState(() => _busy = false);
    _snack(error ?? 'AI 分析完成，关系网已更新');
  }

  Future<void> _export() async {
    final state = AppScope.of(context);
    final json = state.exportJson();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('导出 JSON'),
        content: SizedBox(
          width: double.maxFinite,
          height: 360,
          child: SingleChildScrollView(
            child: SelectableText(json, style: const TextStyle(fontSize: 12)),
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: json));
              if (!dialogContext.mounted) return;
              Navigator.of(dialogContext).pop();
              _snack('已复制到剪贴板');
            },
            child: const Text('复制全部'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  Future<void> _import() async {
    final controller = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('导入 JSON'),
        content: SizedBox(
          width: double.maxFinite,
          child: TextField(
            controller: controller,
            maxLines: 10,
            decoration: const InputDecoration(hintText: '在此粘贴导出的 JSON 文本…'),
          ),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('导入（覆盖当前数据）'),
          ),
        ],
      ),
    );
    final text = controller.text;
    controller.dispose();
    if (ok != true || !mounted) return;
    final state = AppScope.of(context);
    final success = state.importJson(text);
    _snack(success ? '导入成功' : '导入失败：JSON 格式不正确');
  }

  Future<void> _openCheck() async {
    await Navigator.of(
      context,
    ).push(MaterialPageRoute<void>(builder: (_) => const CheckPage()));
  }

  Future<void> _clearAll() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('清空全部数据？'),
        content: const Text('人物、情节、关系将全部删除，且无法恢复。'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('取消'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(dialogContext).colorScheme.error,
            ),
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('清空'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    AppScope.of(context).clearAll();
    _snack('已清空');
  }
}

/// 自带控制器的文本输入框：仅在外层值变化时重建内容，避免焦点跳动。
class _AiTextField extends StatefulWidget {
  const _AiTextField({
    required this.label,
    required this.value,
    required this.onChanged,
    this.helper,
    this.obscure = false,
    this.suffix,
  });

  final String label;
  final String value;
  final ValueChanged<String> onChanged;
  final String? helper;
  final bool obscure;
  final Widget? suffix;

  @override
  State<_AiTextField> createState() => _AiTextFieldState();
}

class _AiTextFieldState extends State<_AiTextField> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.value);
  }

  @override
  void didUpdateWidget(covariant _AiTextField oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value && _controller.text != widget.value) {
      _controller.value = TextEditingValue(
        text: widget.value,
        selection: TextSelection.collapsed(offset: widget.value.length),
      );
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: TextField(
        controller: _controller,
        obscureText: widget.obscure,
        decoration: InputDecoration(
          labelText: widget.label,
          helperText: widget.helper,
          suffixIcon: widget.suffix,
        ),
        onChanged: widget.onChanged,
      ),
    );
  }
}
