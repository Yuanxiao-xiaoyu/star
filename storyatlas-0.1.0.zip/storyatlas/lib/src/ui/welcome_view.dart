import 'package:flutter/material.dart';

/// 空项目引导：新建人物 / 书写情节 / 让 AI 起个头。
class WelcomeView extends StatelessWidget {
  const WelcomeView({
    super.key,
    required this.onCharacter,
    required this.onStory,
    required this.onGenerate,
  });

  final VoidCallback onCharacter;
  final VoidCallback onStory;
  final VoidCallback onGenerate;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(24, 32, 24, 100),
      children: <Widget>[
        Icon(
          Icons.auto_stories_outlined,
          size: 64,
          color: theme.colorScheme.primary,
        ),
        const SizedBox(height: 16),
        Text(
          '从一个名字开始',
          style: theme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 8),
        Text(
          '这里没有任何预置剧情。\n人物、情节、关系全部由你定义，'
          '应用负责梳理关联、指正矛盾。',
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.outline,
            height: 1.6,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 32),
        _StepCard(
          index: 1,
          icon: Icons.person_add_alt,
          title: '建立人物',
          detail: '姓名、别名、性格、外貌、背景、目标、生卒年。',
          action: FilledButton(
            onPressed: onCharacter,
            child: const Text('新建人物'),
          ),
        ),
        _StepCard(
          index: 2,
          icon: Icons.edit_note,
          title: '写下情节',
          detail: '每篇情节是一个时间点，正文里写出场人物，关系会自动分析。',
          action: OutlinedButton(
            onPressed: onStory,
            child: const Text('写一篇情节'),
          ),
        ),
        _StepCard(
          index: 3,
          icon: Icons.auto_awesome,
          title: '让 AI 起个头',
          detail: '给出题材和要求，自动生成人物或情节草稿，你再改。',
          action: TextButton.icon(
            onPressed: onGenerate,
            icon: const Icon(Icons.auto_awesome, size: 18),
            label: const Text('打开 AI 创作'),
          ),
        ),
        const SizedBox(height: 24),
        Text(
          '所有数据只保存在本机，可随时在设置里导出备份。',
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.outline,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}

class _StepCard extends StatelessWidget {
  const _StepCard({
    required this.index,
    required this.icon,
    required this.title,
    required this.detail,
    required this.action,
  });

  final int index;
  final IconData icon;
  final String title;
  final String detail;
  final Widget action;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            CircleAvatar(
              radius: 16,
              backgroundColor: theme.colorScheme.primaryContainer,
              child: Text(
                '$index',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: theme.colorScheme.onPrimaryContainer,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Icon(icon, size: 18),
                      const SizedBox(width: 6),
                      Text(
                        title,
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    detail,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.outline,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Align(alignment: Alignment.centerLeft, child: action),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
