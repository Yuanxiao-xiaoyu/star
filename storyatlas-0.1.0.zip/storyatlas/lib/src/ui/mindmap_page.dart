import 'dart:math';

import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../app.dart';
import '../painters/mindmap_painter.dart';
import 'palette.dart';
import 'story_detail_page.dart';
import 'widgets.dart';

/// 思维视图：以某个人物为根，放射状展开关系与情节。
class MindmapPage extends StatefulWidget {
  const MindmapPage({super.key});

  @override
  State<MindmapPage> createState() => _MindmapPageState();
}

class _MindmapPageState extends State<MindmapPage> {
  static const double _canvasW = 1600;
  static const double _canvasH = 1400;

  String? _rootId;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final chars = state.data.characters;
    if (chars.isEmpty) {
      return EmptyHint(
        icon: Icons.hub_outlined,
        title: '还没有思维视图',
        subtitle: '创建人物并写下情节后，\n以任意人物为根展开 TA 的思维视图。',
      );
    }
    final requestedRoot = state.mindmapRootId;
    if (requestedRoot != null && state.characterById(requestedRoot) != null) {
      _rootId = requestedRoot;
    }
    if (_rootId != null && state.characterById(_rootId!) == null) {
      _rootId = null;
    }
    final rootId = _rootId ?? chars.first.id;

    final built = _build(rootId, state);
    final nodes = <String, MindmapNodeMeta>{};
    for (final c in chars) {
      if (!built.positions.containsKey(c.id)) continue;
      nodes[c.id] = MindmapNodeMeta(
        label: c.name,
        color: charColor(c.colorIndex),
        isStory: false,
        isRoot: c.id == rootId,
      );
    }
    for (final s in state.storiesOf(rootId)) {
      nodes['story-${s.id}'] = MindmapNodeMeta(
        label: '📖 ${s.title}',
        color: Colors.grey,
        isStory: true,
        isRoot: false,
      );
    }

    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: Row(
            children: <Widget>[
              const Icon(Icons.hub_outlined, size: 18),
              const SizedBox(width: 8),
              Text('根人物：', style: Theme.of(context).textTheme.labelLarge),
              const SizedBox(width: 8),
              Expanded(
                child: DropdownButton<String>(
                  isExpanded: true,
                  value: rootId,
                  items: <DropdownMenuItem<String>>[
                    for (final c in chars)
                      DropdownMenuItem<String>(
                        value: c.id,
                        child: Text(c.name, overflow: TextOverflow.ellipsis),
                      ),
                  ],
                  onChanged: (v) {
                    if (v != null) {
                      setState(() => _rootId = v);
                      state.mindmapRootId = v;
                    }
                  },
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Text(
            '点击任意人物节点，可切换为以 TA 为根展开',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.outline,
            ),
          ),
        ),
        Expanded(
          child: InteractiveViewer(
            constrained: false,
            minScale: 0.2,
            maxScale: 4,
            boundaryMargin: const EdgeInsets.all(300),
            child: GestureDetector(
              onTapUp: (d) => _onTapUp(d.localPosition, state, rootId),
              child: CustomPaint(
                size: const Size(_canvasW, _canvasH),
                painter: MindmapPainter(
                  positions: built.positions,
                  edges: built.edges,
                  edgeColors: built.edgeColors,
                  nodes: nodes,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// 构建径向树：根 → 关联人物（第 1 层）→ 其重要关联（第 2 层），
  /// 以及根人物参与的情节（叶子）。
  ({
    List<MindmapEdge> edges,
    Map<String, Color> edgeColors,
    Map<String, Point<double>> positions,
  })
  _build(String rootId, AppState state) {
    final edges = <MindmapEdge>[];
    final edgeColors = <String, Color>{};
    final visited = <String>{rootId};
    final relations = state.relationsOf(rootId);
    for (final r in relations) {
      final other = r.otherOf(rootId);
      if (visited.contains(other)) continue;
      visited.add(other);
      edges.add(
        MindmapEdge(parentId: rootId, childId: other, weight: r.weight / 100),
      );
      edgeColors[other] = kindColor(r.kind);
    }
    for (final r in relations) {
      final mid = r.otherOf(rootId);
      final rels2 = state.relationsOf(mid)
        ..sort((a, b) => b.weight.compareTo(a.weight));
      var count = 0;
      for (final r2 in rels2) {
        final leaf = r2.otherOf(mid);
        if (visited.contains(leaf)) continue;
        visited.add(leaf);
        edges.add(
          MindmapEdge(parentId: mid, childId: leaf, weight: r2.weight / 100),
        );
        edgeColors[leaf] = kindColor(r2.kind);
        if (++count >= 3) break;
      }
    }
    for (final s in state.storiesOf(rootId)) {
      final storyId = 'story-${s.id}';
      edges.add(MindmapEdge(parentId: rootId, childId: storyId, weight: 0.25));
      edgeColors[storyId] = Colors.blueGrey;
    }
    final positions = MindmapLayout.compute(rootId: rootId, edges: edges);
    return (edges: edges, edgeColors: edgeColors, positions: positions);
  }

  void _onTapUp(Offset tap, AppState state, String rootId) {
    const center = Offset(_canvasW / 2, _canvasH / 2);
    final local = tap - center;
    final built = _build(rootId, state);
    String? hit;
    var best = 70.0;
    for (final c in state.data.characters) {
      final p = built.positions[c.id];
      if (p == null) continue;
      final d = (Offset(p.x, p.y) - local).distance;
      if (d < best && d <= 40) {
        best = d;
        hit = c.id;
      }
    }
    if (hit == null) {
      for (final s in state.storiesOf(rootId)) {
        final p = built.positions['story-${s.id}'];
        if (p == null) continue;
        final d = (Offset(p.x, p.y) - local).distance;
        if (d < best && d <= 60) {
          _openStory(s.id);
          return;
        }
      }
      return;
    }
    if (hit != rootId) {
      setState(() => _rootId = hit);
      state.mindmapRootId = hit;
    }
  }

  void _openStory(String storyId) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => StoryDetailPage(storyId: storyId),
      ),
    );
  }
}
