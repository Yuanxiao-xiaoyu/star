import 'package:flutter/material.dart';

import '../app.dart';
import 'character_edit_page.dart';
import 'characters_page.dart';
import 'check_page.dart';
import 'generator_page.dart';
import 'graph_page.dart';
import 'mindmap_page.dart';
import 'relations_page.dart';
import 'routes.dart';
import 'settings_page.dart';
import 'stories_page.dart';
import 'story_edit_page.dart';
import 'timeline_page.dart';

/// 主界面：五个标签页 + 顶栏的体检 / 关系 / 创作 / 设置。
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  static const List<String> _titles = <String>['人物', '情节', '时间线', '思维图', '关系网'];

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final tab = state.homeTab;
    final issues = state.report.issues.length;
    return Scaffold(
      appBar: AppBar(
        title: Text('故事图谱 · ${_titles[tab]}'),
        actions: <Widget>[
          IconButton(
            tooltip: 'AI 创作',
            icon: const Icon(Icons.auto_awesome_outlined),
            onPressed: () => Routes.push<void>(context, const GeneratorPage()),
          ),
          IconButton(
            tooltip: '剧情体检',
            icon: Badge(
              isLabelVisible: issues > 0,
              label: Text('$issues'),
              child: const Icon(Icons.fact_check_outlined),
            ),
            onPressed: () => Routes.push<void>(context, const CheckPage()),
          ),
          PopupMenuButton<String>(
            tooltip: '更多',
            icon: const Icon(Icons.more_vert),
            onSelected: (v) {
              switch (v) {
                case 'relations':
                  Routes.push<void>(context, const RelationsPage());
                  break;
                case 'settings':
                  Routes.push<void>(context, const SettingsPage());
                  break;
              }
            },
            itemBuilder: (context) => const <PopupMenuEntry<String>>[
              PopupMenuItem<String>(
                value: 'relations',
                child: _MenuRow(
                  icon: Icons.account_tree_outlined,
                  label: '关系列表',
                ),
              ),
              PopupMenuItem<String>(
                value: 'settings',
                child: _MenuRow(icon: Icons.settings_outlined, label: '设置'),
              ),
            ],
          ),
        ],
      ),
      body: IndexedStack(
        index: tab,
        children: const <Widget>[
          CharactersPage(),
          StoriesPage(),
          TimelinePage(),
          MindmapPage(),
          GraphPage(),
        ],
      ),
      floatingActionButton: tab <= 1
          ? FloatingActionButton(
              tooltip: tab == 0 ? '新建人物' : '新建情节',
              onPressed: () => _addCurrent(context, tab),
              child: const Icon(Icons.add),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: state.switchTab,
        destinations: const <NavigationDestination>[
          NavigationDestination(
            icon: Icon(Icons.people_outline),
            selectedIcon: Icon(Icons.people),
            label: '人物',
          ),
          NavigationDestination(
            icon: Icon(Icons.menu_book_outlined),
            selectedIcon: Icon(Icons.menu_book),
            label: '情节',
          ),
          NavigationDestination(
            icon: Icon(Icons.timeline_outlined),
            selectedIcon: Icon(Icons.timeline),
            label: '时间线',
          ),
          NavigationDestination(
            icon: Icon(Icons.hub_outlined),
            selectedIcon: Icon(Icons.hub),
            label: '思维图',
          ),
          NavigationDestination(
            icon: Icon(Icons.share_outlined),
            selectedIcon: Icon(Icons.share),
            label: '关系网',
          ),
        ],
      ),
    );
  }

  void _addCurrent(BuildContext context, int tab) {
    if (tab == 0) {
      Routes.push<void>(context, const CharacterEditPage());
    } else {
      Routes.push<void>(context, const StoryEditPage());
    }
  }
}

/// 弹出菜单中的一行图标 + 文字。
class _MenuRow extends StatelessWidget {
  const _MenuRow({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Icon(icon, size: 20),
        const SizedBox(width: 12),
        Text(label),
      ],
    );
  }
}
