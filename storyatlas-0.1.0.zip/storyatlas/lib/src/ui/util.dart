/// 日期显示工具。
String two(int n) => n.toString().padLeft(2, '0');

/// 2026-11-13 形式的日期。
String fmtDate(DateTime? d) {
  if (d == null) return '未注明时间';
  return '${d.year}-${two(d.month)}-${two(d.day)}';
}

/// 2026-11-13 14:30 形式。
String fmtDateTime(DateTime d) =>
    '${d.year}-${two(d.month)}-${two(d.day)} ${two(d.hour)}:${two(d.minute)}';

/// 截断长文本。
String truncate(String s, int max) {
  if (s.length <= max) return s;
  return '${s.substring(0, max)}…';
}
