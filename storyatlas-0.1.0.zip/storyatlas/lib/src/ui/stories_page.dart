import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../app.dart';
import 'character_edit_page.dart';
import 'palette.dart';
import 'routes.dart';
import 'story_detail_page.dart';
import 'story_edit_page.dart';
import 'util.dart';
import 'welcome_view.dart';

/// 情节列表页。
class StoriesPage extends StatelessWidget {
  const StoriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    if (state.isEmpty) {
      return WelcomeView(
        onCharacter: () =>
            Routes.push<void>(context, const CharacterEditPage()),
        onStory: () => Routes.push<void>(context, const StoryEditPage()),
        onGenerate: () => Routes.generator<void>(context),
      );
    }
    final stories = state.sortedStories();
    if (stories.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const Text('还没有情节'),
              const SizedBox(height: 6),
              Text(
                '写下一篇情节，人物关系会根据正文自动分析。',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.outline,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: () =>
                    Routes.push<void>(context, const StoryEditPage()),
                icon: const Icon(Icons.edit_note),
                label: const Text('写一篇情节'),
              ),
            ],
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 88),
      itemCount: stories.length,
      itemBuilder: (context, index) {
        final s = stories[index];
        final issueCount = state.report.ofStory(s.id).length;
        return Card(
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Theme.of(context).colorScheme.secondaryContainer,
              child: const Icon(Icons.article_outlined),
            ),
            title: Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    s.title,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                if (issueCount > 0)
                  Text(
                    '$issueCount 提示',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: const Color(0xFFEF6C00),
                    ),
                  ),
              ],
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  '${fmtDate(s.time)}'
                  '${s.location.isEmpty ? '' : ' · ${s.location}'}'
                  ' · ${truncate(s.content, 40)}',
                ),
                if (s.characterIds.isNotEmpty || s.tags.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Wrap(
                      spacing: 6,
                      runSpacing: 2,
                      children: <Widget>[
                        for (final id in s.characterIds)
                          if (state.characterById(id) != null)
                            _miniChip(context, state.characterById(id)!),
                        for (final t in s.tags)
                          Chip(
                            label: Text('#$t'),
                            labelStyle: Theme.of(context).textTheme.labelSmall,
                            visualDensity: VisualDensity.compact,
                            materialTapTargetSize:
                                MaterialTapTargetSize.shrinkWrap,
                          ),
                      ],
                    ),
                  ),
              ],
            ),
            isThreeLine: true,
            onTap: () =>
                Routes.push<void>(context, StoryDetailPage(storyId: s.id)),
          ),
        );
      },
    );
  }

  Widget _miniChip(BuildContext context, Character c) => Chip(
    avatar: CircleAvatar(backgroundColor: charColor(c.colorIndex)),
    label: Text(c.name),
    labelStyle: Theme.of(context).textTheme.labelSmall,
    visualDensity: VisualDensity.compact,
    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
  );
}
