import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../app.dart';
import 'character_detail_page.dart';
import 'character_edit_page.dart';
import 'routes.dart';
import 'story_detail_page.dart';
import 'story_edit_page.dart';
import 'widgets.dart';

/// 剧情体检：列出所有可能不妥的地方，并给出修改建议。
class CheckPage extends StatefulWidget {
  const CheckPage({super.key});

  @override
  State<CheckPage> createState() => _CheckPageState();
}

class _CheckPageState extends State<CheckPage> {
  IssueSeverity? _filter;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final report = state.report;
    final all = report.issues;
    final shown = _filter == null
        ? all
        : all.where((i) => i.severity == _filter).toList(growable: false);

    return Scaffold(
      appBar: AppBar(
        title: Text('剧情体检（${all.length}）'),
        actions: <Widget>[
          if (all.isNotEmpty)
            IconButton(
              tooltip: '重新检查',
              icon: const Icon(Icons.refresh),
              onPressed: () {
                setState(() {});
                ScaffoldMessenger.of(
                  context,
                ).showSnackBar(const SnackBar(content: Text('已根据当前内容重新体检')));
              },
            ),
        ],
      ),
      body: Column(
        children: <Widget>[
          _summary(context, report),
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text('全部 ${all.length}'),
                    selected: _filter == null,
                    onSelected: (_) => setState(() => _filter = null),
                  ),
                ),
                for (final s in IssueSeverity.values)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text('${s.label} ${_count(all, s)}'),
                      selected: _filter == s,
                      onSelected: (_) => setState(() => _filter = s),
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: shown.isEmpty
                ? EmptyHint(
                    icon: all.isEmpty
                        ? Icons.verified_outlined
                        : Icons.filter_alt_off_outlined,
                    title: all.isEmpty ? '没有发现问题' : '该类别下没有问题',
                    subtitle: all.isEmpty ? '人物设定、时间线与人物关系目前彼此自洽。' : null,
                  )
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 24),
                    itemCount: shown.length,
                    itemBuilder: (context, index) {
                      final issue = shown[index];
                      return IssueTile(
                        issue: issue,
                        onTap: () => _open(context, state, issue),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  int _count(List<StoryIssue> all, IssueSeverity s) =>
      all.where((i) => i.severity == s).length;

  Widget _summary(BuildContext context, CheckReport report) {
    final theme = Theme.of(context);
    final clean = report.isClean;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: clean
            ? theme.colorScheme.primaryContainer.withValues(alpha: 0.5)
            : theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: <Widget>[
          Icon(
            clean ? Icons.verified : Icons.fact_check_outlined,
            color: clean
                ? theme.colorScheme.primary
                : theme.colorScheme.onSurfaceVariant,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  clean
                      ? '整体自洽'
                      : '发现 ${report.errorCount} 个问题、${report.warningCount} 条建议',
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  clean ? '体检只做静态检查，剧情好不好仍由你判断。' : '这些只是可能不妥的地方，不代表必须修改。',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.outline,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _open(BuildContext context, AppState state, StoryIssue issue) {
    final storyId = issue.storyIds.isEmpty ? null : issue.storyIds.first;
    final charId = issue.characterIds.isEmpty ? null : issue.characterIds.first;

    if (storyId != null) {
      final story = state.storyById(storyId);
      if (story != null) {
        // 时间线 / 情节类问题直接进编辑页，方便立刻改。
        if (issue.category == IssueCategory.timeline ||
            issue.category == IssueCategory.story) {
          Routes.push<void>(context, StoryEditPage(initial: story));
        } else {
          Routes.push<void>(context, StoryDetailPage(storyId: storyId));
        }
        return;
      }
    }
    if (charId != null) {
      final c = state.characterById(charId);
      if (c != null) {
        if (issue.category == IssueCategory.character) {
          Routes.push<void>(context, CharacterEditPage(initial: c));
        } else {
          Routes.push<void>(context, CharacterDetailPage(characterId: charId));
        }
        return;
      }
    }
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('这条问题没有可跳转的对象')));
  }
}
