import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../app.dart';
import 'character_detail_page.dart';
import 'palette.dart';
import 'story_edit_page.dart';
import 'util.dart';
import 'widgets.dart';

/// 情节详情：正文 + 本篇的交际证据。
class StoryDetailPage extends StatelessWidget {
  const StoryDetailPage({super.key, required this.storyId});

  final String storyId;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final s = state.storyById(storyId);
    if (s == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('情节')),
        body: const EmptyHint(icon: Icons.article_outlined, title: '情节不存在'),
      );
    }
    final evidence = state.evidenceOf(s.id);
    return Scaffold(
      appBar: AppBar(
        title: Text(s.title),
        actions: <Widget>[
          IconButton(
            tooltip: '编辑',
            icon: const Icon(Icons.edit_outlined),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => StoryEditPage(initial: s),
                ),
              );
            },
          ),
          IconButton(
            tooltip: '删除',
            icon: const Icon(Icons.delete_outline),
            onPressed: () => _confirmDelete(context, state, s),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  fmtDate(s.time),
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 4),
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: <Widget>[
                    for (final id in s.characterIds)
                      if (state.characterById(id) != null)
                        ActionChip(
                          avatar: CircleAvatar(
                            backgroundColor: charColor(
                              state.characterById(id)!.colorIndex,
                            ),
                          ),
                          label: Text(state.characterById(id)!.name),
                          onPressed: () {
                            Navigator.of(context).push(
                              MaterialPageRoute<void>(
                                builder: (_) =>
                                    CharacterDetailPage(characterId: id),
                              ),
                            );
                          },
                        ),
                    for (final t in s.tags) Chip(label: Text('#$t')),
                  ],
                ),
                const SizedBox(height: 12),
                SelectableText(
                  s.content,
                  style: Theme.of(
                    context,
                  ).textTheme.bodyLarge?.copyWith(height: 1.7),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Text(
              '本篇交际证据（${evidence.length}）',
              style: Theme.of(context).textTheme.titleSmall,
            ),
          ),
          if (evidence.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text('正文中没有识别到两个以上的人物提及。'),
            )
          else
            for (final e in evidence) _evidenceTile(context, state, e),
        ],
      ),
    );
  }

  Widget _evidenceTile(BuildContext context, AppState state, StoryEvidence e) {
    final from = state.characterById(e.fromId)?.name ?? '未知';
    final to = state.characterById(e.toId)?.name ?? '未知';
    final kindLabel = e.kind?.label ?? '共现';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            CircleAvatar(
              radius: 10,
              backgroundColor: e.kind == null
                  ? Colors.grey
                  : kindColor(e.kind!),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    '$from ⇄ $to · $kindLabel · 强度 ${e.score.round()}',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '「${e.snippet}」',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.outline,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDelete(
    BuildContext context,
    AppState state,
    Story s,
  ) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除「${s.title}」？'),
        content: const Text('删除后无法恢复。'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('取消'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
            ),
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (ok == true) {
      state.deleteStory(s.id);
      if (context.mounted) Navigator.of(context).pop();
    }
  }
}
