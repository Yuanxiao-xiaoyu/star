import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

/// 人物配色盘（按 Character.colorIndex 取模）。
const List<Color> characterPalette = <Color>[
  Color(0xFFE57373),
  Color(0xFFF06292),
  Color(0xFFBA68C8),
  Color(0xFF9575CD),
  Color(0xFF7986CB),
  Color(0xFF64B5F6),
  Color(0xFF4DB6AC),
  Color(0xFF81C784),
  Color(0xFFFFB74D),
  Color(0xFFA1887F),
];

Color charColor(int index) => characterPalette[index % characterPalette.length];

/// 关系类型 → 展示颜色。
Color kindColor(RelationKind kind) => switch (kind) {
  RelationKind.love => const Color(0xFFE91E63),
  RelationKind.family => const Color(0xFFFF9800),
  RelationKind.friendship => const Color(0xFF4CAF50),
  RelationKind.masterApprentice => const Color(0xFF9C27B0),
  RelationKind.colleague => const Color(0xFF009688),
  RelationKind.superior => const Color(0xFF3F51B5),
  RelationKind.enemy => const Color(0xFFD32F2F),
  RelationKind.alliance => const Color(0xFF2196F3),
  RelationKind.other => const Color(0xFF9E9E9E),
};

/// 关系来源徽章颜色。
Color sourceColor(RelationSource source) => switch (source) {
  RelationSource.manual => const Color(0xFF2E7D32),
  RelationSource.ai => const Color(0xFF6A1B9A),
  RelationSource.auto => const Color(0xFF546E7A),
};
