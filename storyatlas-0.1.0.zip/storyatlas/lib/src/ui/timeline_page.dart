import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../app.dart';
import 'character_detail_page.dart';
import 'palette.dart';
import 'story_detail_page.dart';
import 'util.dart';
import 'widgets.dart';

/// 时间交际线：按时间顺序排列的情节与人物交际。
class TimelinePage extends StatelessWidget {
  const TimelinePage({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final stories = state.sortedStories();
    if (stories.isEmpty) {
      return EmptyHint(
        icon: Icons.timeline,
        title: '还没有时间线',
        subtitle: '为情节设置发生时间后，\n人物交际将按时间顺序连成一条线。',
      );
    }

    // 按年份分组。
    final items = <_TimelineEntry>[];
    String? lastYear;
    for (final s in stories) {
      final year = s.time == null ? null : '${s.time!.year} 年';
      final label = year ?? '未注明时间';
      if (label != lastYear) {
        items.add(_TimelineEntry.header(label));
        lastYear = label;
      }
      items.add(_TimelineEntry.story(s));
    }

    return ListView.builder(
      padding: const EdgeInsets.only(top: 8, bottom: 88),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final entry = items[index];
        if (entry.isHeader) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 16, 8),
            child: Text(
              entry.label!,
              style: Theme.of(
                context,
              ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
          );
        }
        return _TimelineItem(story: entry.story!);
      },
    );
  }
}

class _TimelineEntry {
  const _TimelineEntry.header(this.label) : story = null;
  const _TimelineEntry.story(this.story) : label = null;

  final String? label;
  final Story? story;

  bool get isHeader => label != null;
}

/// 单条时间线节点：圆点 + 连线 + 情节卡片。
class _TimelineItem extends StatelessWidget {
  const _TimelineItem({required this.story});

  final Story story;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final evidence = state.evidenceOf(story.id);
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          SizedBox(
            width: 36,
            child: Column(
              children: <Widget>[
                const SizedBox(height: 14),
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: story.time == null
                        ? Colors.grey
                        : Theme.of(context).colorScheme.primary,
                  ),
                ),
                Expanded(
                  child: Container(
                    width: 2,
                    color: Theme.of(context).colorScheme.outlineVariant,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(4, 8, 12, 8),
              child: Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => StoryDetailPage(storyId: story.id),
                      ),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            Icon(
                              story.time == null
                                  ? Icons.help_outline
                                  : Icons.event,
                              size: 16,
                              color: Theme.of(context).colorScheme.outline,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              fmtDate(story.time),
                              style: Theme.of(context).textTheme.labelMedium
                                  ?.copyWith(
                                    color: Theme.of(
                                      context,
                                    ).colorScheme.primary,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                story.title,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 6,
                          runSpacing: 4,
                          children: <Widget>[
                            for (final id in story.characterIds)
                              if (state.characterById(id) != null)
                                ActionChip(
                                  avatar: CircleAvatar(
                                    backgroundColor: charColor(
                                      state.characterById(id)!.colorIndex,
                                    ),
                                  ),
                                  label: Text(state.characterById(id)!.name),
                                  visualDensity: VisualDensity.compact,
                                  onPressed: () {
                                    Navigator.of(context).push(
                                      MaterialPageRoute<void>(
                                        builder: (_) => CharacterDetailPage(
                                          characterId: id,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                          ],
                        ),
                        if (evidence.isNotEmpty) ...<Widget>[
                          const SizedBox(height: 8),
                          const Divider(height: 1),
                          const SizedBox(height: 8),
                          for (final e in evidence)
                            _evidenceLine(context, state, e),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _evidenceLine(BuildContext context, AppState state, StoryEvidence e) {
    final from = state.characterById(e.fromId)?.name ?? '未知';
    final to = state.characterById(e.toId)?.name ?? '未知';
    final kind = e.kind;
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          CircleAvatar(
            radius: 6,
            backgroundColor: kind == null ? Colors.grey : kindColor(kind),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              kind == null
                  ? '$from ⇄ $to 同篇共现'
                  : '$from ⇄ $to · ${kind.label} · 「${e.snippet}」',
              style: Theme.of(context).textTheme.bodySmall,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
