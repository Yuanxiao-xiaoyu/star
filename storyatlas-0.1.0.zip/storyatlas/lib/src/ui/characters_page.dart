import 'package:flutter/material.dart';

import '../app.dart';
import 'character_detail_page.dart';
import 'character_edit_page.dart';
import 'palette.dart';
import 'routes.dart';
import 'welcome_view.dart';

/// 人物列表页。
class CharactersPage extends StatelessWidget {
  const CharactersPage({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    if (state.isEmpty) {
      return WelcomeView(
        onCharacter: () =>
            Routes.push<void>(context, const CharacterEditPage()),
        onStory: () => Routes.push<void>(context,StoryEditPage()),
        onGenerate: () => Routes.generator<void>(context),
      );
    }
    final chars = state.data.characters;
    if (chars.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const Text('还没有人物'),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: () =>
                    Routes.push<void>(context, const CharacterEditPage()),
                icon: const Icon(Icons.person_add_alt),
                label: const Text('新建人物'),
              ),
            ],
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 88),
      itemCount: chars.length,
      itemBuilder: (context, index) {
        final c = chars[index];
        final relCount = state.relationsOf(c.id).length;
        final issueCount = state.report.ofCharacter(c.id).length;
        final color = charColor(c.colorIndex);
        return Card(
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: color,
              foregroundColor: Colors.white,
              child: Text(
                c.name.isEmpty ? '?' : c.name.characters.first,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            title: Row(
              children: <Widget>[
                Flexible(
                  child: Text(
                    c.name,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                if (c.traits.isNotEmpty) ...<Widget>[
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      c.traits.take(3).join('·'),
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: Theme.of(context).colorScheme.outline,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ],
            ),
            subtitle: Text(
              c.description.isNotEmpty
                  ? c.description
                  : (c.aliases.isEmpty
                        ? (c.goal.isNotEmpty ? '目标：${c.goal}' : '暂无简介')
                        : '别名：${c.aliases.join('、')}'),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            trailing: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                if (relCount > 0)
                  Text(
                    '$relCount 关系',
                    style: Theme.of(context).textTheme.labelSmall,
                  ),
                if (issueCount > 0)
                  Text(
                    '$issueCount 提示',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: const Color(0xFFEF6C00),
                    ),
                  ),
              ],
            ),
            onTap: () => Routes.push<void>(
              context,
              CharacterDetailPage(characterId: c.id),
            ),
          ),
        );
      },
    );
  }
}
