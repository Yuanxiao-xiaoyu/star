import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../app.dart';
import 'palette.dart';
import 'settings_page.dart';
import 'story_detail_page.dart';
import 'util.dart';

/// AI 创作：生成人物、生成情节、润色正文。
class GeneratorPage extends StatefulWidget {
  const GeneratorPage({super.key});

  @override
  State<GeneratorPage> createState() => _GeneratorPageState();
}

class _GeneratorPageState extends State<GeneratorPage>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  bool _busy = false;

  // 生成人物
  final _premise = TextEditingController();
  final _charReq = TextEditingController();
  int _charCount = 3;

  // 生成情节
  final _storyReq = TextEditingController();
  final Set<String> _castIds = <String>{};
  DateTime? _storyTime;

  // 润色
  String? _polishTargetId;
  final _polishReq = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    _premise.dispose();
    _charReq.dispose();
    _storyReq.dispose();
    _polishReq.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final aiReady =
        state.data.aiSettings.useAi &&
        state.data.aiSettings.apiKey.trim().isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        title: const Text('AI 创作'),
        bottom: TabBar(
          controller: _tabs,
          tabs: const <Widget>[
            Tab(text: '人物'),
            Tab(text: '情节'),
            Tab(text: '润色'),
          ],
        ),
      ),
      body: Column(
        children: <Widget>[
          if (!aiReady) _aiBanner(context, state),
          Expanded(
            child: TabBarView(
              controller: _tabs,
              children: <Widget>[
                _characterTab(context, state),
                _storyTab(context, state),
                _polishTab(context, state),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _aiBanner(BuildContext context, AppState state) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: theme.colorScheme.errorContainer.withValues(alpha: 0.4),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: <Widget>[
          Icon(
            Icons.key_off_outlined,
            color: theme.colorScheme.error,
            size: 20,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              '尚未配置 AI 接口。启用后才能真正生成内容；\n本地规则分析与体检始终可用。',
              style: theme.textTheme.bodySmall,
            ),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const SettingsPage()),
            ),
            child: const Text('去设置'),
          ),
        ],
      ),
    );
  }

  // ---------------- 人物 ----------------

  Widget _characterTab(BuildContext context, AppState state) {
    final theme = Theme.of(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      children: <Widget>[
        Text('题材 / 世界观', style: theme.textTheme.labelLarge),
        const SizedBox(height: 6),
        TextField(
          controller: _premise,
          maxLines: 2,
          decoration: const InputDecoration(hintText: '例如：民国小镇，医药世家与镖局之间的恩怨'),
        ),
        const SizedBox(height: 12),
        Text('具体要求', style: theme.textTheme.labelLarge),
        const SizedBox(height: 6),
        TextField(
          controller: _charReq,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: '例如：一个表面温和、实则记仇的女掌柜；不要出现超自然设定',
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: <Widget>[
            Text('生成数量', style: theme.textTheme.labelLarge),
            Expanded(
              child: Slider(
                value: _charCount.toDouble(),
                min: 1,
                max: 8,
                divisions: 7,
                label: '$_charCount',
                onChanged: (v) => setState(() => _charCount = v.round()),
              ),
            ),
            Text('$_charCount 个'),
          ],
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: _busy ? null : () => _generateCharacters(state),
          icon: _busy
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.auto_awesome),
          label: Text(_busy ? '生成中…' : '生成人物'),
        ),
        const SizedBox(height: 20),
        if (state.data.characters.isEmpty)
          Text(
            '还没有人物。生成结果会自动加入人物列表。',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.outline,
            ),
          )
        else ...<Widget>[
          Text(
            '当前人物（${state.data.characters.length}）',
            style: theme.textTheme.labelLarge,
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: <Widget>[
              for (final c in state.data.characters)
                Chip(
                  avatar: CircleAvatar(
                    backgroundColor: charColor(c.colorIndex),
                    radius: 8,
                  ),
                  label: Text(c.name),
                  visualDensity: VisualDensity.compact,
                ),
            ],
          ),
        ],
      ],
    );
  }

  Future<void> _generateCharacters(AppState state) async {
    setState(() => _busy = true);
    final result = await state.generateCharacters(
      premise: _premise.text.trim(),
      requirements: _charReq.text.trim(),
      count: _charCount,
    );
    if (!mounted) return;
    setState(() => _busy = false);
    if (result.error != null) {
      _snack(result.error!);
      return;
    }
    _snack(
      '已生成 ${result.created.length} 个人物：'
      '${result.created.map((c) => c.name).join('、')}',
    );
  }

  // ---------------- 情节 ----------------

  Widget _storyTab(BuildContext context, AppState state) {
    final theme = Theme.of(context);
    final chars = state.data.characters;
    if (chars.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text('请先生成或新建至少一个人物，再来生成情节。'),
        ),
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      children: <Widget>[
        Text('出场人物', style: theme.textTheme.labelLarge),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: <Widget>[
            for (final c in chars)
              FilterChip(
                label: Text(c.name),
                selected: _castIds.contains(c.id),
                onSelected: (v) => setState(() {
                  if (v) {
                    _castIds.add(c.id);
                  } else {
                    _castIds.remove(c.id);
                  }
                }),
              ),
          ],
        ),
        const SizedBox(height: 12),
        Text('发生时间', style: theme.textTheme.labelLarge),
        const SizedBox(height: 6),
        Row(
          children: <Widget>[
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _pickStoryDate,
                icon: const Icon(Icons.event_outlined),
                label: Text(_storyTime == null ? '选择时间' : fmtDate(_storyTime)),
              ),
            ),
            if (_storyTime != null)
              IconButton(
                tooltip: '清除',
                icon: const Icon(Icons.close),
                onPressed: () => setState(() => _storyTime = null),
              ),
          ],
        ),
        const SizedBox(height: 12),
        Text('情节要求', style: theme.textTheme.labelLarge),
        const SizedBox(height: 6),
        TextField(
          controller: _storyReq,
          maxLines: 3,
          decoration: const InputDecoration(hintText: '例如：两人因为一桩旧案起冲突，结尾留下悬念'),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: _busy ? null : () => _generateStory(state),
          icon: _busy
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.auto_awesome),
          label: Text(_busy ? '生成中…' : '生成情节'),
        ),
      ],
    );
  }

  Future<void> _pickStoryDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _storyTime ?? now,
      firstDate: DateTime(1),
      lastDate: DateTime(now.year + 10),
    );
    if (picked != null) {
      setState(
        () => _storyTime = DateTime(picked.year, picked.month, picked.day),
      );
    }
  }

  Future<void> _generateStory(AppState state) async {
    if (_castIds.isEmpty) {
      _snack('请至少选择一位出场人物');
      return;
    }
    setState(() => _busy = true);
    final result = await state.generateStory(
      castIds: _castIds.toList(growable: false),
      requirements: _storyReq.text.trim(),
      time: _storyTime,
    );
    if (!mounted) return;
    setState(() => _busy = false);
    final story = result.story;
    if (result.error != null || story == null) {
      _snack(result.error ?? '生成失败');
      return;
    }
    _snack('已生成《${story.title}》');
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => StoryDetailPage(storyId: story.id),
      ),
    );
  }

  // ---------------- 润色 ----------------

  Widget _polishTab(BuildContext context, AppState state) {
    final theme = Theme.of(context);
    final stories = state.sortedStories();
    if (stories.isEmpty) {
      return const Center(
        child: Padding(padding: EdgeInsets.all(32), child: Text('还没有情节可以润色。')),
      );
    }
    final target = _polishTargetId == null
        ? null
        : state.storyById(_polishTargetId!);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      children: <Widget>[
        Text('选择要润色的情节', style: theme.textTheme.labelLarge),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _polishTargetId,
          isExpanded: true,
          items: <DropdownMenuItem<String>>[
            for (final s in stories)
              DropdownMenuItem<String>(
                value: s.id,
                child: Text(
                  '${fmtDate(s.time)} · ${s.title}',
                  overflow: TextOverflow.ellipsis,
                ),
              ),
          ],
          onChanged: (v) => setState(() => _polishTargetId = v),
        ),
        if (target != null) ...<Widget>[
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              target.content,
              maxLines: 8,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodySmall,
            ),
          ),
        ],
        const SizedBox(height: 12),
        Text('润色要求', style: theme.textTheme.labelLarge),
        const SizedBox(height: 6),
        TextField(
          controller: _polishReq,
          maxLines: 2,
          decoration: const InputDecoration(hintText: '例如：更口语化；保留原意；增强打斗画面感'),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: _busy || target == null
              ? null
              : () => _polish(state, target.id),
          icon: _busy
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.auto_fix_high),
          label: Text(_busy ? '处理中…' : '润色并覆盖正文'),
        ),
        const SizedBox(height: 8),
        Text(
          '润色会直接覆盖该情节的正文，建议先导出备份。',
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.outline,
          ),
        ),
      ],
    );
  }

  Future<void> _polish(AppState state, String storyId) async {
    setState(() => _busy = true);
    final error = await state.polishStory(
      storyId,
      requirements: _polishReq.text.trim(),
    );
    if (!mounted) return;
    setState(() => _busy = false);
    _snack(error ?? '已润色并保存');
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }
}
