import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../app.dart';
import 'palette.dart';

/// 新建 / 编辑人物：姓名、别名、性格、外貌、背景、目标、生卒年。
class CharacterEditPage extends StatefulWidget {
  const CharacterEditPage({super.key, this.initial});

  final Character? initial;

  @override
  State<CharacterEditPage> createState() => _CharacterEditPageState();
}

class _CharacterEditPageState extends State<CharacterEditPage> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _aliases;
  late final TextEditingController _description;
  late final TextEditingController _appearance;
  late final TextEditingController _background;
  late final TextEditingController _goal;
  late final TextEditingController _birthYear;
  late final TextEditingController _deathYear;
  late int _colorIndex;
  late List<String> _traits;

  static const List<String> _traitPresets = <String>[
    '沉稳',
    '温和',
    '果敢',
    '多疑',
    '护短',
    '狡黠',
    '执拗',
    '隐忍',
    '天真',
    '冷酷',
    '重情',
    '孤傲',
    '投机',
    '刀子嘴豆腐心',
  ];

  @override
  void initState() {
    super.initState();
    final c = widget.initial;
    _name = TextEditingController(text: c?.name ?? '');
    _aliases = TextEditingController(text: c?.aliases.join('、') ?? '');
    _description = TextEditingController(text: c?.description ?? '');
    _appearance = TextEditingController(text: c?.appearance ?? '');
    _background = TextEditingController(text: c?.background ?? '');
    _goal = TextEditingController(text: c?.goal ?? '');
    _birthYear = TextEditingController(text: c?.birthYear?.toString() ?? '');
    _deathYear = TextEditingController(text: c?.deathYear?.toString() ?? '');
    _colorIndex = c?.colorIndex ?? 0;
    _traits = List<String>.of(c?.traits ?? const <String>[]);
  }

  @override
  void dispose() {
    _name.dispose();
    _aliases.dispose();
    _description.dispose();
    _appearance.dispose();
    _background.dispose();
    _goal.dispose();
    _birthYear.dispose();
    _deathYear.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final state = AppScope.of(context);
    final initial = widget.initial;
    final aliases = _split(_aliases.text);
    final birth = int.tryParse(_birthYear.text.trim());
    final death = int.tryParse(_deathYear.text.trim());
    final character =
        (initial ?? Character(id: newId('char'), name: _name.text.trim()))
            .copyWith(
              name: _name.text.trim(),
              aliases: aliases,
              description: _description.text.trim(),
              traits: _traits,
              appearance: _appearance.text.trim(),
              background: _background.text.trim(),
              goal: _goal.text.trim(),
              birthYear: birth,
              clearBirthYear: birth == null,
              deathYear: death,
              clearDeathYear: death == null,
              colorIndex: _colorIndex,
            );
    state.upsertCharacter(character);
    Navigator.of(context).pop();
  }

  List<String> _split(String text) => text
      .split(RegExp(r'[、,，\s]+'))
      .where((s) => s.trim().isNotEmpty)
      .map((s) => s.trim())
      .toList(growable: true);

  @override
  Widget build(BuildContext context) {
    final editing = widget.initial != null;
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(editing ? '编辑人物' : '新建人物')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 40),
          children: <Widget>[
            TextFormField(
              controller: _name,
              decoration: const InputDecoration(
                labelText: '姓名 *',
                helperText: '正文中会用这个名字识别人物',
              ),
              textInputAction: TextInputAction.next,
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? '请填写姓名' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _aliases,
              decoration: const InputDecoration(
                labelText: '别名 / 称呼',
                helperText: '用顿号或逗号分隔，如：砚秋、沈先生',
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _description,
              decoration: const InputDecoration(labelText: '一句话简介'),
              maxLines: 2,
            ),
            const SizedBox(height: 20),
            Text('性格 · 特点', style: theme.textTheme.labelLarge),
            const SizedBox(height: 6),
            Text(
              '标签会参与体检：例如标了「温和」却频繁主动施暴时，会提醒你复核。',
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.outline,
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: <Widget>[
                for (final t in _traitPresets)
                  FilterChip(
                    label: Text(t),
                    selected: _traits.contains(t),
                    onSelected: (v) => setState(() {
                      if (v) {
                        _traits.add(t);
                      } else {
                        _traits.remove(t);
                      }
                    }),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            _TraitInput(
              traits: _traits,
              onAdd: (value) {
                final t = value.trim();
                if (t.isEmpty || _traits.contains(t)) return;
                setState(() => _traits.add(t));
              },
              onRemove: (t) => setState(() => _traits.remove(t)),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: _appearance,
              decoration: const InputDecoration(labelText: '外貌'),
              maxLines: 2,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _background,
              decoration: const InputDecoration(labelText: '背景 / 出身'),
              maxLines: 3,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _goal,
              decoration: const InputDecoration(
                labelText: '目标 / 动机',
                helperText: 'TA 想要什么？这会成为情节的驱动力',
              ),
              maxLines: 2,
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                Expanded(
                  child: TextFormField(
                    controller: _birthYear,
                    decoration: const InputDecoration(
                      labelText: '出生年份',
                      helperText: '可选，用于时间线体检',
                    ),
                    keyboardType: TextInputType.number,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _deathYear,
                    decoration: const InputDecoration(
                      labelText: '去世年份',
                      helperText: '可选，用于「死后出场」检查',
                    ),
                    keyboardType: TextInputType.number,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Text('代表色', style: theme.textTheme.labelLarge),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: <Widget>[
                for (var i = 0; i < characterPalette.length; i++)
                  InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () => setState(() => _colorIndex = i),
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: characterPalette[i],
                        shape: BoxShape.circle,
                        border: _colorIndex == i
                            ? Border.all(
                                color: theme.colorScheme.primary,
                                width: 3,
                              )
                            : null,
                      ),
                      child: _colorIndex == i
                          ? const Icon(
                              Icons.check,
                              color: Colors.white,
                              size: 20,
                            )
                          : null,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 28),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save_outlined),
              label: const Text('保存'),
            ),
          ],
        ),
      ),
    );
  }
}

/// 自定义性格标签输入。
class _TraitInput extends StatefulWidget {
  const _TraitInput({
    required this.traits,
    required this.onAdd,
    required this.onRemove,
  });

  final List<String> traits;
  final ValueChanged<String> onAdd;
  final ValueChanged<String> onRemove;

  @override
  State<_TraitInput> createState() => _TraitInputState();
}

class _TraitInputState extends State<_TraitInput> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    widget.onAdd(text);
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        if (widget.traits.isNotEmpty)
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: <Widget>[
              for (final t in widget.traits)
                InputChip(
                  label: Text(t),
                  onDeleted: () => widget.onRemove(t),
                  visualDensity: VisualDensity.compact,
                ),
            ],
          ),
        Row(
          children: <Widget>[
            Expanded(
              child: TextField(
                controller: _controller,
                decoration: const InputDecoration(
                  hintText: '自定义标签，回车添加',
                  isDense: true,
                ),
                onSubmitted: (_) => _submit(),
              ),
            ),
            IconButton(
              tooltip: '添加标签',
              icon: const Icon(Icons.add),
              onPressed: _submit,
            ),
          ],
        ),
      ],
    );
  }
}
