import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../app.dart';
import 'character_edit_page.dart';
import 'palette.dart';
import 'relation_edit_page.dart';
import 'story_detail_page.dart';
import 'util.dart';
import 'widgets.dart';

/// 人物详情：简介、关系、相关情节。
class CharacterDetailPage extends StatelessWidget {
  const CharacterDetailPage({super.key, required this.characterId});

  final String characterId;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final c = state.characterById(characterId);
    if (c == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('人物')),
        body: const EmptyHint(icon: Icons.person_off, title: '人物不存在'),
      );
    }
    final relations = state.relationsOf(c.id);
    final stories = state.storiesOf(c.id);
    final color = charColor(c.colorIndex);
    return Scaffold(
      appBar: AppBar(
        title: Text(c.name),
        actions: <Widget>[
          IconButton(
            tooltip: '编辑',
            icon: const Icon(Icons.edit_outlined),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => CharacterEditPage(initial: c),
                ),
              );
            },
          ),
          IconButton(
            tooltip: '删除',
            icon: const Icon(Icons.delete_outline),
            onPressed: () => _confirmDelete(context, state, c),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: <Widget>[
                CircleAvatar(
                  radius: 28,
                  backgroundColor: color,
                  foregroundColor: Colors.white,
                  child: Text(
                    c.name.isEmpty ? '?' : c.name.characters.first,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        c.name,
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      if (c.aliases.isNotEmpty)
                        Text(
                          '别名：${c.aliases.join('、')}',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      Text(c.description.isEmpty ? '暂无简介' : c.description),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: FilledButton.tonalIcon(
              onPressed: () {
                state.mindmapRootId = c.id;
                state.switchTab(3);
                Navigator.of(context).popUntil((r) => r.isFirst);
              },
              icon: const Icon(Icons.hub_outlined),
              label: const Text('以 TA 为根查看思维视图'),
            ),
          ),
          _sectionTitle(context, '人际关系（${relations.length}）'),
          if (relations.isEmpty)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('暂无关系。写下 TA 的情节后会自动分析。'),
            )
          else
            for (final r in relations) _relationTile(context, state, c, r),
          _sectionTitle(context, '相关情节（${stories.length}）'),
          if (stories.isEmpty)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('暂无情节。去「情节」页写一篇吧。'),
            )
          else
            for (final s in stories)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.menu_book_outlined),
                  title: Text(s.title),
                  subtitle: Text(
                    '${fmtDate(s.time)} · ${truncate(s.content, 40)}',
                  ),
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => StoryDetailPage(storyId: s.id),
                      ),
                    );
                  },
                ),
              ),
        ],
      ),
    );
  }

  Widget _sectionTitle(BuildContext context, String text) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
    child: Text(text, style: Theme.of(context).textTheme.titleSmall),
  );

  Widget _relationTile(
    BuildContext context,
    AppState state,
    Character c,
    Relation r,
  ) {
    final other = state.characterById(r.otherOf(c.id));
    final otherName = other?.name ?? '未知人物';
    return Card(
      child: ListTile(
        leading: CircleAvatar(radius: 14, backgroundColor: kindColor(r.kind)),
        title: Text(
          r.kind.isDirected && r.fromId == c.id
              ? relationTitle(c.name, otherName, '→')
              : relationTitle(otherName, c.name, r.arrow),
        ),
        subtitle: Text(
          '${r.kind.label} · ${r.source.label} · 强度 ${r.weight.round()}'
          '${r.note.isEmpty ? '' : '\n${r.note}'}',
        ),
        isThreeLine: r.note.isNotEmpty,
        trailing: PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'edit') {
              Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => RelationEditPage(initial: r),
                ),
              );
            } else if (v == 'delete') {
              state.deleteRelation(r.id);
            }
          },
          itemBuilder: (context) => const <PopupMenuEntry<String>>[
            PopupMenuItem<String>(value: 'edit', child: Text('手动修正')),
            PopupMenuItem<String>(value: 'delete', child: Text('删除 / 忽略')),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDelete(
    BuildContext context,
    AppState state,
    Character c,
  ) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('删除「${c.name}」？'),
        content: const Text('将同时移除与 TA 相关的所有关系，并取消情节中对该人物的关联。'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('取消'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
            ),
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (ok == true) {
      state.deleteCharacter(c.id);
      if (context.mounted) Navigator.of(context).pop();
    }
  }
}
