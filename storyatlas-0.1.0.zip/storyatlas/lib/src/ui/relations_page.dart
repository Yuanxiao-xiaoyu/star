import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../app.dart';
import 'palette.dart';
import 'relation_edit_page.dart';
import 'widgets.dart';

/// 关系列表：筛选、查看、修正、删除 / 忽略。
class RelationsPage extends StatefulWidget {
  const RelationsPage({super.key});

  @override
  State<RelationsPage> createState() => _RelationsPageState();
}

class _RelationsPageState extends State<RelationsPage> {
  RelationKind? _filter;

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final all = state.analysis.relations;
    final relations = _filter == null
        ? all
        : all.where((r) => r.kind == _filter).toList(growable: true);
    return Scaffold(
      appBar: AppBar(title: Text('人际关系（${all.length}）')),
      floatingActionButton: state.data.characters.length >= 2
          ? FloatingActionButton(
              tooltip: '手动添加关系',
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const RelationEditPage(),
                  ),
                );
              },
              child: const Icon(Icons.add),
            )
          : null,
      body: Column(
        children: <Widget>[
          SizedBox(
            height: 52,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: const Text('全部'),
                    selected: _filter == null,
                    onSelected: (_) => setState(() => _filter = null),
                  ),
                ),
                for (final kind in RelationKind.values)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      avatar: CircleAvatar(
                        backgroundColor: kindColor(kind),
                        radius: 8,
                      ),
                      label: Text(kind.label),
                      selected: _filter == kind,
                      onSelected: (_) => setState(() => _filter = kind),
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: relations.isEmpty
                ? EmptyHint(
                    icon: Icons.account_tree_outlined,
                    title: '暂无关系',
                    subtitle: _filter == null
                        ? '写下两个以上人物共同出场的情节，\n或点右下角手动添加。'
                        : '该类型下没有关系。',
                  )
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 88),
                    itemCount: relations.length,
                    itemBuilder: (context, index) {
                      final r = relations[index];
                      final from = state.characterById(r.fromId)?.name ?? '未知';
                      final to = state.characterById(r.toId)?.name ?? '未知';
                      return Card(
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: kindColor(r.kind),
                            child: Text(
                              r.kind.label.characters.first,
                              style: const TextStyle(color: Colors.white),
                            ),
                          ),
                          title: Text(
                            '$from ${r.arrow} $to',
                            style: const TextStyle(fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(
                            '${r.kind.label} · ${r.source.label} · 强度 ${r.weight.round()}'
                            '${r.note.isEmpty ? '' : '\n${r.note}'}',
                          ),
                          isThreeLine: r.note.isNotEmpty,
                          trailing: PopupMenuButton<String>(
                            onSelected: (v) => _onAction(context, state, r, v),
                            itemBuilder: (context) =>
                                const <PopupMenuEntry<String>>[
                                  PopupMenuItem<String>(
                                    value: 'edit',
                                    child: Text('手动修正'),
                                  ),
                                  PopupMenuItem<String>(
                                    value: 'delete',
                                    child: Text('删除 / 忽略'),
                                  ),
                                ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _onAction(
    BuildContext context,
    AppState state,
    Relation r,
    String action,
  ) {
    if (action == 'edit') {
      Navigator.of(context).push(
        MaterialPageRoute<void>(builder: (_) => RelationEditPage(initial: r)),
      );
    } else if (action == 'delete') {
      state.deleteRelation(r.id);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            r.source == RelationSource.manual
                ? '已删除该关系'
                : '已忽略该关系（可在手动关系中重新添加）',
          ),
        ),
      );
    }
  }
}
