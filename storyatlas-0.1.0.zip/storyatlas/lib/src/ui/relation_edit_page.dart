import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../app.dart';

/// 新建 / 修正关系（保存后均为手动关系，优先级最高）。
class RelationEditPage extends StatefulWidget {
  const RelationEditPage({super.key, this.initial});

  final Relation? initial;

  @override
  State<RelationEditPage> createState() => _RelationEditPageState();
}

class _RelationEditPageState extends State<RelationEditPage> {
  String? _fromId;
  String? _toId;
  RelationKind _kind = RelationKind.other;
  double _weight = 50;
  late final TextEditingController _note;

  @override
  void initState() {
    super.initState();
    final r = widget.initial;
    _fromId = r?.fromId;
    _toId = r?.toId;
    _kind = r?.kind ?? RelationKind.other;
    _weight = r?.weight ?? 50;
    _note = TextEditingController(text: r?.note ?? '');
  }

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  void _save() {
    final fromId = _fromId;
    final toId = _toId;
    if (fromId == null || toId == null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('请选择关系的双方人物')));
      return;
    }
    if (fromId == toId) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('关系的双方不能是同一人')));
      return;
    }
    final state = AppScope.of(context);
    final existing = widget.initial;
    final relation =
        existing != null && existing.source == RelationSource.manual
        ? existing.copyWith(
            fromId: fromId,
            toId: toId,
            kind: _kind,
            weight: _weight,
            note: _note.text.trim(),
            updatedAt: DateTime.now(),
          )
        : Relation(
            id: newId('rel'),
            fromId: fromId,
            toId: toId,
            kind: _kind,
            weight: _weight,
            source: RelationSource.manual,
            note: _note.text.trim(),
            updatedAt: DateTime.now(),
          );
    state.upsertRelation(relation);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final chars = state.data.characters;
    if (chars.length < 2) {
      return Scaffold(
        appBar: AppBar(title: const Text('编辑关系')),
        body: const Center(child: Text('至少需要两个人物才能建立关系。')),
      );
    }
    final kindDirected = _kind.isDirected;
    return Scaffold(
      appBar: AppBar(title: Text(widget.initial == null ? '手动添加关系' : '修正关系')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: <Widget>[
          _LabeledDropdown<String>(
            label: kindDirected ? '主动方 / 上位方 *' : '人物甲 *',
            value: _fromId,
            items: <DropdownMenuItem<String>>[
              for (final c in chars)
                DropdownMenuItem<String>(value: c.id, child: Text(c.name)),
            ],
            onChanged: (v) => setState(() => _fromId = v),
          ),
          const SizedBox(height: 12),
          _LabeledDropdown<String>(
            label: kindDirected ? '被动方 / 下位方 *' : '人物乙 *',
            value: _toId,
            items: <DropdownMenuItem<String>>[
              for (final c in chars)
                DropdownMenuItem<String>(value: c.id, child: Text(c.name)),
            ],
            onChanged: (v) => setState(() => _toId = v),
          ),
          const SizedBox(height: 12),
          _LabeledDropdown<RelationKind>(
            label: '关系类型 *',
            helper: kindDirected
                ? '有向关系：箭头从主动方 / 上位方指向被动方 / 下位方'
                : '无向关系：不区分方向',
            value: _kind,
            items: <DropdownMenuItem<RelationKind>>[
              for (final k in RelationKind.values)
                DropdownMenuItem<RelationKind>(
                  value: k,
                  child: Text('${k.label}${k.isDirected ? '（有向）' : ''}'),
                ),
            ],
            onChanged: (v) => setState(() => _kind = v ?? RelationKind.other),
          ),
          const SizedBox(height: 12),
          Text(
            '关系强度：${_weight.round()} / 100',
            style: Theme.of(context).textTheme.labelLarge,
          ),
          Slider(
            value: _weight,
            min: 1,
            max: 100,
            divisions: 99,
            label: '${_weight.round()}',
            onChanged: (v) => setState(() => _weight = v),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _note,
            decoration: const InputDecoration(
              labelText: '备注',
              helperText: '这段关系的说明或原文依据',
            ),
            maxLines: 3,
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save_outlined),
            label: const Text('保存'),
          ),
        ],
      ),
    );
  }
}

/// 带浮动标签的下拉框：用 DropdownButton + InputDecorator 组合，
/// 避免依赖 DropdownButtonFormField 在不同 Flutter 版本间的参数改名。
class _LabeledDropdown<T> extends StatelessWidget {
  const _LabeledDropdown({
    required this.label,
    required this.value,
    required this.items,
    required this.onChanged,
    this.helper,
  });

  final String label;
  final T? value;
  final List<DropdownMenuItem<T>> items;
  final ValueChanged<T?> onChanged;
  final String? helper;

  @override
  Widget build(BuildContext context) {
    return InputDecorator(
      decoration: InputDecoration(labelText: label, helperText: helper),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<T>(
          isExpanded: true,
          isDense: true,
          value: value,
          hint: Text(label.replaceAll(' *', '')),
          items: items,
          onChanged: onChanged,
        ),
      ),
    );
  }
}
