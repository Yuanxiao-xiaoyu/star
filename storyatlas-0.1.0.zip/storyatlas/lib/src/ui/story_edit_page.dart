import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../app.dart';
import 'util.dart';

/// 新建 / 编辑情节。
class StoryEditPage extends StatefulWidget {
  const StoryEditPage({super.key, this.initial});

  final Story? initial;

  @override
  State<StoryEditPage> createState() => _StoryEditPageState();
}

class _StoryEditPageState extends State<StoryEditPage> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _title;
  late final TextEditingController _content;
  late final TextEditingController _tags;
  late final TextEditingController _location;
  DateTime? _time;
  late final Set<String> _characterIds;

  @override
  void initState() {
    super.initState();
    final s = widget.initial;
    _title = TextEditingController(text: s?.title ?? '');
    _content = TextEditingController(text: s?.content ?? '');
    _tags = TextEditingController(text: s?.tags.join('、') ?? '');
    _location = TextEditingController(text: s?.location ?? '');
    _time = s?.time;
    _characterIds = Set<String>.of(s?.characterIds ?? const <String>[]);
  }

  @override
  void dispose() {
    _title.dispose();
    _content.dispose();
    _tags.dispose();
    _location.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _time ?? now,
      firstDate: DateTime(1),
      lastDate: DateTime(now.year + 10),
    );
    if (picked != null) {
      setState(() {
        _time = DateTime(
          picked.year,
          picked.month,
          picked.day,
          _time?.hour ?? 12,
          _time?.minute ?? 0,
        );
      });
    }
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final state = AppScope.of(context);
    final initial = widget.initial;
    final tags = _tags.text
        .split(RegExp(r'[、,，\s]+'))
        .where((s) => s.trim().isNotEmpty)
        .map((s) => s.trim())
        .toList(growable: true);
    final story =
        (initial ??
                Story(
                  id: newId('story'),
                  title: _title.text.trim(),
                  content: _content.text.trim(),
                ))
            .copyWith(
              title: _title.text.trim(),
              content: _content.text.trim(),
              time: _time,
              clearTime: _time == null,
              location: _location.text.trim(),
              characterIds: _characterIds.toList(growable: true),
              tags: tags,
            );
    state.upsertStory(story);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppScope.of(context);
    final editing = widget.initial != null;
    return Scaffold(
      appBar: AppBar(title: Text(editing ? '编辑情节' : '新建情节')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: <Widget>[
            TextFormField(
              controller: _title,
              decoration: const InputDecoration(labelText: '标题 *'),
              textInputAction: TextInputAction.next,
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? '请填写标题' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _location,
              decoration: const InputDecoration(
                labelText: '地点',
                helperText: '这场戏发生在哪里（可选）',
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _pickDate,
                    icon: const Icon(Icons.event_outlined),
                    label: Text(_time == null ? '选择发生时间' : fmtDate(_time)),
                  ),
                ),
                if (_time != null)
                  IconButton(
                    tooltip: '清除时间',
                    icon: const Icon(Icons.close),
                    onPressed: () => setState(() => _time = null),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _content,
              decoration: const InputDecoration(
                labelText: '正文 *',
                alignLabelWithHint: true,
                helperText: '正文是人物关系分析的依据：写出人物姓名（含别名），引擎会判断上下文中的关系。',
              ),
              maxLines: 10,
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? '请填写正文' : null,
            ),
            const SizedBox(height: 12),
            Text('关联人物（可多选）', style: Theme.of(context).textTheme.labelLarge),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: <Widget>[
                for (final c in state.data.characters)
                  FilterChip(
                    label: Text(c.name),
                    selected: _characterIds.contains(c.id),
                    onSelected: (v) {
                      setState(() {
                        if (v) {
                          _characterIds.add(c.id);
                        } else {
                          _characterIds.remove(c.id);
                        }
                      });
                    },
                  ),
              ],
            ),
            if (state.data.characters.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text('还没有人物，先在「人物」页创建。'),
              ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _tags,
              decoration: const InputDecoration(
                labelText: '标签',
                helperText: '用顿号或逗号分隔，如：命案、决斗',
              ),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save_outlined),
              label: const Text('保存并自动分析'),
            ),
          ],
        ),
      ),
    );
  }
}
