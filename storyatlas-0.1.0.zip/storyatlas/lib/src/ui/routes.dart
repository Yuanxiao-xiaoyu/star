import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../app.dart';
import 'check_page.dart';
import 'generator_page.dart';

/// 统一入口：把页面打开动作集中在这里，避免各处重复写 MaterialPageRoute。
class Routes {
  const Routes._();

  static Future<T?> push<T>(BuildContext context, Widget page) =>
      Navigator.of(context).push<T>(MaterialPageRoute<T>(builder: (_) => page));

  static Future<T?> generator<T>(BuildContext context) =>
      push<T>(context, const GeneratorPage());

  static Future<T?> check<T>(BuildContext context) =>
      push<T>(context, const CheckPage());

  /// 跳转到主界面的某个视图（先关掉当前页面栈）。
  static void toTab(BuildContext context, int index) {
    AppScope.of(context).switchTab(index);
    Navigator.of(context).popUntil((r) => r.isFirst);
  }
}

/// 体检问题列表项，供体检页与详情页复用。
class IssueTile extends StatelessWidget {
  const IssueTile({super.key, required this.issue, this.onTap});

  final StoryIssue issue;
  final VoidCallback? onTap;

  static IconData iconOf(IssueSeverity s) => switch (s) {
    IssueSeverity.error => Icons.error_outline,
    IssueSeverity.warning => Icons.warning_amber_outlined,
    IssueSeverity.info => Icons.info_outline,
  };

  static Color colorOf(BuildContext context, IssueSeverity s) => switch (s) {
    IssueSeverity.error => Theme.of(context).colorScheme.error,
    IssueSeverity.warning => const Color(0xFFEF6C00),
    IssueSeverity.info => Theme.of(context).colorScheme.outline,
  };

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = colorOf(context, issue.severity);
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Icon(iconOf(issue.severity), color: color, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Text(
                            issue.title,
                            style: theme.textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: color.withValues(alpha: 0.12),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            issue.category.label,
                            style: theme.textTheme.labelSmall?.copyWith(
                              color: color,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(issue.message, style: theme.textTheme.bodySmall),
                    if (issue.suggestion.isNotEmpty) ...<Widget>[
                      const SizedBox(height: 6),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Icon(
                            Icons.lightbulb_outline,
                            size: 14,
                            color: theme.colorScheme.outline,
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              issue.suggestion,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: theme.colorScheme.outline,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
