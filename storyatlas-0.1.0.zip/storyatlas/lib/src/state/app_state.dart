import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../services/ai_service.dart';
import '../services/data_store.dart';

/// 全局应用状态：数据、分析结果、体检报告、增删改查与持久化。
class AppState extends ChangeNotifier {
  AppState({required DataStore store, AiService? aiService})
    : _store = store,
      _aiService = aiService;

  final DataStore _store;
  final AiService? _aiService;

  ProjectData data = ProjectData();
  AnalysisResult analysis = const AnalysisResult(relations: []);
  CheckReport report = const CheckReport(<StoryIssue>[]);

  /// 数据版本号，每次变化 +1，供图视图判断是否需要重算布局。
  int revision = 0;

  Timer? _saveTimer;

  // ---- 跨页导航意图 ----

  /// 从其他页面跳到「思维视图」时指定的根人物 ID。
  String? mindmapRootId;

  /// 主界面当前标签页索引（0 人物 / 1 情节 / 2 时间线 / 3 思维图 / 4 关系网）。
  int homeTab = 0;

  void switchTab(int index) {
    homeTab = index;
    notifyListeners();
  }

  // ---- 生命周期 ----

  Future<void> load() async {
    final stored = await _store.load();
    if (stored != null) data = stored;
    _recompute();
    notifyListeners();
  }

  void _recompute() {
    analysis = RelationEngine.analyze(
      characters: data.characters,
      stories: data.stories,
      manual: data.relations,
      ai: data.aiRelations,
      ignoredPairs: data.ignoredPairs.toSet(),
    );
    report = ConsistencyChecker.check(
      characters: data.characters,
      stories: data.stories,
      manual: data.relations,
      ai: data.aiRelations,
    );
  }

  void _markDirty() {
    data.updatedAt = DateTime.now();
    _recompute();
    revision++;
    notifyListeners();
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 600), () {
      unawaited(_store.save(data));
    });
  }

  /// 外部直接替换 [data] 后调用，重新计算分析与体检。
  void refresh() {
    _recompute();
    revision++;
    notifyListeners();
  }

  // ---- 人物 ----

  void upsertCharacter(Character c) {
    final list = List<Character>.of(data.characters);
    final idx = list.indexWhere((x) => x.id == c.id);
    if (idx < 0) {
      list.add(c);
    } else {
      list[idx] = c;
    }
    data.characters = list;
    _markDirty();
  }

  void addCharacters(Iterable<Character> list) {
    data.characters = <Character>[...data.characters, ...list];
    _markDirty();
  }

  void deleteCharacter(String id) {
    data.characters = data.characters
        .where((c) => c.id != id)
        .toList(growable: true);
    data.stories = [
      for (final s in data.stories)
        s.copyWith(
          characterIds: s.characterIds
              .where((x) => x != id)
              .toList(growable: true),
        ),
    ];
    data.relations = data.relations
        .where((r) => !r.involves(id))
        .toList(growable: true);
    data.aiRelations = data.aiRelations
        .where((r) => !r.involves(id))
        .toList(growable: true);
    data.ignoredPairs = data.ignoredPairs
        .where((p) => !p.contains('$id\u0000') && !p.contains('\u0000$id'))
        .toList(growable: true);
    _markDirty();
  }

  // ---- 情节 ----

  void upsertStory(Story s) {
    final list = List<Story>.of(data.stories);
    final idx = list.indexWhere((x) => x.id == s.id);
    if (idx < 0) {
      list.add(s);
    } else {
      list[idx] = s;
    }
    data.stories = list;
    _markDirty();
  }

  void addStory(Story s) {
    data.stories = <Story>[...data.stories, s];
    _markDirty();
  }

  void deleteStory(String id) {
    data.stories = data.stories.where((s) => s.id != id).toList(growable: true);
    _markDirty();
  }

  // ---- 关系 ----

  /// 保存一条手动关系（同对人物只保留一条手动关系）。
  void upsertRelation(Relation r) {
    final pair = r.unorderedPairKey;
    data.relations = [
      for (final x in data.relations)
        if (x.unorderedPairKey != pair) x,
      r,
    ];
    data.ignoredPairs = data.ignoredPairs
        .where((p) => p != pair)
        .toList(growable: true);
    _markDirty();
  }

  /// 删除一条关系：手动关系直接删除；自动 / AI 关系加入忽略列表。
  void deleteRelation(String id) {
    Relation? manual;
    for (final r in data.relations) {
      if (r.id == id) {
        manual = r;
        break;
      }
    }
    if (manual != null) {
      data.relations = data.relations
          .where((r) => r.id != id)
          .toList(growable: true);
    } else {
      Relation? target;
      for (final r in analysis.relations) {
        if (r.id == id) {
          target = r;
          break;
        }
      }
      if (target != null) {
        if (target.source == RelationSource.ai) {
          data.aiRelations = data.aiRelations
              .where((r) => r.id != id)
              .toList(growable: true);
        } else {
          data.ignoredPairs = List<String>.of(data.ignoredPairs)
            ..add(target.unorderedPairKey);
        }
      }
    }
    _markDirty();
  }

  // ---- AI ----

  ChatFn? get chatFn {
    final svc = _aiService;
    if (svc == null) return null;
    return (messages) => svc.chat(data.aiSettings, messages);
  }

  /// 检查 AI 是否可用，返回错误提示；可用时返回 null。
  String? _aiGuard() {
    if (!data.aiSettings.useAi) return '请先在设置中开启 AI 分析';
    if (data.aiSettings.apiKey.trim().isEmpty) return '请先填写 API 密钥';
    return null;
  }

  /// 运行 AI 关系分析；成功返回 null，失败返回错误信息。
  Future<String?> runAiAnalysis() async {
    final guard = _aiGuard();
    if (guard != null) return guard;
    final chat = chatFn;
    if (chat == null) return 'AI 服务未初始化';
    try {
      final rels = await AiAnalyzer.analyze(
        chat: chat,
        characters: data.characters,
        stories: data.stories,
        known: data.relations,
      );
      if (rels.isEmpty) return 'AI 未返回有效的关系数据';
      data.aiRelations = rels;
      _markDirty();
      return null;
    } catch (e) {
      return 'AI 分析失败：$e';
    }
  }

  Future<bool> testAiConnection() async {
    final svc = _aiService;
    if (svc == null) return false;
    try {
      return await svc.testConnection(data.aiSettings);
    } catch (_) {
      return false;
    }
  }

  void updateAiSettings(AiSettings s) {
    data.aiSettings = s;
    _markDirty();
  }

  void clearAiRelations() {
    data.aiRelations = [];
    _markDirty();
  }

  // ---- AI 生成 ----

  /// 自动生成人物并加入项目；返回生成结果与错误信息。
  Future<({List<Character> created, String? error})> generateCharacters({
    String premise = '',
    String requirements = '',
    int count = 3,
    int? yearHint,
  }) async {
    final guard = _aiGuard();
    if (guard != null) return (created: const <Character>[], error: guard);
    final chat = chatFn;
    if (chat == null) {
      return (created: const <Character>[], error: 'AI 服务未初始化');
    }
    try {
      final created = await AiGenerator.generateCharacters(
        chat: chat,
        existing: data.characters,
        premise: premise,
        requirements: requirements,
        count: count,
        yearHint: yearHint,
        colorSeed: data.characters.length,
      );
      if (created.isEmpty) {
        return (created: const <Character>[], error: 'AI 未返回可用的人物');
      }
      addCharacters(created);
      return (created: created, error: null);
    } catch (e) {
      return (created: const <Character>[], error: '生成失败：$e');
    }
  }

  /// 自动生成一篇情节；成功返回生成的故事。
  Future<({Story? story, String? error})> generateStory({
    required List<String> castIds,
    String requirements = '',
    String premise = '',
    DateTime? time,
  }) async {
    final guard = _aiGuard();
    if (guard != null) return (story: null, error: guard);
    final chat = chatFn;
    if (chat == null) return (story: null, error: 'AI 服务未初始化');
    final cast = <Character>[
      for (final id in castIds)
        if (data.characterById(id) != null) data.characterById(id)!,
    ];
    if (cast.isEmpty) return (story: null, error: '请先选择出场人物');
    try {
      final story = await AiGenerator.generateStory(
        chat: chat,
        cast: cast,
        existingStories: sortedStories(),
        requirements: requirements,
        premise: premise,
        time: time,
      );
      if (story == null) return (story: null, error: 'AI 未返回可用的情节');
      addStory(story);
      return (story: story, error: null);
    } catch (e) {
      return (story: null, error: '生成失败：$e');
    }
  }

  /// 润色指定情节的正文，成功后写回。
  Future<String?> polishStory(
    String storyId, {
    String requirements = '',
  }) async {
    final guard = _aiGuard();
    if (guard != null) return guard;
    final chat = chatFn;
    if (chat == null) return 'AI 服务未初始化';
    final story = data.storyById(storyId);
    if (story == null) return '情节不存在';
    final cast = <Character>[
      for (final id in story.characterIds)
        if (data.characterById(id) != null) data.characterById(id)!,
    ];
    try {
      final polished = await AiGenerator.polish(
        chat: chat,
        content: story.content,
        cast: cast,
        requirements: requirements,
      );
      if (polished.isEmpty) return 'AI 未返回内容';
      upsertStory(story.copyWith(content: polished));
      return null;
    } catch (e) {
      return '润色失败：$e';
    }
  }

  // ---- 数据管理 ----

  String exportJson() => data.exportJson();

  bool importJson(String source) {
    try {
      data = ProjectData.fromJsonString(source);
      _markDirty();
      return true;
    } catch (_) {
      return false;
    }
  }

  void clearAll() {
    data = ProjectData();
    _markDirty();
  }

  // ---- 查询辅助 ----

  Character? characterById(String id) => data.characterById(id);

  Story? storyById(String id) => data.storyById(id);

  List<Relation> relationsOf(String characterId) =>
      analysis.relationsOf(characterId);

  List<StoryEvidence> evidenceOf(String storyId) =>
      analysis.evidenceOf(storyId);

  /// 该人物参与的情节：手动勾选，或正文中实际提及。
  List<Story> storiesOf(String characterId) {
    final c = characterById(characterId);
    return [
      for (final s in data.stories)
        if (s.characterIds.contains(characterId) ||
            (c != null &&
                RelationEngine.findMentions(s.content, [c]).isNotEmpty))
          s,
    ];
  }

  /// 按时间排序的全部情节（无时间的排在最后）。
  List<Story> sortedStories() {
    final list = List<Story>.of(data.stories);
    list.sort((a, b) {
      if (a.time == null && b.time == null) {
        return b.createdAt.compareTo(a.createdAt);
      }
      if (a.time == null) return 1;
      if (b.time == null) return -1;
      return a.time!.compareTo(b.time!);
    });
    return list;
  }

  /// 项目是否为空（用于空状态引导）。
  bool get isEmpty => data.characters.isEmpty && data.stories.isEmpty;

  @override
  void dispose() {
    _saveTimer?.cancel();
    super.dispose();
  }
}
