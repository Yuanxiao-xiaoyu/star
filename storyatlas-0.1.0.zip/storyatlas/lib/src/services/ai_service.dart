import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:storyatlas_core/storyatlas_core.dart';

/// OpenAI 兼容接口的聊天客户端（实现核心包的 [ChatFn]）。
class AiService {
  AiService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  /// 发送一次对话请求并返回模型回复文本。
  Future<String> chat(
    AiSettings settings,
    List<Map<String, String>> messages,
  ) async {
    final base = settings.baseUrl.trim().replaceFirst(RegExp(r'/+$'), '');
    final uri = Uri.parse('$base/chat/completions');
    final res = await _client
        .post(
          uri,
          headers: <String, String>{
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${settings.apiKey}',
          },
          body: jsonEncode(<String, Object?>{
            'model': settings.model,
            'messages': messages,
            'temperature': 0.3,
          }),
        )
        .timeout(const Duration(seconds: 90));
    if (res.statusCode != 200) {
      final detail = utf8.decode(res.bodyBytes, allowMalformed: true);
      throw Exception(
        'HTTP ${res.statusCode}: ${detail.length > 200 ? detail.substring(0, 200) : detail}',
      );
    }
    final data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    final choices = data['choices'] as List<dynamic>? ?? const <dynamic>[];
    if (choices.isEmpty) throw const FormatException('响应中没有 choices');
    final message =
        (choices.first as Map<String, dynamic>)['message']
            as Map<String, dynamic>?;
    final content = message?['content'] as String? ?? '';
    if (content.isEmpty) throw const FormatException('响应内容为空');
    return content;
  }

  /// 用一次最小对话测试连接是否可用。
  Future<bool> testConnection(AiSettings settings) async {
    try {
      final out = await chat(settings, <Map<String, String>>[
        <String, String>{'role': 'user', 'content': '请只回复两个字：正常'},
      ]);
      return out.isNotEmpty;
    } catch (_) {
      return false;
    }
  }
}
