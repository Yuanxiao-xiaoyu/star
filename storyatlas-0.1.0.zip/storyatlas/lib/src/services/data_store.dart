import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

/// 本地 JSON 文件存储：应用数据目录下的 storyatlas/project.json。
class DataStore {
  Future<File> _projectFile() async {
    final base = await getApplicationSupportDirectory();
    final dir = Directory('${base.path}${Platform.pathSeparator}storyatlas');
    await dir.create(recursive: true);
    return File('${dir.path}${Platform.pathSeparator}project.json');
  }

  Future<ProjectData?> load() async {
    try {
      final file = await _projectFile();
      if (!await file.exists()) return null;
      final source = await file.readAsString();
      if (source.trim().isEmpty) return null;
      return ProjectData.fromJsonString(source);
    } catch (_) {
      return null;
    }
  }

  Future<void> save(ProjectData data) async {
    try {
      final file = await _projectFile();
      await file.writeAsString(data.exportJson(), flush: true);
    } catch (_) {
      // 存储失败不影响当前会话，仅在下次启动时可能丢失。
    }
  }
}
