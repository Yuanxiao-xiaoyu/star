import 'dart:math';

import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

import '../ui/palette.dart';

/// 关系网节点的绘制元数据。
class GraphNodeMeta {
  const GraphNodeMeta({
    required this.name,
    required this.color,
    required this.radius,
    required this.selected,
  });

  final String name;
  final Color color;
  final double radius;
  final bool selected;
}

/// 人物关系网画布：边（类型着色、粗细按强度、有向箭头）与节点。
class GraphPainter extends CustomPainter {
  GraphPainter({
    required this.positions,
    required this.relations,
    required this.nodes,
  });

  final Map<String, Point<double>> positions;
  final List<Relation> relations;
  final Map<String, GraphNodeMeta> nodes;

  @override
  void paint(Canvas canvas, Size size) {
    final labelStyle = TextStyle(
      fontSize: 11,
      color: Colors.black87,
      fontWeight: FontWeight.w600,
    );

    // 边。
    for (final r in relations) {
      final a = positions[r.fromId];
      final b = positions[r.toId];
      if (a == null || b == null) continue;
      final from = Offset(a.x, a.y);
      final to = Offset(b.x, b.y);
      final color = kindColor(r.kind);
      final stroke = 1 + r.weight / 100 * 3.5;
      canvas.drawLine(
        from,
        to,
        Paint()
          ..color = color.withValues(alpha: 0.55)
          ..strokeWidth = stroke,
      );
      if (r.kind.isDirected) {
        _drawArrow(canvas, from, to, color, stroke);
      }
      if (r.weight >= 25) {
        _drawEdgeLabel(
          canvas,
          Offset((from.dx + to.dx) / 2, (from.dy + to.dy) / 2),
          r.kind.label,
          labelStyle,
          color,
        );
      }
    }

    // 节点。
    for (final e in positions.entries) {
      final meta = nodes[e.key];
      if (meta == null) continue;
      final p = e.value;
      final center = Offset(p.x, p.y);
      canvas.drawCircle(
        center,
        meta.radius + 3,
        Paint()
          ..color = meta.selected
              ? const Color(0xFF4A5FC1)
              : Colors.white.withValues(alpha: 0.9),
      );
      canvas.drawCircle(center, meta.radius, Paint()..color = meta.color);
      if (meta.selected) {
        canvas.drawCircle(
          center,
          meta.radius + 6,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2.5
            ..color = const Color(0xFF4A5FC1),
        );
      }
      _drawText(
        canvas,
        meta.name,
        Offset(p.x, p.y + meta.radius + 14),
        TextStyle(
          fontSize: 12,
          fontWeight: meta.selected ? FontWeight.bold : FontWeight.w500,
          color: Colors.black87,
        ),
        align: _TextAlign.center,
      );
    }
  }

  void _drawArrow(
    Canvas canvas,
    Offset from,
    Offset to,
    Color color,
    double stroke,
  ) {
    final dir = to - from;
    final len = dir.distance;
    if (len < 1) return;
    final unit = dir / len;
    final nodeR = 18.0;
    final tip = to - unit * nodeR;
    final base = tip - unit * 9;
    final perp = Offset(-unit.dy, unit.dx) * 5;
    final path = Path()
      ..moveTo(tip.dx, tip.dy)
      ..lineTo(base.dx + perp.dx, base.dy + perp.dy)
      ..lineTo(base.dx - perp.dx, base.dy - perp.dy)
      ..close();
    canvas.drawPath(path, Paint()..color = color);
  }

  void _drawEdgeLabel(
    Canvas canvas,
    Offset center,
    String text,
    TextStyle style,
    Color color,
  ) {
    final tp = TextPainter(
      text: TextSpan(text: text, style: style),
      textDirection: TextDirection.ltr,
    )..layout();
    final rect = Rect.fromCenter(
      center: center,
      width: tp.width + 8,
      height: tp.height + 2,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(6)),
      Paint()..color = color.withValues(alpha: 0.15),
    );
    tp.paint(canvas, rect.topLeft + const Offset(4, 1));
  }

  void _drawText(
    Canvas canvas,
    String text,
    Offset anchor,
    TextStyle style, {
    required _TextAlign align,
  }) {
    final tp = TextPainter(
      text: TextSpan(text: text, style: style),
      textDirection: TextDirection.ltr,
    )..layout();
    final dx = switch (align) {
      _TextAlign.center => anchor.dx - tp.width / 2,
      _TextAlign.left => anchor.dx,
      _TextAlign.right => anchor.dx - tp.width,
    };
    tp.paint(canvas, Offset(dx, anchor.dy - tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant GraphPainter oldDelegate) =>
      oldDelegate.positions != positions ||
      oldDelegate.relations != relations ||
      oldDelegate.nodes != nodes;
}

enum _TextAlign { left, center, right }
