import 'dart:math';

import 'package:flutter/material.dart';
import 'package:storyatlas_core/storyatlas_core.dart';

/// 思维图节点的绘制元数据。
class MindmapNodeMeta {
  const MindmapNodeMeta({
    required this.label,
    required this.color,
    required this.isStory,
    required this.isRoot,
  });

  final String label;
  final Color color;
  final bool isStory;
  final bool isRoot;
}

/// 思维视图画布：径向树布局 + 连线。
class MindmapPainter extends CustomPainter {
  MindmapPainter({
    required this.positions,
    required this.edges,
    required this.edgeColors,
    required this.nodes,
  });

  final Map<String, Point<double>> positions;
  final List<MindmapEdge> edges;

  /// 每条边（以子节点 ID 为键）的颜色。
  final Map<String, Color> edgeColors;

  final Map<String, MindmapNodeMeta> nodes;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.translate(size.width / 2, size.height / 2);

    // 连线。
    for (final e in edges) {
      final a = positions[e.parentId];
      final b = positions[e.childId];
      if (a == null || b == null) continue;
      final color = edgeColors[e.childId] ?? Colors.grey;
      final from = Offset(a.x, a.y);
      final to = Offset(b.x, b.y);
      canvas.drawLine(
        from,
        to,
        Paint()
          ..color = color.withValues(alpha: 0.7)
          ..strokeWidth = 2,
      );
    }

    // 节点。
    for (final entry in positions.entries) {
      final meta = nodes[entry.key];
      if (meta == null) continue;
      final p = entry.value;
      final center = Offset(p.x, p.y);
      if (meta.isStory) {
        _drawStoryNode(canvas, center, meta.label);
      } else {
        _drawCharNode(canvas, center, meta);
      }
    }

    canvas.restore();
  }

  void _drawCharNode(Canvas canvas, Offset center, MindmapNodeMeta meta) {
    final r = meta.isRoot ? 34.0 : 22.0;
    canvas.drawCircle(
      center,
      r + 3,
      Paint()..color = Colors.white.withValues(alpha: 0.9),
    );
    canvas.drawCircle(center, r, Paint()..color = meta.color);
    if (meta.isRoot) {
      canvas.drawCircle(
        center,
        r + 6,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5
          ..color = const Color(0xFF4A5FC1),
      );
    }
    final tp = TextPainter(
      text: TextSpan(
        text: meta.label,
        style: TextStyle(
          fontSize: meta.isRoot ? 14 : 12,
          fontWeight: FontWeight.w600,
          color: Colors.white,
        ),
      ),
      textDirection: TextDirection.ltr,
      maxLines: 1,
    )..layout(maxWidth: 90);
    tp.paint(
      canvas,
      Offset(center.dx - tp.width / 2, center.dy - tp.height / 2),
    );
    // 名称标在节点下方。
    final nameTp = TextPainter(
      text: TextSpan(
        text: meta.label,
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w500,
          color: Colors.black87,
        ),
      ),
      textDirection: TextDirection.ltr,
      maxLines: 1,
      ellipsis: '…',
    )..layout(maxWidth: 110);
    nameTp.paint(
      canvas,
      Offset(center.dx - nameTp.width / 2, center.dy + r + 8),
    );
  }

  void _drawStoryNode(Canvas canvas, Offset center, String label) {
    final tp = TextPainter(
      text: TextSpan(
        text: label,
        style: const TextStyle(fontSize: 11, color: Colors.black87),
      ),
      textDirection: TextDirection.ltr,
      maxLines: 1,
      ellipsis: '…',
    )..layout(maxWidth: 130);
    final rect = Rect.fromCenter(
      center: center,
      width: tp.width + 16,
      height: 30,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(8)),
      Paint()..color = const Color(0xFFECEFF1),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(8)),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = const Color(0xFF90A4AE),
    );
    tp.paint(canvas, Offset(rect.left + 8, center.dy - tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant MindmapPainter oldDelegate) =>
      oldDelegate.positions != positions ||
      oldDelegate.edges != edges ||
      oldDelegate.edgeColors != edgeColors ||
      oldDelegate.nodes != nodes;
}
