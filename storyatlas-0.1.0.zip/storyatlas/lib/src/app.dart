import 'package:flutter/material.dart';

import 'state/app_state.dart';
import 'ui/home_page.dart';

// 让导入本文件的地方能直接使用 AppState（各界面页面的公共依赖）。
export 'state/app_state.dart';

/// 应用根组件。
class StoryAtlasApp extends StatelessWidget {
  const StoryAtlasApp({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    return AppScope(
      state: state,
      child: MaterialApp(
        title: '故事图谱 StoryAtlas',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorSchemeSeed: const Color(0xFF4A5FC1),
          brightness: Brightness.light,
          inputDecorationTheme: const InputDecorationTheme(
            border: OutlineInputBorder(),
            isDense: true,
          ),
        ),
        darkTheme: ThemeData(
          colorSchemeSeed: const Color(0xFF4A5FC1),
          brightness: Brightness.dark,
          inputDecorationTheme: const InputDecorationTheme(
            border: OutlineInputBorder(),
            isDense: true,
          ),
        ),
        home: const HomePage(),
      ),
    );
  }
}

/// 把 [AppState] 注入组件树。
class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState state, required super.child})
    : super(notifier: state);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppScope>();
    assert(scope != null, 'AppScope 未找到，请确认组件位于 StoryAtlasApp 之下');
    return scope!.notifier!;
  }
}
